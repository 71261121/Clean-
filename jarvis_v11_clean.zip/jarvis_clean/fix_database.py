#!/usr/bin/env python3
"""
JARVIS Database Fix Script
Resolves database connection issues
"""

import sqlite3
import os
import shutil
from pathlib import Path

def fix_jarvis_database():
    """Fixes JARVIS database issues"""
    
    print("🔧 JARVIS Database Fix Starting...")
    
    # Step 1: Clean existing database
    logs_dir = Path("logs")
    db_file = logs_dir / "jarvis.db"
    
    if db_file.exists():
        print("📋 Removing corrupted database...")
        db_file.unlink()
    
    # Step 2: Create fresh database
    print("🆕 Creating fresh database...")
    conn = sqlite3.connect(str(db_file))
    c = conn.cursor()
    
    # Create tables with proper structure
    c.execute('''
        CREATE TABLE IF NOT EXISTS command_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL,
            command TEXT,
            success BOOLEAN,
            execution_time REAL,
            output TEXT,
            error_message TEXT,
            danger_level INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS system_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL,
            cpu_usage REAL,
            memory_usage REAL,
            disk_usage REAL,
            temperature REAL,
            battery_level REAL
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS ai_responses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL,
            query TEXT,
            response TEXT,
            confidence REAL,
            response_time REAL
        )
    ''')
    
    # Insert test data
    c.execute('''
        INSERT INTO command_history 
        (timestamp, command, success, execution_time, output, error_message, danger_level)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (1567890123.456, 'JARVIS_DATABASE_FIX', True, 0.001, 'Database successfully fixed', '', 1))
    
    conn.commit()
    conn.close()
    
    print("✅ Database created successfully!")
    print(f"📁 Database location: {db_file.absolute()}")
    
    # Step 3: Set proper permissions
    try:
        os.chmod(db_file, 0o644)
        print("🔒 Permissions set successfully!")
    except:
        print("⚠️  Permission setting skipped")
    
    # Step 4: Test database
    print("🧪 Testing database...")
    conn = sqlite3.connect(str(db_file))
    c = conn.cursor()
    
    # Test query
    c.execute("SELECT COUNT(*) FROM command_history")
    count = c.fetchone()[0]
    
    conn.close()
    
    print(f"✅ Database test passed! Records: {count}")
    
    # Step 5: Create database config file
    config_content = """# JARVIS Database Configuration
DATABASE_PATH=logs/jarvis.db
DATABASE_TIMEOUT=30
DATABASE_POOL_SIZE=5
DEBUG_DATABASE=false
"""
    
    with open("logs/database_config.txt", "w") as f:
        f.write(config_content)
    
    print("📋 Database configuration created!")
    
    print("\n🎉 Database Fix Complete!")
    print("🚀 Restart JARVIS: python jarvis.py")
    
    return True

if __name__ == "__main__":
    try:
        fix_jarvis_database()
    except Exception as e:
        print(f"❌ Database fix failed: {e}")
        print("💡 For manual fix: rm -rf logs/ && mkdir logs")