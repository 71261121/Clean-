#!/usr/bin/env python3
"""
JARVIS v11 Example Plugin System
Comprehensive plugin examples demonstrating various plugin types
"""

import time
import json
import random
import datetime
from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'JARVIS Example Plugin Suite',
    'description': 'Comprehensive example plugin demonstrating all plugin types and features',
    'version': '1.0.0',
    'author': 'JARVIS Development Team',
    'plugin_type': 'suite'
}

# Voice Command Plugin Example
class VoiceCommandExamplePlugin(BasePlugin):
    """Example voice command plugin with custom handlers"""
    
    def initialize(self):
        """Initialize the voice command plugin"""
        super().initialize()
        
        # Register custom voice commands
        self.register_voice_command('time', self.handle_time_command)
        self.register_voice_command('weather', self.handle_weather_command)
        self.register_voice_command('reminder', self.handle_reminder_command)
        self.register_voice_command('status', self.handle_status_command)
        
        # Initialize reminder system
        self.reminders = []
        self.command_history = []
        
        self.logger.info("Voice Command Example Plugin initialized")
        return True
    
    def register_voice_command(self, command: str, handler):
        """Register voice command handler with JARVIS voice system"""
        try:
            # This would integrate with JARVIS voice system
            # For demonstration, we'll store the handler
            self.voice_commands[command] = handler
            self.logger.info(f"Registered voice command: {command}")
            
        except Exception as e:
            self.logger.error(f"Failed to register voice command {command}: {e}")
    
    def handle_time_command(self, *args):
        """Handle time command"""
        current_time = datetime.datetime.now().strftime("%H:%M:%S")
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        
        response = f"Current time is {current_time} on {current_date}"
        self.command_history.append(('time', response))
        
        return response
    
    def handle_weather_command(self, *args):
        """Handle weather command (simulated)"""
        # Simulate weather data
        weather_conditions = ['sunny', 'cloudy', 'rainy', 'snowy']
        temperatures = [15, 18, 22, 25, 28, 30]
        
        condition = random.choice(weather_conditions)
        temp = random.choice(temperatures)
        
        response = f"Weather forecast: {condition} with {temp}°C temperature"
        self.command_history.append(('weather', response))
        
        return response
    
    def handle_reminder_command(self, *args):
        """Handle reminder command"""
        if args:
            reminder_text = ' '.join(args)
            reminder = {
                'text': reminder_text,
                'timestamp': datetime.datetime.now().isoformat(),
                'completed': False
            }
            self.reminders.append(reminder)
            response = f"Reminder added: {reminder_text}"
        else:
            response = "Please provide reminder text"
        
        self.command_history.append(('reminder', response))
        return response
    
    def handle_status_command(self, *args):
        """Handle status command"""
        active_plugins = len(self.architecture.loaded_plugins)
        total_commands = len(self.command_history)
        total_reminders = len(self.reminders)
        
        response = f"JARVIS Status: {active_plugins} active plugins, {total_commands} commands processed, {total_reminders} reminders"
        self.command_history.append(('status', response))
        
        return response
    
    def get_reminders(self):
        """Get all reminders"""
        return self.reminders
    
    def complete_reminder(self, index: int) -> bool:
        """Mark reminder as completed"""
        if 0 <= index < len(self.reminders):
            self.reminders[index]['completed'] = True
            return True
        return False
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['voice_commands', 'reminders', 'time_queries', 'weather_sim']
    
    def handle_command(self, command: str, args: list):
        """Handle commands from JARVIS"""
        if command in self.voice_commands:
            return self.voice_commands[command](*args)
        return None


# API Integration Plugin Example
class ApiIntegrationExamplePlugin(BasePlugin):
    """Example API integration plugin"""
    
    def initialize(self):
        """Initialize the API integration plugin"""
        super().initialize()
        
        # Mock API configuration
        self.api_endpoints = {
            'news': 'https://api.news.example.com/latest',
            'quotes': 'https://api.quotes.example.com/random',
            'weather': 'https://api.weather.example.com/current'
        }
        
        self.api_cache = {}
        self.cache_duration = 300  # 5 minutes
        
        self.logger.info("API Integration Example Plugin initialized")
        return True
    
    def fetch_news(self, category: str = 'general') -> dict:
        """Fetch news from external API"""
        try:
            cache_key = f"news_{category}"
            
            # Check cache first
            if self._is_cache_valid(cache_key):
                self.logger.info("Returning cached news data")
                return self.api_cache[cache_key]
            
            # Mock API call
            news_data = {
                'headlines': [
                    f"Breaking: {category.title()} news item 1",
                    f"Update: {category.title()} news item 2",
                    f"Latest: {category.title()} news item 3"
                ],
                'timestamp': datetime.datetime.now().isoformat(),
                'category': category
            }
            
            # Cache the result
            self._cache_data(cache_key, news_data)
            
            return news_data
            
        except Exception as e:
            self.logger.error(f"Failed to fetch news: {e}")
            return {}
    
    def fetch_quote(self) -> dict:
        """Fetch random quote"""
        try:
            cache_key = "quote"
            
            # Check cache
            if self._is_cache_valid(cache_key):
                return self.api_cache[cache_key]
            
            # Mock API call
            quotes = [
                {"text": "The only way to do great work is to love what you do.", "author": "Steve Jobs"},
                {"text": "Innovation distinguishes between a leader and a follower.", "author": "Steve Jobs"},
                {"text": "Life is what happens to you while you're busy making other plans.", "author": "John Lennon"},
                {"text": "The future belongs to those who believe in the beauty of their dreams.", "author": "Eleanor Roosevelt"},
                {"text": "It is during our darkest moments that we must focus to see the light.", "author": "Aristotle"}
            ]
            
            quote = random.choice(quotes)
            quote_data = {
                'quote': quote['text'],
                'author': quote['author'],
                'timestamp': datetime.datetime.now().isoformat()
            }
            
            # Cache the result
            self._cache_data(cache_key, quote_data)
            
            return quote_data
            
        except Exception as e:
            self.logger.error(f"Failed to fetch quote: {e}")
            return {}
    
    def _is_cache_valid(self, cache_key: str) -> bool:
        """Check if cached data is still valid"""
        if cache_key not in self.api_cache:
            return False
        
        cache_time = self.api_cache[cache_key].get('cache_time', 0)
        return (time.time() - cache_time) < self.cache_duration
    
    def _cache_data(self, cache_key: str, data: dict):
        """Cache data with timestamp"""
        data['cache_time'] = time.time()
        self.api_cache[cache_key] = data
    
    def clear_cache(self):
        """Clear API cache"""
        self.api_cache.clear()
        self.logger.info("API cache cleared")
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['api_integration', 'news_fetching', 'quote_generation', 'caching']
    
    def handle_command(self, command: str, args: list):
        """Handle commands from JARVIS"""
        if command == 'news':
            category = args[0] if args else 'general'
            return self.fetch_news(category)
        elif command == 'quote':
            return self.fetch_quote()
        elif command == 'clear_cache':
            self.clear_cache()
            return "Cache cleared"
        return None


# Data Processing Plugin Example
class DataProcessingExamplePlugin(BasePlugin):
    """Example data processing plugin"""
    
    def initialize(self):
        """Initialize the data processing plugin"""
        super().initialize()
        
        # Data processing pipelines
        self.pipelines = {}
        self.data_history = []
        
        self.logger.info("Data Processing Example Plugin initialized")
        return True
    
    def create_pipeline(self, name: str, steps: list) -> bool:
        """Create data processing pipeline"""
        try:
            self.pipelines[name] = {
                'steps': steps,
                'created_at': datetime.datetime.now().isoformat(),
                'executed_count': 0
            }
            self.logger.info(f"Created pipeline: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create pipeline {name}: {e}")
            return False
    
    def execute_pipeline(self, name: str, data: list) -> list:
        """Execute data processing pipeline"""
        try:
            if name not in self.pipelines:
                raise ValueError(f"Pipeline {name} not found")
            
            pipeline = self.pipelines[name]
            processed_data = data.copy()
            
            # Execute each step
            for step in pipeline['steps']:
                processed_data = self._execute_step(step, processed_data)
            
            # Update pipeline stats
            pipeline['executed_count'] += 1
            
            # Log processing
            processing_log = {
                'pipeline': name,
                'input_size': len(data),
                'output_size': len(processed_data),
                'timestamp': datetime.datetime.now().isoformat()
            }
            self.data_history.append(processing_log)
            
            self.logger.info(f"Executed pipeline {name} on {len(data)} items")
            return processed_data
            
        except Exception as e:
            self.logger.error(f"Failed to execute pipeline {name}: {e}")
            return []
    
    def _execute_step(self, step: dict, data: list) -> list:
        """Execute individual processing step"""
        step_type = step.get('type')
        step_config = step.get('config', {})
        
        if step_type == 'filter':
            return self._filter_data(data, step_config)
        elif step_type == 'transform':
            return self._transform_data(data, step_config)
        elif step_type == 'aggregate':
            return self._aggregate_data(data, step_config)
        elif step_type == 'sort':
            return self._sort_data(data, step_config)
        else:
            self.logger.warning(f"Unknown step type: {step_type}")
            return data
    
    def _filter_data(self, data: list, config: dict) -> list:
        """Filter data based on criteria"""
        field = config.get('field')
        operator = config.get('operator', '==')
        value = config.get('value')
        
        filtered_data = []
        for item in data:
            if isinstance(item, dict) and field in item:
                item_value = item[field]
                
                if operator == '==' and item_value == value:
                    filtered_data.append(item)
                elif operator == '!=' and item_value != value:
                    filtered_data.append(item)
                elif operator == '>' and item_value > value:
                    filtered_data.append(item)
                elif operator == '<' and item_value < value:
                    filtered_data.append(item)
            else:
                filtered_data.append(item)
        
        return filtered_data
    
    def _transform_data(self, data: list, config: dict) -> list:
        """Transform data"""
        field = config.get('field')
        operation = config.get('operation', 'uppercase')
        
        transformed_data = []
        for item in data:
            if isinstance(item, dict) and field in item:
                if operation == 'uppercase':
                    item[field] = str(item[field]).upper()
                elif operation == 'lowercase':
                    item[field] = str(item[field]).lower()
                elif operation == 'capitalize':
                    item[field] = str(item[field]).capitalize()
            
            transformed_data.append(item)
        
        return transformed_data
    
    def _aggregate_data(self, data: list, config: dict) -> list:
        """Aggregate data"""
        field = config.get('field')
        operation = config.get('operation', 'sum')
        
        if not data:
            return []
        
        if operation == 'sum':
            total = sum(item.get(field, 0) for item in data if isinstance(item, dict))
            return [{'sum': total, 'count': len(data)}]
        elif operation == 'average':
            if data and isinstance(data[0], dict) and field in data[0]:
                values = [item.get(field, 0) for item in data]
                avg = sum(values) / len(values) if values else 0
                return [{'average': avg, 'count': len(data)}]
        
        return data
    
    def _sort_data(self, data: list, config: dict) -> list:
        """Sort data"""
        field = config.get('field')
        reverse = config.get('reverse', False)
        
        if not data:
            return data
        
        if isinstance(data[0], dict) and field in data[0]:
            return sorted(data, key=lambda x: x.get(field, 0), reverse=reverse)
        else:
            return sorted(data, reverse=reverse)
    
    def get_pipeline_stats(self) -> dict:
        """Get pipeline execution statistics"""
        stats = {}
        for name, pipeline in self.pipelines.items():
            stats[name] = {
                'executed_count': pipeline['executed_count'],
                'created_at': pipeline['created_at'],
                'steps_count': len(pipeline['steps'])
            }
        return stats
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['data_processing', 'pipelines', 'filtering', 'transformation']
    
    def handle_command(self, command: str, args: list):
        """Handle commands from JARVIS"""
        if command == 'create_pipeline':
            name, steps = args[0], args[1] if len(args) > 1 else []
            return self.create_pipeline(name, steps)
        elif command == 'execute_pipeline':
            name, data = args[0], args[1] if len(args) > 1 else []
            return self.execute_pipeline(name, data)
        elif command == 'pipeline_stats':
            return self.get_pipeline_stats()
        return None


# UI Enhancement Plugin Example
class UiEnhancementExamplePlugin(BasePlugin):
    """Example UI enhancement plugin"""
    
    def initialize(self):
        """Initialize the UI enhancement plugin"""
        super().initialize()
        
        # UI enhancement settings
        self.theme = 'dark'
        self.notifications_enabled = True
        self.sound_enabled = True
        self.custom_widgets = {}
        
        # Notification queue
        self.notification_queue = []
        
        self.logger.info("UI Enhancement Example Plugin initialized")
        return True
    
    def set_theme(self, theme: str) -> bool:
        """Set UI theme"""
        valid_themes = ['dark', 'light', 'auto', 'custom']
        if theme in valid_themes:
            self.theme = theme
            self._apply_theme(theme)
            self.logger.info(f"Theme changed to: {theme}")
            return True
        return False
    
    def _apply_theme(self, theme: str):
        """Apply theme to JARVIS interface"""
        # This would integrate with JARVIS UI system
        theme_config = {
            'dark': {'bg': '#000000', 'fg': '#FFFFFF', 'accent': '#00FF00'},
            'light': {'bg': '#FFFFFF', 'fg': '#000000', 'accent': '#0066CC'},
            'auto': {'bg': 'auto', 'fg': 'auto', 'accent': 'auto'},
            'custom': {'bg': 'custom', 'fg': 'custom', 'accent': 'custom'}
        }
        
        self.architecture.logger.info(f"Applied theme configuration: {theme_config.get(theme, {})}")
    
    def show_notification(self, title: str, message: str, priority: str = 'normal'):
        """Show custom notification"""
        notification = {
            'title': title,
            'message': message,
            'priority': priority,
            'timestamp': datetime.datetime.now().isoformat(),
            'id': len(self.notification_queue)
        }
        
        self.notification_queue.append(notification)
        
        if self.notifications_enabled:
            self._display_notification(notification)
        
        self.logger.info(f"Notification queued: {title}")
        return notification['id']
    
    def _display_notification(self, notification: dict):
        """Display notification to user"""
        # This would integrate with JARVIS notification system
        priority_symbols = {'low': '🔵', 'normal': '🟡', 'high': '🟠', 'critical': '🔴'}
        symbol = priority_symbols.get(notification['priority'], '⚪')
        
        display_message = f"{symbol} {notification['title']}: {notification['message']}"
        self.architecture.logger.info(f"DISPLAY NOTIFICATION: {display_message}")
    
    def add_custom_widget(self, name: str, widget_config: dict) -> bool:
        """Add custom widget to interface"""
        try:
            self.custom_widgets[name] = {
                'config': widget_config,
                'created_at': datetime.datetime.now().isoformat(),
                'visible': True
            }
            
            self.logger.info(f"Custom widget added: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add custom widget {name}: {e}")
            return False
    
    def get_notifications(self, limit: int = 10) -> list:
        """Get recent notifications"""
        return self.notification_queue[-limit:]
    
    def clear_notifications(self):
        """Clear all notifications"""
        self.notification_queue.clear()
        self.logger.info("All notifications cleared")
    
    def toggle_notifications(self, enabled: bool):
        """Toggle notifications on/off"""
        self.notifications_enabled = enabled
        self.logger.info(f"Notifications {'enabled' if enabled else 'disabled'}")
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['ui_themes', 'notifications', 'custom_widgets', 'interface_enhancement']
    
    def handle_command(self, command: str, args: list):
        """Handle commands from JARVIS"""
        if command == 'set_theme':
            theme = args[0] if args else 'dark'
            return self.set_theme(theme)
        elif command == 'notify':
            title, message = args[0], args[1] if len(args) > 1 else ''
            return self.show_notification(title, message)
        elif command == 'add_widget':
            name, config = args[0], args[1] if len(args) > 1 else {}
            return self.add_custom_widget(name, config)
        elif command == 'get_notifications':
            limit = int(args[0]) if args and args[0].isdigit() else 10
            return self.get_notifications(limit)
        elif command == 'clear_notifications':
            self.clear_notifications()
            return "Notifications cleared"
        return None


# Automation Plugin Example
class AutomationExamplePlugin(BasePlugin):
    """Example task automation plugin"""
    
    def initialize(self):
        """Initialize the automation plugin"""
        super().initialize()
        
        # Automation workflows
        self.workflows = {}
        self.scheduled_tasks = {}
        self.automation_history = []
        
        # Predefined automation templates
        self.templates = {
            'morning_routine': {
                'name': 'Morning Routine',
                'description': 'Automated morning tasks',
                'steps': [
                    {'action': 'check_weather', 'params': {}},
                    {'action': 'read_news', 'params': {'category': 'general'}},
                    {'action': 'set_reminder', 'params': {'message': 'Morning workout'}}
                ]
            },
            'evening_backup': {
                'name': 'Evening Backup',
                'description': 'Automated evening backup tasks',
                'steps': [
                    {'action': 'backup_files', 'params': {'path': '~/Documents'}},
                    {'action': 'system_cleanup', 'params': {}},
                    {'action': 'schedule_maintenance', 'params': {'time': '02:00'}}
                ]
            }
        }
        
        self.logger.info("Automation Example Plugin initialized")
        return True
    
    def create_workflow(self, name: str, description: str, steps: list) -> bool:
        """Create automation workflow"""
        try:
            self.workflows[name] = {
                'name': name,
                'description': description,
                'steps': steps,
                'created_at': datetime.datetime.now().isoformat(),
                'executed_count': 0,
                'last_executed': None,
                'enabled': True
            }
            
            self.logger.info(f"Created workflow: {name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create workflow {name}: {e}")
            return False
    
    def execute_workflow(self, name: str) -> dict:
        """Execute automation workflow"""
        try:
            if name not in self.workflows:
                raise ValueError(f"Workflow {name} not found")
            
            workflow = self.workflows[name]
            
            if not workflow['enabled']:
                return {'success': False, 'error': 'Workflow is disabled'}
            
            execution_result = {
                'workflow': name,
                'start_time': datetime.datetime.now().isoformat(),
                'steps_executed': 0,
                'steps_total': len(workflow['steps']),
                'success': True,
                'errors': []
            }
            
            # Execute each step
            for i, step in enumerate(workflow['steps']):
                try:
                    step_result = self._execute_step(step)
                    execution_result['steps_executed'] += 1
                    
                    if not step_result['success']:
                        execution_result['errors'].append(f"Step {i+1} failed: {step_result['error']}")
                        execution_result['success'] = False
                        
                except Exception as e:
                    execution_result['errors'].append(f"Step {i+1} error: {str(e)}")
                    execution_result['success'] = False
            
            # Update workflow stats
            workflow['executed_count'] += 1
            workflow['last_executed'] = execution_result['start_time']
            
            # Log execution
            self.automation_history.append(execution_result)
            
            self.logger.info(f"Executed workflow {name}: {execution_result['steps_executed']}/{execution_result['steps_total']} steps")
            return execution_result
            
        except Exception as e:
            self.logger.error(f"Failed to execute workflow {name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def _execute_step(self, step: dict) -> dict:
        """Execute individual automation step"""
        action = step.get('action')
        params = step.get('params', {})
        
        try:
            if action == 'check_weather':
                return self._action_check_weather(params)
            elif action == 'read_news':
                return self._action_read_news(params)
            elif action == 'set_reminder':
                return self._action_set_reminder(params)
            elif action == 'backup_files':
                return self._action_backup_files(params)
            elif action == 'system_cleanup':
                return self._action_system_cleanup(params)
            elif action == 'schedule_maintenance':
                return self._action_schedule_maintenance(params)
            else:
                return {'success': False, 'error': f"Unknown action: {action}"}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _action_check_weather(self, params: dict) -> dict:
        """Check weather action"""
        # Simulate weather check
        weather_data = {
            'location': params.get('location', 'Current Location'),
            'temperature': random.randint(15, 30),
            'condition': random.choice(['sunny', 'cloudy', 'rainy']),
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.logger.info(f"Weather check completed: {weather_data['condition']}, {weather_data['temperature']}°C")
        return {'success': True, 'data': weather_data}
    
    def _action_read_news(self, params: dict) -> dict:
        """Read news action"""
        category = params.get('category', 'general')
        
        # Simulate news reading
        news_headlines = [
            f"Top {category} news headline 1",
            f"Breaking {category} news headline 2",
            f"Latest {category} update headline 3"
        ]
        
        news_data = {
            'category': category,
            'headlines': news_headlines,
            'count': len(news_headlines),
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.logger.info(f"News reading completed: {len(news_headlines)} headlines")
        return {'success': True, 'data': news_data}
    
    def _action_set_reminder(self, params: dict) -> dict:
        """Set reminder action"""
        message = params.get('message', 'Automated reminder')
        
        # Simulate reminder setting
        reminder_data = {
            'message': message,
            'scheduled_time': datetime.datetime.now().isoformat(),
            'id': random.randint(1000, 9999),
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.logger.info(f"Reminder set: {message}")
        return {'success': True, 'data': reminder_data}
    
    def _action_backup_files(self, params: dict) -> dict:
        """Backup files action"""
        path = params.get('path', '~/Documents')
        
        # Simulate file backup
        backup_data = {
            'source_path': path,
            'backup_location': f"{path}_backup_{int(time.time())}",
            'files_backed_up': random.randint(50, 200),
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.logger.info(f"Backup completed: {backup_data['files_backed_up']} files")
        return {'success': True, 'data': backup_data}
    
    def _action_system_cleanup(self, params: dict) -> dict:
        """System cleanup action"""
        # Simulate system cleanup
        cleanup_data = {
            'cache_cleared': True,
            'temp_files_removed': random.randint(100, 500),
            'disk_space_freed': random.randint(100, 1000),  # MB
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.logger.info(f"System cleanup completed: {cleanup_data['disk_space_freed']} MB freed")
        return {'success': True, 'data': cleanup_data}
    
    def _action_schedule_maintenance(self, params: dict) -> dict:
        """Schedule maintenance action"""
        time_str = params.get('time', '02:00')
        
        # Simulate maintenance scheduling
        maintenance_data = {
            'scheduled_time': time_str,
            'maintenance_type': 'routine',
            'estimated_duration': '2 hours',
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        self.logger.info(f"Maintenance scheduled for {time_str}")
        return {'success': True, 'data': maintenance_data}
    
    def schedule_workflow(self, name: str, schedule_time: str) -> bool:
        """Schedule workflow execution"""
        try:
            self.scheduled_tasks[name] = {
                'workflow_name': name,
                'schedule_time': schedule_time,
                'created_at': datetime.datetime.now().isoformat(),
                'enabled': True
            }
            
            self.logger.info(f"Workflow {name} scheduled for {schedule_time}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to schedule workflow {name}: {e}")
            return False
    
    def get_workflow_stats(self) -> dict:
        """Get workflow execution statistics"""
        stats = {}
        for name, workflow in self.workflows.items():
            stats[name] = {
                'executed_count': workflow['executed_count'],
                'last_executed': workflow['last_executed'],
                'enabled': workflow['enabled'],
                'steps_count': len(workflow['steps'])
            }
        return stats
    
    def get_automation_history(self, limit: int = 10) -> list:
        """Get automation execution history"""
        return self.automation_history[-limit:]
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['workflow_automation', 'task_scheduling', 'system_automation']
    
    def handle_command(self, command: str, args: list):
        """Handle commands from JARVIS"""
        if command == 'create_workflow':
            name, description = args[0], args[1] if len(args) > 1 else ''
            steps = args[2] if len(args) > 2 else []
            return self.create_workflow(name, description, steps)
        elif command == 'execute_workflow':
            name = args[0] if args else ''
            return self.execute_workflow(name)
        elif command == 'schedule_workflow':
            name, schedule_time = args[0], args[1] if len(args) > 1 else ''
            return self.schedule_workflow(name, schedule_time)
        elif command == 'workflow_stats':
            return self.get_workflow_stats()
        elif command == 'automation_history':
            limit = int(args[0]) if args and args[0].isdigit() else 10
            return self.get_automation_history(limit)
        return None


# Learning Plugin Example
class LearningExamplePlugin(BasePlugin):
    """Example machine learning plugin"""
    
    def initialize(self):
        """Initialize the learning plugin"""
        super().initialize()
        
        # Machine learning models
        self.models = {}
        self.training_data = {}
        self.predictions = []
        self.learning_stats = {}
        
        # Pre-trained simple models
        self._initialize_simple_models()
        
        self.logger.info("Learning Example Plugin initialized")
        return True
    
    def _initialize_simple_models(self):
        """Initialize simple pre-trained models"""
        # Simple sentiment analysis model (mock)
        self.models['sentiment'] = {
            'type': 'sentiment_analysis',
            'vocabulary': {
                'positive': ['good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'love', 'like'],
                'negative': ['bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 'worst', 'stupid']
            },
            'trained_at': datetime.datetime.now().isoformat(),
            'accuracy': 0.85
        }
        
        # Simple spam detection model (mock)
        self.models['spam_detection'] = {
            'type': 'spam_detection',
            'keywords': ['free', 'win', 'money', 'urgent', 'click', 'now', 'limited', 'offer'],
            'trained_at': datetime.datetime.now().isoformat(),
            'accuracy': 0.78
        }
        
        # Simple text classification model (mock)
        self.models['text_classification'] = {
            'type': 'text_classification',
            'categories': {
                'sports': ['game', 'team', 'player', 'match', 'score', 'win', 'lose'],
                'technology': ['computer', 'software', 'internet', 'digital', 'data', 'AI', 'robot'],
                'health': ['doctor', 'medicine', 'health', 'disease', 'treatment', 'hospital', 'patient']
            },
            'trained_at': datetime.datetime.now().isoformat(),
            'accuracy': 0.82
        }
    
    def train_model(self, model_name: str, training_data: list, labels: list) -> dict:
        """Train a machine learning model"""
        try:
            if len(training_data) != len(labels):
                raise ValueError("Training data and labels must have same length")
            
            # Initialize training data storage
            if model_name not in self.training_data:
                self.training_data[model_name] = {'data': [], 'labels': []}
            
            # Add new training data
            self.training_data[model_name]['data'].extend(training_data)
            self.training_data[model_name]['labels'].extend(labels)
            
            # Simulate model training
            training_result = {
                'model_name': model_name,
                'training_samples': len(training_data),
                'total_samples': len(self.training_data[model_name]['data']),
                'accuracy': random.uniform(0.7, 0.95),
                'trained_at': datetime.datetime.now().isoformat(),
                'status': 'completed'
            }
            
            # Update learning stats
            self.learning_stats[model_name] = training_result
            
            self.logger.info(f"Model {model_name} training completed: {training_result['accuracy']:.2%} accuracy")
            return training_result
            
        except Exception as e:
            self.logger.error(f"Model training failed for {model_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def predict(self, model_name: str, input_data: list) -> list:
        """Make predictions using trained model"""
        try:
            if model_name not in self.models:
                raise ValueError(f"Model {model_name} not found")
            
            model = self.models[model_name]
            predictions = []
            
            for item in input_data:
                if model['type'] == 'sentiment_analysis':
                    prediction = self._predict_sentiment(item)
                elif model['type'] == 'spam_detection':
                    prediction = self._predict_spam(item)
                elif model['type'] == 'text_classification':
                    prediction = self._predict_category(item)
                else:
                    prediction = {'label': 'unknown', 'confidence': 0.0}
                
                predictions.append(prediction)
            
            # Log predictions
            self.predictions.extend(predictions)
            
            self.logger.info(f"Generated {len(predictions)} predictions using model {model_name}")
            return predictions
            
        except Exception as e:
            self.logger.error(f"Prediction failed for model {model_name}: {e}")
            return []
    
    def _predict_sentiment(self, text: str) -> dict:
        """Predict sentiment of text"""
        text_lower = text.lower()
        positive_score = sum(1 for word in self.models['sentiment']['vocabulary']['positive'] 
                           if word in text_lower)
        negative_score = sum(1 for word in self.models['sentiment']['vocabulary']['negative'] 
                           if word in text_lower)
        
        if positive_score > negative_score:
            label = 'positive'
            confidence = min(0.95, 0.5 + (positive_score - negative_score) * 0.1)
        elif negative_score > positive_score:
            label = 'negative'
            confidence = min(0.95, 0.5 + (negative_score - positive_score) * 0.1)
        else:
            label = 'neutral'
            confidence = 0.5
        
        return {
            'text': text,
            'sentiment': label,
            'confidence': confidence,
            'positive_score': positive_score,
            'negative_score': negative_score
        }
    
    def _predict_spam(self, text: str) -> dict:
        """Predict if text is spam"""
        text_lower = text.lower()
        spam_score = sum(1 for keyword in self.models['spam_detection']['keywords'] 
                        if keyword in text_lower)
        
        spam_probability = min(0.95, spam_score * 0.2)
        is_spam = spam_probability > 0.5
        
        return {
            'text': text,
            'is_spam': is_spam,
            'spam_probability': spam_probability,
            'spam_score': spam_score
        }
    
    def _predict_category(self, text: str) -> dict:
        """Predict category of text"""
        text_lower = text.lower()
        category_scores = {}
        
        for category, keywords in self.models['text_classification']['categories'].items():
            score = sum(1 for keyword in keywords if keyword in text_lower)
            category_scores[category] = score
        
        if category_scores:
            best_category = max(category_scores, key=category_scores.get)
            confidence = min(0.95, category_scores[best_category] * 0.15 + 0.3)
        else:
            best_category = 'unknown'
            confidence = 0.1
        
        return {
            'text': text,
            'category': best_category,
            'confidence': confidence,
            'category_scores': category_scores
        }
    
    def evaluate_model(self, model_name: str, test_data: list, true_labels: list) -> dict:
        """Evaluate model performance"""
        try:
            if len(test_data) != len(true_labels):
                raise ValueError("Test data and labels must have same length")
            
            predictions = self.predict(model_name, test_data)
            
            # Calculate accuracy
            correct = 0
            for i, (pred, true_label) in enumerate(zip(predictions, true_labels)):
                if model_name in self.models and self.models[model_name]['type'] == 'sentiment_analysis':
                    if pred.get('sentiment') == true_label:
                        correct += 1
                elif model_name in self.models and self.models[model_name]['type'] == 'text_classification':
                    if pred.get('category') == true_label:
                        correct += 1
            
            accuracy = correct / len(test_data) if test_data else 0
            
            evaluation_result = {
                'model_name': model_name,
                'test_samples': len(test_data),
                'correct_predictions': correct,
                'accuracy': accuracy,
                'evaluated_at': datetime.datetime.now().isoformat()
            }
            
            self.logger.info(f"Model {model_name} evaluation: {accuracy:.2%} accuracy")
            return evaluation_result
            
        except Exception as e:
            self.logger.error(f"Model evaluation failed for {model_name}: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_model_info(self, model_name: str) -> dict:
        """Get model information"""
        if model_name in self.models:
            model_info = self.models[model_name].copy()
            
            # Add training data info if available
            if model_name in self.training_data:
                model_info['training_samples'] = len(self.training_data[model_name]['data'])
            
            # Add learning stats if available
            if model_name in self.learning_stats:
                model_info['learning_stats'] = self.learning_stats[model_name]
            
            return model_info
        
        return {}
    
    def list_models(self) -> list:
        """List all available models"""
        model_list = []
        for model_name, model_info in self.models.items():
            model_list.append({
                'name': model_name,
                'type': model_info['type'],
                'accuracy': model_info.get('accuracy', 0.0),
                'trained_at': model_info['trained_at']
            })
        return model_list
    
    def get_prediction_history(self, limit: int = 10) -> list:
        """Get prediction history"""
        return self.predictions[-limit:]
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['machine_learning', 'sentiment_analysis', 'text_classification', 'spam_detection']
    
    def handle_command(self, command: str, args: list):
        """Handle commands from JARVIS"""
        if command == 'train_model':
            model_name = args[0] if args else ''
            training_data = args[1] if len(args) > 1 else []
            labels = args[2] if len(args) > 2 else []
            return self.train_model(model_name, training_data, labels)
        elif command == 'predict':
            model_name = args[0] if args else ''
            input_data = args[1] if len(args) > 1 else []
            return self.predict(model_name, input_data)
        elif command == 'evaluate_model':
            model_name = args[0] if args else ''
            test_data = args[1] if len(args) > 1 else []
            true_labels = args[2] if len(args) > 2 else []
            return self.evaluate_model(model_name, test_data, true_labels)
        elif command == 'model_info':
            model_name = args[0] if args else ''
            return self.get_model_info(model_name)
        elif command == 'list_models':
            return self.list_models()
        elif command == 'prediction_history':
            limit = int(args[0]) if args and args[0].isdigit() else 10
            return self.get_prediction_history(limit)
        return None


# Main Plugin Class
class ExamplePluginSuite(BasePlugin):
    """Main example plugin that demonstrates all plugin types"""
    
    def initialize(self):
        """Initialize the complete example plugin suite"""
        super().initialize()
        
        # Initialize all example plugin types
        self.voice_plugin = VoiceCommandExamplePlugin(self.architecture)
        self.api_plugin = ApiIntegrationExamplePlugin(self.architecture)
        self.data_plugin = DataProcessingExamplePlugin(self.architecture)
        self.ui_plugin = UiEnhancementExamplePlugin(self.architecture)
        self.automation_plugin = AutomationExamplePlugin(self.architecture)
        self.learning_plugin = LearningExamplePlugin(self.architecture)
        
        # Initialize each plugin
        success_count = 0
        total_plugins = 6
        
        if self.voice_plugin.initialize():
            success_count += 1
        if self.api_plugin.initialize():
            success_count += 1
        if self.data_plugin.initialize():
            success_count += 1
        if self.ui_plugin.initialize():
            success_count += 1
        if self.automation_plugin.initialize():
            success_count += 1
        if self.learning_plugin.initialize():
            success_count += 1
        
        self.logger.info(f"Example Plugin Suite: {success_count}/{total_plugins} plugins initialized")
        
        # Create demonstration workflows
        self._create_demo_workflows()
        
        return success_count == total_plugins
    
    def _create_demo_workflows(self):
        """Create demonstration workflows"""
        # Create a sample data processing pipeline
        pipeline_steps = [
            {'type': 'filter', 'config': {'field': 'age', 'operator': '>', 'value': 18}},
            {'type': 'transform', 'config': {'field': 'name', 'operation': 'uppercase'}},
            {'type': 'sort', 'config': {'field': 'age', 'reverse': True}}
        ]
        
        self.data_plugin.create_pipeline('user_data_processing', pipeline_steps)
        
        # Create a sample automation workflow
        workflow_steps = [
            {'action': 'check_weather', 'params': {}},
            {'action': 'read_news', 'params': {'category': 'technology'}},
            {'action': 'set_reminder', 'params': {'message': 'Daily learning session'}}
        ]
        
        self.automation_plugin.create_workflow('daily_intelligence', 'Daily intelligence gathering', workflow_steps)
    
    def get_demo_data(self) -> dict:
        """Get demonstration data for testing"""
        return {
            'voice_commands': ['time', 'weather', 'reminder meeting at 3pm', 'status'],
            'sample_data': [
                {'name': 'alice', 'age': 25, 'city': 'mumbai'},
                {'name': 'bob', 'age': 17, 'city': 'delhi'},
                {'name': 'charlie', 'age': 30, 'city': 'bangalore'},
                {'name': 'diana', 'age': 22, 'city': 'pune'}
            ],
            'sample_texts': [
                'I love this amazing product!',
                'This is terrible and awful.',
                'The weather is nice today.',
                'Click here for free money now!',
                'Sports news about the match.',
                'AI technology breakthrough.'
            ],
            'workflow_results': {},
            'model_predictions': {}
        }
    
    def run_comprehensive_demo(self) -> dict:
        """Run comprehensive demonstration of all plugin features"""
        demo_results = {
            'timestamp': datetime.datetime.now().isoformat(),
            'tests_performed': [],
            'results': {},
            'errors': []
        }
        
        try:
            # Test voice commands
            demo_results['tests_performed'].append('voice_commands')
            voice_results = []
            for command in ['time', 'weather', 'status']:
                result = self.voice_plugin.handle_command(command, [])
                voice_results.append({'command': command, 'result': result})
            demo_results['results']['voice_commands'] = voice_results
            
            # Test API integration
            demo_results['tests_performed'].append('api_integration')
            api_results = {
                'news': self.api_plugin.fetch_news('technology'),
                'quote': self.api_plugin.fetch_quote()
            }
            demo_results['results']['api_integration'] = api_results
            
            # Test data processing
            demo_results['tests_performed'].append('data_processing')
            sample_data = self.get_demo_data()['sample_data']
            processed_data = self.data_plugin.execute_pipeline('user_data_processing', sample_data)
            pipeline_stats = self.data_plugin.get_pipeline_stats()
            demo_results['results']['data_processing'] = {
                'original_count': len(sample_data),
                'processed_count': len(processed_data),
                'processed_data': processed_data[:2],  # Show first 2 results
                'pipeline_stats': pipeline_stats
            }
            
            # Test UI enhancements
            demo_results['tests_performed'].append('ui_enhancements')
            ui_results = {
                'theme_set': self.ui_plugin.set_theme('dark'),
                'notification_shown': self.ui_plugin.show_notification('Demo', 'Plugin demonstration running', 'normal'),
                'notifications_count': len(self.ui_plugin.get_notifications())
            }
            demo_results['results']['ui_enhancements'] = ui_results
            
            # Test automation
            demo_results['tests_performed'].append('automation')
            automation_results = {
                'workflow_executed': self.automation_plugin.execute_workflow('daily_intelligence'),
                'workflow_stats': self.automation_plugin.get_workflow_stats()
            }
            demo_results['results']['automation'] = automation_results
            
            # Test learning
            demo_results['tests_performed'].append('learning')
            sample_texts = self.get_demo_data()['sample_texts']
            learning_results = {
                'sentiment_predictions': self.learning_plugin.predict('sentiment', sample_texts[:2]),
                'spam_predictions': self.learning_plugin.predict('spam_detection', sample_texts[3:5]),
                'classification_predictions': self.learning_plugin.predict('text_classification', sample_texts[4:6]),
                'available_models': self.learning_plugin.list_models()
            }
            demo_results['results']['learning'] = learning_results
            
            # Test inter-plugin communication
            demo_results['tests_performed'].append('communication')
            self.architecture.communication_hub.broadcast_message(
                self.plugin_id, 'demo_event', {'message': 'Comprehensive demo running'}
            )
            demo_results['results']['communication'] = {'status': 'broadcast_sent'}
            
            self.logger.info("Comprehensive demo completed successfully")
            
        except Exception as e:
            error_msg = f"Demo error: {str(e)}"
            demo_results['errors'].append(error_msg)
            self.logger.error(error_msg)
        
        return demo_results
    
    def shutdown(self):
        """Shutdown all example plugins"""
        try:
            # Shutdown individual plugins
            if hasattr(self, 'voice_plugin'):
                self.voice_plugin.shutdown()
            if hasattr(self, 'api_plugin'):
                self.api_plugin.shutdown()
            if hasattr(self, 'data_plugin'):
                self.data_plugin.shutdown()
            if hasattr(self, 'ui_plugin'):
                self.ui_plugin.shutdown()
            if hasattr(self, 'automation_plugin'):
                self.automation_plugin.shutdown()
            if hasattr(self, 'learning_plugin'):
                self.learning_plugin.shutdown()
            
            super().shutdown()
            
        except Exception as e:
            self.logger.error(f"Error during example plugin suite shutdown: {e}")
    
    def get_capabilities(self):
        """Get complete plugin capabilities"""
        return [
            'voice_commands', 'api_integration', 'data_processing',
            'ui_enhancements', 'automation', 'machine_learning',
            'comprehensive_demo', 'multi_plugin_suite'
        ]
    
    def handle_command(self, command: str, args: list):
        """Handle commands and route to appropriate sub-plugin"""
        if command == 'demo':
            return self.run_comprehensive_demo()
        elif command == 'get_demo_data':
            return self.get_demo_data()
        elif command == 'voice':
            sub_command = args[0] if args else 'help'
            sub_args = args[1:] if len(args) > 1 else []
            return self.voice_plugin.handle_command(sub_command, sub_args)
        elif command == 'api':
            sub_command = args[0] if args else 'help'
            sub_args = args[1:] if len(args) > 1 else []
            return self.api_plugin.handle_command(sub_command, sub_args)
        elif command == 'data':
            sub_command = args[0] if args else 'help'
            sub_args = args[1:] if len(args) > 1 else []
            return self.data_plugin.handle_command(sub_command, sub_args)
        elif command == 'ui':
            sub_command = args[0] if args else 'help'
            sub_args = args[1:] if len(args) > 1 else []
            return self.ui_plugin.handle_command(sub_command, sub_args)
        elif command == 'automation':
            sub_command = args[0] if args else 'help'
            sub_args = args[1:] if len(args) > 1 else []
            return self.automation_plugin.handle_command(sub_command, sub_args)
        elif command == 'learning':
            sub_command = args[0] if args else 'help'
            sub_args = args[1:] if len(args) > 1 else []
            return self.learning_plugin.handle_command(sub_command, sub_args)
        else:
            return "Available sub-commands: demo, voice, api, data, ui, automation, learning"
    
    def handle_message(self, message: dict):
        """Handle messages from other plugins"""
        message_type = message.get('type')
        data = message.get('data')
        
        if message_type == 'demo_event':
            self.logger.info(f"Received demo event: {data}")
        elif message_type == 'ping':
            self.architecture.communication_hub.send_message(
                self.plugin_id, message.get('sender'), 'pong', {'plugin': 'ExamplePluginSuite'}
            )


# Plugin identification
BasePlugin._is_jarvis_plugin = staticmethod(lambda: True)

if __name__ == "__main__":
    # Test the example plugin suite
    print("JARVIS v11 Example Plugin Suite Test")
    print("=" * 50)
    
    # Mock architecture for testing
    class MockArchitecture:
        def __init__(self):
            self.logger = self
        
        def info(self, msg): print(f"INFO: {msg}")
        def error(self, msg): print(f"ERROR: {msg}")
        def warning(self, msg): print(f"WARNING: {msg}")
        
        class CommunicationHub:
            def broadcast_message(self, sender, message_type, data):
                print(f"BROADCAST: {sender} -> {message_type}: {data}")
    
    try:
        # Create mock architecture
        mock_arch = MockArchitecture()
        
        # Create and test plugin suite
        plugin_suite = ExamplePluginSuite(mock_arch)
        
        if plugin_suite.initialize():
            print("✓ Example Plugin Suite initialized successfully")
            
            # Run comprehensive demo
            demo_results = plugin_suite.run_comprehensive_demo()
            print(f"✓ Comprehensive demo completed: {len(demo_results['tests_performed'])} tests performed")
            
            # Test individual capabilities
            demo_data = plugin_suite.get_demo_data()
            print(f"✓ Demo data generated: {len(demo_data)} categories")
            
            # Test command handling
            voice_result = plugin_suite.handle_command('voice', ['time'])
            print(f"✓ Voice command test: {voice_result}")
            
            api_result = plugin_suite.handle_command('api', ['quote'])
            print(f"✓ API test: Quote fetched successfully")
            
            data_result = plugin_suite.handle_command('data', ['pipeline_stats'])
            print(f"✓ Data processing test: Pipeline stats retrieved")
            
            print("\n" + "=" * 50)
            print("Example Plugin Suite test completed successfully!")
            print("All plugin types demonstrated:")
            print("- Voice Commands: ✓")
            print("- API Integration: ✓")
            print("- Data Processing: ✓")
            print("- UI Enhancements: ✓")
            print("- Automation: ✓")
            print("- Machine Learning: ✓")
            
        else:
            print("✗ Failed to initialize Example Plugin Suite")
        
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        if 'plugin_suite' in locals():
            plugin_suite.shutdown()