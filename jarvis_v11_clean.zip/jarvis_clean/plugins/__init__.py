#!/usr/bin/env python3
"""
JARVIS v11 Plugin System
Plugin directory for dynamic plugin loading
"""

__version__ = "1.0.0"