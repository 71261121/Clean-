"""
JARVIS v11 - Configuration Settings
Secure and optimized for Termux
"""

import os
import json
from pathlib import Path
from typing import Dict, Any

class JarvisConfig:
    """JARVIS v11 configuration management"""
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path or self._get_default_config_path()
        self.config = self._load_config()
    
    def _get_default_config_path(self) -> str:
        """Get default configuration path"""
        home = Path.home()
        jarvis_dir = home / "jarvis_v11" / "config"
        return str(jarvis_dir / "settings.json")
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        config_path = Path(self.config_path)
        
        # Default configuration
        default_config = {
            "version": "11.0.0",
            "author": "MiniMax Agent",
            
            # API Keys (must be set via environment variables)
            "api_keys": {
                "openrouter_api_key": "ENV_REQUIRED",
                "github_token": "ENV_OPTIONAL", 
                "news_api_key": "ENV_OPTIONAL",
                "weather_api_key": "ENV_OPTIONAL"
            },
            
            # Feature toggles
            "features": {
                "enable_ai": True,
                "enable_world_data": True,
                "enable_github_integration": True,
                "enable_termux_controller": True,
                "enable_code_analysis": True,
                "enable_auto_improvement": True,
                "enable_background_monitoring": True,
                "enable_database_logging": True
            },
            
            # Performance settings
            "performance": {
                "max_concurrent_tasks": 3,
                "cache_timeout_seconds": 300,
                "api_timeout_seconds": 30,
                "max_memory_usage_mb": 500,
                "max_file_analysis_size_mb": 10,
                "background_monitoring_interval": 60
            },
            
            # Safety settings
            "safety": {
                "require_confirmation": True,
                "block_dangerous_commands": True,
                "dangerous_command_timeout": 5,
                "max_command_execution_time": 30,
                "enable_code_sandboxing": True,
                "backup_before_modifications": True
            },
            
            # Termux specific settings
            "termux": {
                "termux_api_required": True,
                "auto_setup_storage": True,
                "enable_notifications": True,
                "battery_optimization": True,
                "low_memory_mode": False,
                "prefer_lightweight_apis": True
            },
            
            # UI settings
            "ui": {
                "theme": "dark",
                "color_output": True,
                "verbose_logging": False,
                "show_banner": True,
                "interactive_mode": True
            },
            
            # Database settings
            "database": {
                "auto_backup": True,
                "backup_interval_hours": 24,
                "max_backup_files": 7,
                "cleanup_old_data_days": 30,
                "optimize_on_startup": True
            },
            
            # Logging settings
            "logging": {
                "level": "INFO",
                "file_logging": True,
                "console_logging": True,
                "max_log_file_size_mb": 10,
                "log_retention_days": 7,
                "log_format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            }
        }
        
        # Load from file if exists
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    file_config = json.load(f)
                    # Merge with defaults (file takes precedence)
                    default_config.update(file_config)
            except Exception as e:
                print(f"Warning: Could not load config file: {e}")
                print("Using default configuration")
        
        return default_config
    
    def save_config(self):
        """Save configuration to file"""
        config_path = Path(self.config_path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            with open(config_path, 'w') as f:
                json.dump(self.config, f, indent=4)
            print(f"Configuration saved to {self.config_path}")
        except Exception as e:
            print(f"Error saving configuration: {e}")
    
    def get(self, key: str, default=None):
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        # Navigate to parent dict
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        # Set the value
        config[keys[-1]] = value
    
    def is_feature_enabled(self, feature_name: str) -> bool:
        """Check if a feature is enabled"""
        return self.get(f"features.enable_{feature_name}", False)
    
    def get_api_key(self, key_name: str) -> str:
        """Get API key from environment or config"""
        env_mapping = {
            "openrouter_api_key": "OPENROUTER_API_KEY",
            "github_token": "GITHUB_TOKEN",
            "news_api_key": "NEWS_API_KEY", 
            "weather_api_key": "WEATHER_API_KEY"
        }
        
        # Try environment variable first
        env_var = env_mapping.get(key_name)
        if env_var and os.getenv(env_var):
            return os.getenv(env_var)
        
        # Fall back to config (but warn about security)
        config_value = self.get(f"api_keys.{key_name}")
        if config_value and config_value != "ENV_REQUIRED" and config_value != "ENV_OPTIONAL":
            print(f"Warning: API key found in config file. Consider using environment variable {env_var}")
            return config_value
        
        return None
    
    def validate_config(self) -> Dict[str, Any]:
        """Validate configuration and return any issues"""
        issues = []
        warnings = []
        
        # Check required API keys
        openrouter_key = self.get_api_key("openrouter_api_key")
        if not openrouter_key:
            issues.append("OPENROUTER_API_KEY environment variable is required for AI functionality")
        
        # Check Termux API availability
        if self.get("termux.termux_api_required"):
            try:
                import subprocess
                result = subprocess.run(['termux-api', '--help'], 
                                      capture_output=True, timeout=5)
                if result.returncode != 0:
                    warnings.append("termux-api not found. Install with: pkg install termux-api")
            except Exception:
                warnings.append("termux-api check failed. Install with: pkg install termux-api")
        
        # Check memory limits
        max_memory = self.get("performance.max_memory_usage_mb")
        if max_memory > 1000:
            warnings.append(f"High memory limit ({max_memory}MB) may cause performance issues on mobile")
        
        # Check dangerous command settings
        if not self.get("safety.block_dangerous_commands"):
            issues.append("Dangerous command blocking is disabled - this is not recommended")
        
        # Check performance settings
        concurrent_tasks = self.get("performance.max_concurrent_tasks")
        if concurrent_tasks > 5:
            warnings.append(f"High concurrent task limit ({concurrent_tasks}) may impact mobile performance")
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "warnings": warnings
        }
    
    def create_example_config(self, output_path: str = None):
        """Create an example configuration file"""
        if not output_path:
            output_path = self.config_path + ".example"
        
        # Create example config with placeholder values
        example_config = self.config.copy()
        
        # Set example API keys
        example_config["api_keys"]["openrouter_api_key"] = "your_openrouter_api_key_here"
        example_config["api_keys"]["github_token"] = "your_github_token_here"
        example_config["api_keys"]["news_api_key"] = "your_news_api_key_here"
        example_config["api_keys"]["weather_api_key"] = "your_weather_api_key_here"
        
        try:
            with open(output_path, 'w') as f:
                json.dump(example_config, f, indent=4)
            print(f"Example configuration created at {output_path}")
            print("Copy this file to your config directory and update with your API keys")
        except Exception as e:
            print(f"Error creating example config: {e}")

# Global configuration instance
config = JarvisConfig()

# Quick access functions
def get_config(key: str, default=None):
    """Get configuration value"""
    return config.get(key, default)

def set_config(key: str, value: Any):
    """Set configuration value"""
    config.set(key, value)

def is_feature_enabled(feature: str) -> bool:
    """Check if feature is enabled"""
    return config.is_feature_enabled(feature)

def get_api_key(key_name: str) -> str:
    """Get API key"""
    return config.get_api_key(key_name)

def validate_configuration() -> Dict[str, Any]:
    """Validate current configuration"""
    return config.validate_config()

if __name__ == "__main__":
    # CLI interface for config management
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python config.py [validate|create-example|show]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "validate":
        result = validate_configuration()
        print(f"Configuration valid: {result['valid']}")
        if result['issues']:
            print("Issues:")
            for issue in result['issues']:
                print(f"  ❌ {issue}")
        if result['warnings']:
            print("Warnings:")
            for warning in result['warnings']:
                print(f"  ⚠️ {warning}")
    
    elif command == "create-example":
        config.create_example_config()
    
    elif command == "show":
        print("Current configuration:")
        print(json.dumps(config.config, indent=2))
    
    else:
        print(f"Unknown command: {command}")
        print("Available commands: validate, create-example, show")