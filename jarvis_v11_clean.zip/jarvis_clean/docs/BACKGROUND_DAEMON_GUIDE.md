# JARVIS v11 Enhanced - Background Daemon System

## Overview

The JARVIS v11 Background Daemon is a robust, mobile-optimized background service designed specifically for Termux environments. It provides always-running services, task queuing, system monitoring, and seamless Android integration.

## Features

### 🎯 Core Features
- **Always-Running Service**: Persistent background process with auto-restart
- **Priority-Based Task Queue**: Efficient task scheduling and execution
- **Resource-Efficient Monitoring**: Low battery usage with smart scheduling
- **Auto-start on Boot**: Termux-boot integration for seamless startup
- **System Integration**: Android intent handling and battery optimization
- **Crash Recovery**: Automatic restart with health monitoring
- **Notification System**: Important event alerts and status updates

### 🔧 Technical Features
- **Asyncio-based**: Concurrent background task processing
- **Signal Handling**: Graceful shutdown and restart capabilities
- **State Persistence**: Survives crashes and system reboots
- **Health Monitoring**: Continuous system health assessment
- **Mobile Optimizations**: Battery-aware scheduling and low-memory handling
- **Termux Native**: Built specifically for Termux environment

## Architecture

```
JARVIS v11 Background Daemon
├── Core Components
│   ├── TaskQueue (Priority-based task management)
│   ├── SystemMonitor (Resource monitoring)
│   ├── NotificationService (Event notifications)
│   ├── StateManager (Persistent state)
│   └── BackgroundServices (Service management)
├── Integration
│   ├── Termux-boot (Auto-start)
│   ├── Health Monitor (Crash recovery)
│   └── Android APIs (System integration)
└── Background Services
    ├── Health Check Service
    ├── Battery Monitor Service
    ├── Repository Monitor Service
    └── Cleanup Service
```

## Installation & Setup

### 1. Install Dependencies

```bash
cd /data/data/com.termux/files/home/jarvis_v11
pip install -r requirements_termux_optimized.txt
```

### 2. Setup Termux Boot Integration

```bash
# Method 1: Using daemon setup command
python3 core/background_daemon.py setup-boot

# Method 2: Manual setup
cp termux-boot/termux-start.sh /data/data/com.termux/files/home/.termux/boot/
chmod +x /data/data/com.termux/files/home/.termux/boot/termux-start.sh
```

### 3. Install Termux API (Optional)

```bash
pkg install -y termux-api
```

### 4. Test Installation

```bash
# Run comprehensive tests
python3 core/daemon_tester.py

# Quick test
python3 core/daemon_tester.py quick
```

## Usage

### Starting the Daemon

```bash
# Start daemon manually
python3 core/background_daemon.py

# Start via termux-boot (automatic on boot)
# The daemon will automatically start when device boots if termux-boot is enabled
```

### Daemon Commands

```bash
# Check daemon status
python3 core/background_daemon.py status

# Add a background task
python3 core/background_daemon.py add-task "Task Name" "function_name"

# Setup boot integration
python3 core/background_daemon.py setup-boot

# Remove boot integration
python3 core/background_daemon.py remove-boot
```

### Boot Integration Management

```bash
# Check boot script
/data/data/com.termux/files/home/.termux/boot/jarvis-start.sh check

# View boot logs
/data/data/com.termux/files/home/.termux/boot/jarvis-start.sh logs

# Manual daemon restart
/data/data/com.termux/files/home/.termux/boot/jarvis-start.sh restart
```

### Health Monitoring

```bash
# Monitor daemon health
python3 core/health_monitor.py

# Check daemon health
python3 core/health_monitor.py status

# Restart daemon via health monitor
python3 core/health_monitor.py restart
```

## Task Management

### Adding Background Tasks

```python
# Import the daemon
import asyncio
import sys
sys.path.append('/data/data/com.termux/files/home/jarvis_v11')

from core.background_daemon import BackgroundDaemon, TaskPriority

# Create and add a task
async def add_task():
    daemon = BackgroundDaemon()
    
    task_id = daemon.add_background_task(
        name="My Background Task",
        function="my_function",
        priority=TaskPriority.NORMAL,
        args=("arg1", "arg2"),
        kwargs={"option": "value"}
    )
    
    print(f"Task added with ID: {task_id}")

# Run the function
asyncio.run(add_task())
```

### Task Priority Levels

```python
from core.background_daemon import TaskPriority

# Available priorities (1 = highest, 5 = lowest)
TaskPriority.CRITICAL    # System critical tasks
TaskPriority.HIGH        # High priority user tasks
TaskPriority.NORMAL      # Regular background tasks (default)
TaskPriority.LOW         # Low priority maintenance tasks
TaskPriority.IDLE        # Tasks to run when system is idle
```

### Task Function Examples

```python
# Define task functions in background_daemon.py
async def _run_task_function(self, task):
    if task.function == "check_email":
        await self._check_email()
    elif task.function == "sync_data":
        await self._sync_data()
    elif task.function == "cleanup_files":
        await self._cleanup_files()

async def _check_email(self):
    # Your email checking logic here
    logger.info("Checking emails...")
    # Implementation here

async def _sync_data(self):
    # Your data synchronization logic here
    logger.info("Syncing data...")
    # Implementation here

async def _cleanup_files(self):
    # Your file cleanup logic here
    logger.info("Cleaning up files...")
    # Implementation here
```

## System Monitoring

### Battery-Aware Scheduling

The daemon automatically adapts to battery conditions:

- **Low Battery (<15%)**: Reduces background activity
- **Charging**: Allows normal activity levels
- **High Temperature**: Reduces CPU-intensive tasks
- **Background Restricted**: Pauses non-critical tasks

### Resource Monitoring

```python
# Get current system status
daemon = BackgroundDaemon()
status = daemon.get_status()

print(f"Battery: {status['battery_status']['battery_level']}%")
print(f"Memory Usage: {status['system_state']['memory_usage']:.1f}%")
print(f"Health Score: {status['health_score']}/100")
```

### Health Score Calculation

The daemon calculates a health score based on:
- CPU usage (< 50% = good, > 80% = poor)
- Memory usage (< 75% = good, > 90% = poor)
- Disk usage (< 85% = good, > 95% = poor)
- System temperature (< 40°C = good, > 45°C = poor)
- Background restrictions (no restrictions = good)
- Network connectivity (connected = good)

## Configuration

### Daemon Configuration

Edit `/data/data/com.termux/files/home/jarvis_v11/data/daemon_state.json`:

```json
{
  "max_concurrent_tasks": 3,
  "task_timeout": 300,
  "health_check_interval": 300,
  "enable_notifications": true,
  "enable_auto_restart": true,
  "battery_saver_mode": false,
  "notification_preferences": {
    "low_battery_alerts": true,
    "crash_alerts": true,
    "health_alerts": true
  }
}
```

### Health Monitor Configuration

Edit `/data/data/com.termux/files/home/jarvis_v11/config/health_monitor.json`:

```json
{
  "crash_threshold": 5,
  "health_check_interval": 60,
  "restart_delay": 30,
  "max_memory_usage": 80,
  "enable_auto_restart": true,
  "enable_notifications": true,
  "enable_cleanup": true,
  "health_score_threshold": 70
}
```

## Troubleshooting

### Common Issues

#### 1. Daemon Not Starting

```bash
# Check logs
tail -f /data/data/com.termux/files/home/jarvis_v11/logs/daemon.log

# Check if port is already in use
lsof -i :8080

# Check permissions
ls -la /data/data/com.termux/files/home/jarvis_v11/core/background_daemon.py
```

#### 2. Termux-boot Not Working

```bash
# Check if termux-boot is installed
pkg list-installed | grep termux-boot

# Install termux-boot
pkg install termux-boot

# Check boot directory permissions
ls -la /data/data/com.termux/files/home/.termux/boot/

# Make script executable
chmod +x /data/data/com.termux/files/home/.termux/boot/termux-start.sh
```

#### 3. Battery Optimization Issues

```bash
# Check if app is restricted
dumpsys package com.termux | grep restricted

# Disable battery optimization manually:
# 1. Go to Android Settings
# 2. Apps & notifications
# 3. Termux
# 4. Battery
# 5. Disable "Battery optimization"
```

#### 4. High Memory Usage

```bash
# Check daemon memory usage
ps aux | grep background_daemon

# Monitor memory over time
python3 core/health_monitor.py status

# Clear system cache
sync
echo 3 > /proc/sys/vm/drop_caches
```

#### 5. Notification Issues

```bash
# Check if termux-notification is available
which termux-notification

# Test notification
termux-notification --title "Test" --content "Test message"

# Check notification permissions in Android settings
```

### Debug Commands

```bash
# View real-time daemon logs
tail -f /data/data/com.termux/files/home/jarvis_v11/logs/daemon.log

# Check daemon process
ps aux | grep background_daemon

# Check system resources
free -h
df -h
cat /proc/loadavg

# Test daemon functionality
python3 core/daemon_tester.py

# Check boot integration
/data/data/com.termux/files/home/.termux/boot/termux-start.sh check

# Manual daemon restart
python3 core/health_monitor.py restart
```

### Log Files

- `daemon.log` - Main daemon logs
- `health_monitor.log` - Health monitoring logs
- `boot.log` - Boot startup logs
- `daemon_test_report.txt` - Test results

## Performance Optimization

### Battery Optimization Tips

1. **Reduce Check Intervals**: Increase `health_check_interval` in config
2. **Limit Concurrent Tasks**: Set `max_concurrent_tasks` to 1 or 2
3. **Enable Battery Saver**: Set `battery_saver_mode: true`
4. **Disable Non-essential Services**: Comment out unused services

### Memory Optimization

1. **Regular Cleanup**: Enable automatic log cleanup
2. **Limit History**: Set max health history size
3. **Task Timeouts**: Set appropriate task timeouts
4. **Monitor Usage**: Regular health checks

### Network Optimization

1. **Batch Operations**: Combine multiple network requests
2. **Retry Logic**: Implement exponential backoff
3. **Offline Mode**: Handle network unavailability
4. **Data Compression**: Use compression for large transfers

## Integration Examples

### GitHub Integration

```python
# Add GitHub monitoring task
daemon.add_background_task(
    name="GitHub Repository Check",
    function="check_repository_updates",
    priority=TaskPriority.NORMAL,
    timeout=600  # 10 minutes
)
```

### Email Integration

```python
# Add email checking task
daemon.add_background_task(
    name="Email Check",
    function="check_email",
    priority=TaskPriority.HIGH,
    schedule_interval=300  # 5 minutes
)
```

### File Synchronization

```python
# Add file sync task
daemon.add_background_task(
    name="File Sync",
    function="sync_files",
    priority=TaskPriority.NORMAL,
    dependencies=["network_check"]
)
```

## Security Considerations

### File Permissions

```bash
# Set secure permissions
chmod 750 /data/data/com.termux/files/home/jarvis_v11/core/background_daemon.py
chmod 640 /data/data/com.termux/files/home/jarvis_v11/data/daemon_state.json
```

### Process Isolation

The daemon runs as a separate process with limited permissions:
- No root access required
- Isolated file system access
- Controlled network access
- Limited system resource usage

### Data Encryption

Sensitive data in state files is automatically encrypted:
- Task data encryption
- Secure state storage
- Encrypted log files (optional)

## Advanced Features

### Custom Services

```python
# Extend BackgroundServices class
class CustomServices(BackgroundServices):
    async def _custom_service(self):
        while self._running:
            # Your custom service logic
            await asyncio.sleep(60)

# Add to daemon
daemon.background_services = CustomServices(...)
```

### Plugin System

```python
# Create task plugins
class TaskPlugin:
    def __init__(self, daemon):
        self.daemon = daemon
    
    def register_tasks(self):
        self.daemon.add_background_task(
            name="Plugin Task",
            function="plugin_function",
            priority=TaskPriority.NORMAL
        )
    
    async def plugin_function(self):
        # Plugin implementation
        pass

# Load plugin
plugin = TaskPlugin(daemon)
plugin.register_tasks()
```

## Contributing

### Development Setup

```bash
# Clone repository
git clone <repository-url>
cd jarvis_v11

# Install development dependencies
pip install -r requirements_termux_optimized.txt

# Run tests
python3 core/daemon_tester.py

# Run linting
flake8 core/
black core/
```

### Adding New Features

1. Create feature branch
2. Implement functionality
3. Add tests
4. Update documentation
5. Submit pull request

## Support

### Getting Help

1. Check logs first: `/data/data/com.termux/files/home/jarvis_v11/logs/`
2. Run diagnostic tools: `python3 core/daemon_tester.py`
3. Check system resources: `python3 core/health_monitor.py status`
4. Review this documentation
5. Create issue with logs and system info

### Log Analysis

```bash
# Analyze daemon logs
grep "ERROR" /data/data/com.termux/files/home/jarvis_v11/logs/daemon.log
grep "WARNING" /data/data/com.termux/files/home/jarvis_v11/logs/daemon.log
tail -100 /data/data/com.termux/files/home/jarvis_v11/logs/daemon.log
```

### System Information

```bash
# Gather system info for bug reports
echo "=== System Info ===" > debug_info.txt
uname -a >> debug_info.txt
free -h >> debug_info.txt
df -h >> debug_info.txt
python3 --version >> debug_info.txt
pip list | grep -E "(asyncio|psutil|aiohttp)" >> debug_info.txt

# Include daemon status
python3 core/background_daemon.py status >> debug_info.txt
```

---

**JARVIS v11 Enhanced Background Daemon System**
*Mobile-optimized, battery-aware, always-running service for Termux environments*

**Version**: 1.0.0  
**Last Updated**: 2025-01-01  
**Compatibility**: Termux (Android) | Python 3.8+