# JARVIS v11 Enhanced - Notification System Guide

## Overview

JARVIS v11 Enhanced में एक advanced notification system है जो Termux environment में native Android notifications भेजता है। यह system battery-optimized है और smartphone पर efficient काम करता है।

## Features

### 🔔 Core Features
- **Termux Notification API Integration** - Native Android notifications
- **Priority-based Queue System** - Critical alerts को priority मिलती है
- **Rich Content Support** - Text, images, actions, progress bars
- **Notification History** - SQLite database के साथ persistent storage
- **Smart Filtering** - Spam filtering और quiet hours support

### 📱 Mobile Optimizations
- **Battery Efficient** - Background processing optimization
- **Non-root Compatible** - Termux में full support
- **Permission Management** - Android notification permissions का सही उपयोग
- **Auto-dismiss** - Irrelevant notifications को automatically remove करता है

### 🎯 Notification Types
- **System Alerts** - Battery, storage, system status
- **JARVIS Status** - Voice commands, startup/shutdown updates
- **GitHub Integration** - Repository updates, learning progress
- **Error Alerts** - Critical errors, system failures
- **Progress Updates** - Long-running operations tracking
- **Voice Commands** - Voice command confirmations

## Installation & Setup

### Prerequisites
```bash
# Update Termux packages
pkg update && pkg upgrade

# Install required packages
pkg install python

# Verify termux-notification is available
termux-notification --help
```

### JARVIS Integration
```python
# Import notification system
from core.notification_system import NotificationSystem

# Initialize system
notification_system = NotificationSystem()

# Send your first notification
notification_id = notification_system.send_notification(
    title="JARVIS Alert",
    message="Welcome to JARVIS v11 Enhanced!",
    priority=NotificationPriority.NORMAL
)
```

## Quick Start Guide

### Basic Notifications

```python
from core.notification_system import (
    NotificationSystem,
    NotificationPriority,
    NotificationType
)

# Initialize
system = NotificationSystem()

# Send simple notification
system.send_notification(
    title="Hello JARVIS",
    message="System initialized successfully",
    priority=NotificationPriority.NORMAL
)
```

### System Alerts

```python
# Critical system alert
system.send_system_alert(
    title="Battery Status",
    message="Battery level is below 15%",
    critical=True  # Critical priority
)

# Normal system alert
system.send_system_alert(
    title="Storage Warning",
    message="Storage space is getting low"
)
```

### JARVIS Status Updates

```python
# Startup notification
system.send_jarvis_status(
    status="Starting Up",
    details="Initializing voice recognition modules"
)

# Voice command confirmation
system.send_voice_command_confirmation(
    command="Open settings",
    success=True  # True for success, False for failure
)
```

### Progress Notifications

```python
# Show progress
notification_id = system.send_progress_notification(
    task="Data Loading",
    progress=75,  # Current progress
    total=100     # Total expected
)

# Update progress
system.send_progress_notification(
    task="Data Loading",
    progress=90,
    total=100
)
```

## Advanced Features

### Rich Content Notifications

```python
from core.notification_system import NotificationAction, NotificationContent

# Create action buttons
open_action = NotificationAction(
    id="open_jarvis",
    title="Open JARVIS",
    command="jarvis_start"
)

dismiss_action = NotificationAction(
    id="dismiss",
    title="Dismiss"
)

# Create rich content
content = NotificationContent(
    title="JARVIS Ready",
    message="Click to open JARVIS interface",
    icon="jarvis",
    actions=[open_action, dismiss_action],
    sound="notification_sound.wav",
    vibration=True,
    led_color="#00FF00"  # Green LED
)

# Send notification
system.send_notification(
    title="JARVIS Ready",
    message="Click to open JARVIS interface",
    priority=NotificationPriority.NORMAL
)
```

### Notification Actions

```python
# Create interactive notification
system.send_notification(
    title="Update Available",
    message="JARVIS v11.1 update ready",
    priority=NotificationPriority.HIGH,
    actions=[
        NotificationAction("update", "Update Now"),
        NotificationAction("later", "Later")
    ]
)
```

### Battery Optimization

```python
# Enable/disable battery optimization
system.enable_battery_optimization(True)

# Enable/disable quiet hours (10 PM - 8 AM)
system.enable_quiet_hours(True)

# Add custom filter rules
system.add_filter_rule(
    pattern="progress",
    priority_min=NotificationPriority.LOW,
    persistent=False
)
```

## Notification Priorities

| Priority | Usage | Example |
|----------|-------|---------|
| **CRITICAL** | System failures, urgent alerts | "System overheating - Shutting down" |
| **HIGH** | Important alerts | "Battery low", "Network disconnected" |
| **NORMAL** | Regular notifications | "Voice command received", "JARVIS status" |
| **LOW** | Background updates | "Progress updates", "Status refreshes" |

## Notification Types

### System Alerts
```python
# System alert with persistence
system.send_system_alert(
    title="Memory Critical",
    message="System memory critically low",
    critical=True
)
```

### GitHub Integration
```python
# GitHub notification
system.send_github_notification(
    title="New Learning Available",
    message="5 new repositories to learn from",
    repository="machine-learning"
)
```

### Error Alerts
```python
# Error notification
system.send_error_alert(
    error_message="Voice recognition failed",
    context="Voice command processing"
)
```

## Database Operations

### Get Notification History
```python
# Get recent notifications
history = system.get_notification_history(limit=50)

# Filter by priority
high_priority = system.get_notification_history(
    priority=NotificationPriority.HIGH
)

# Filter by type
voice_commands = system.get_notification_history(
    type_filter=NotificationType.VOICE_COMMAND
)

# Get filtered notifications only
filtered = system.get_notification_history(filtered_only=True)
```

### Clear History
```python
# Clear all non-persistent notifications
cleared_count = system.clear_notification_history()

# Clear notifications older than 7 days
cleared_count = system.clear_notification_history(days=7)
```

## System Status

### Monitor System Health
```python
# Get system status
status = system.get_system_status()

print(f"Termux Available: {status['termux_available']}")
print(f"Queue Size: {status['queue_size']}")
print(f"Database Size: {status['database_size']} bytes")
print(f"Battery Optimization: {status['battery_optimization']}")
```

## Convenience Functions

```python
from core.notification_system import (
    send_alert,
    send_status_update,
    send_error,
    send_progress
)

# Simple alert
send_alert("Test Alert", "This is a test notification")

# Status update
send_status_update("Connected", "Voice module active")

# Error notification
send_error("Connection failed", "Network timeout")

# Progress update
send_progress("Loading", 50, 100)
```

## Real-World Examples

### JARVIS Startup Sequence
```python
def notify_jarvis_startup():
    # JARVIS starting notification
    system.send_jarvis_status(
        "JARVIS v11 Starting",
        "Initializing all systems..."
    )
    
    # Module loading progress
    for module, progress in [
        ("Voice Recognition", 25),
        ("GitHub Integration", 50),
        ("Database Manager", 75),
        ("Self-Modifying Engine", 100)
    ]:
        system.send_progress_notification(
            task=f"Loading {module}",
            progress=progress,
            total=100
        )
        time.sleep(2)
    
    # Ready notification
    system.send_jarvis_status(
        "JARVIS Ready",
        "All systems operational"
    )
```

### Battery Monitoring
```python
def monitor_battery():
    battery_level = get_battery_level()
    
    if battery_level < 10:
        system.send_system_alert(
            "Critical Battery",
            f"Battery at {battery_level}%. Please charge immediately!",
            critical=True
        )
    elif battery_level < 20:
        system.send_system_alert(
            "Low Battery",
            f"Battery at {battery_level}%. Consider charging soon."
        )
```

### Voice Command Flow
```python
def handle_voice_command(command_text):
    # Processing notification
    system.send_notification(
        "Voice Command Processing",
        f"Processing: '{command_text}'",
        type=NotificationType.VOICE_COMMAND
    )
    
    try:
        # Process command
        success = process_command(command_text)
        
        # Success/failure confirmation
        system.send_voice_command_confirmation(
            command_text,
            success=success
        )
        
    except Exception as e:
        system.send_error_alert(
            error_message=str(e),
            context=f"Voice command: {command_text}"
        )
```

### GitHub Integration Notifications
```python
def notify_github_update():
    # New learning repositories
    system.send_github_notification(
        "New Learning Content",
        "3 new Python repositories available",
        repository="python-learning"
    )
    
    # Progress updates
    system.send_progress_notification(
        task="Syncing GitHub Data",
        progress=75,
        total=100
    )
```

## Configuration Options

### Notification Queue Settings
```python
# Initialize with custom settings
system = NotificationSystem(
    data_dir="/data/data/com.termux/files/home/.jarvis/data",
    max_queue_size=100,        # Max notifications in queue
    max_history_days=30        # Keep history for 30 days
)
```

### Filter Customization
```python
# Add spam patterns
system.filter.spam_patterns.append("test notification")

# Add custom filter rules
system.add_filter_rule(
    pattern="background_update",
    priority_min=NotificationPriority.LOW,
    persistent=False
)

# Remove filter rules
system.remove_filter_rule("background_update")
```

## Termux-Specific Features

### Permission Handling
```python
# Check if Termux notifications are available
if TermuxNotificationAPI.is_available():
    print("Termux notification API available")
else:
    print("Termux notification API not found")
```

### Native Android Integration
```python
# Rich notifications with native Android features
system.send_notification(
    title="JARVIS Alert",
    message="This is a native Android notification",
    priority=NotificationPriority.NORMAL,
    icon="ic_notification",           # Android icon resource
    sound="notification_sound.wav",   # Custom sound
    vibration=True,                   # Enable vibration
    led_color="#FF0000",             # Red LED for critical
    group="jarvis_group",             # Group related notifications
    thread_id="jarvis_thread"         # Thread for conversation
)
```

## Troubleshooting

### Common Issues

#### 1. Notifications Not Appearing
```bash
# Check Termux notification API
termux-notification --help

# Check Termux permissions
termux-setup-storage

# Verify notification permissions in Android Settings
```

#### 2. Database Errors
```python
# Check system status
status = system.get_system_status()
print(f"Database size: {status['database_size']} bytes")

# Clear corrupted database
system.clear_notification_history()
```

#### 3. Queue Overflow
```python
# Check queue size
status = system.get_system_status()
print(f"Queue size: {status['queue_size']}")

# Clear queue manually
system.clear_notification_history()
```

#### 4. Battery Optimization Issues
```python
# Check battery optimization status
print(f"Battery optimization: {system.battery_optimization}")

# Disable if causing issues
system.enable_battery_optimization(False)
```

### Debug Mode
```python
# Enable verbose logging
import logging
logging.basicConfig(level=logging.DEBUG)

# Check notification delivery
status = system.get_system_status()
print(f"Delivery status tracking: {status}")
```

### Performance Monitoring
```python
# Monitor notification performance
import time

start_time = time.time()
notification_id = system.send_notification(
    title="Performance Test",
    message="Testing notification speed"
)
end_time = time.time()

print(f"Notification time: {end_time - start_time:.2f} seconds")
```

## Best Practices

### 1. Battery Optimization
- Use `LOW` priority for frequent updates
- Enable quiet hours (10 PM - 8 AM)
- Set auto-dismiss for non-critical notifications
- Use progress notifications sparingly

### 2. User Experience
- Keep notifications concise and actionable
- Use appropriate priority levels
- Provide clear action buttons
- Group related notifications

### 3. System Integration
- Connect with background daemon
- Integrate with voice control system
- Link with self-modifying engine
- Sync with GitHub learning system

### 4. Data Management
- Regular cleanup of old notifications
- Monitor database size
- Use persistent notifications wisely
- Filter spam and test notifications

## Integration Examples

### With Background Daemon
```python
# In background daemon
def notify_daemon_status(status):
    system.send_jarvis_status(
        status=f"Background Daemon: {status}",
        details="Background processes status update"
    )
```

### With Voice Control
```python
# In voice control system
def notify_voice_activation():
    system.send_notification(
        "Voice Activated",
        "JARVIS is listening...",
        type=NotificationType.VOICE_COMMAND,
        auto_dismiss_seconds=3
    )
```

### With Self-Modifying Engine
```python
# In self-modifying engine
def notify_code_update(old_hash, new_hash):
    system.send_notification(
        "Code Updated",
        f"System self-modified: {old_hash[:8]} -> {new_hash[:8]}",
        priority=NotificationPriority.HIGH
    )
```

## API Reference

### NotificationSystem Class

#### Methods
- `send_notification()` - Send basic notification
- `send_system_alert()` - Send system alert
- `send_jarvis_status()` - Send JARVIS status update
- `send_github_notification()` - Send GitHub notification
- `send_error_alert()` - Send error alert
- `send_progress_notification()` - Send progress update
- `send_voice_command_confirmation()` - Voice command confirmation
- `get_notification_history()` - Retrieve notification history
- `clear_notification_history()` - Clear old notifications
- `get_system_status()` - Get system status
- `enable_battery_optimization()` - Battery optimization control
- `enable_quiet_hours()` - Quiet hours control

#### Properties
- `battery_optimization` - Battery optimization flag
- `quiet_hours_enabled` - Quiet hours flag
- `max_history_days` - History retention days

### NotificationPriority Enum
- `CRITICAL` - Critical priority
- `HIGH` - High priority  
- `NORMAL` - Normal priority
- `LOW` - Low priority

### NotificationType Enum
- `SYSTEM_ALERT` - System alerts
- `JARVIS_STATUS` - JARVIS status updates
- `GITHUB_NOTIFICATION` - GitHub integration
- `ERROR_ALERT` - Error notifications
- `PROGRESS` - Progress updates
- `VOICE_COMMAND` - Voice command confirmations
- `GENERAL` - General notifications

## Conclusion

JARVIS v11 Enhanced Notification System एक comprehensive solution है mobile devices पर efficient notifications के लिए। यह Termux के साथ perfect integration करता है और सभी major features provide करता है जो एक modern AI assistant को चाहिए।

**Key Benefits:**
- ✅ Termux native notifications
- ✅ Battery-optimized operation
- ✅ Priority-based queue management
- ✅ Rich content support
- ✅ Persistent history storage
- ✅ Smart filtering system
- ✅ Mobile device optimization
- ✅ Privacy-compliant (local storage only)

**Use Cases:**
- System monitoring and alerts
- JARVIS status notifications
- Voice command confirmations
- Progress tracking
- Error reporting
- GitHub integration updates
- Background daemon notifications

JARVIS के साथ perfect integration के लिए यह system background daemon, voice control, और self-modifying engine के साथ seamlessly work करता है।