#!/usr/bin/env python3
"""
JARVIS v11 Plugin Builder Tool
Interactive plugin creation and development tool
"""

import os
import sys
import json
import time
import shutil
import subprocess
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import tempfile

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

try:
    from sdk.plugin_sdk import PluginSDK, create_plugin_sdk
    from core.plugin_architecture import PluginArchitecture
except ImportError as e:
    print(f"Import error: {e}")
    print("Please ensure plugin system is properly installed")


class PluginBuilder:
    """Interactive plugin builder tool"""
    
    def __init__(self, jarvis_home: str = None):
        self.jarvis_home = jarvis_home or os.environ.get('JARVIS_HOME', str(Path.home() / '.jarvis'))
        self.sdk = create_plugin_sdk(self.jarvis_home)
        self.current_project = None
        self.logger = self._setup_logging()
        
    def _setup_logging(self):
        """Setup logging for plugin builder"""
        import logging
        logger = logging.getLogger('plugin_builder')
        logger.setLevel(logging.INFO)
        
        # Console handler
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def display_banner(self):
        """Display welcome banner"""
        banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                    JARVIS v11 Plugin Builder Tool                           ║
║                    Interactive Plugin Development                           ║
╚══════════════════════════════════════════════════════════════════════════════╝
        
Plugin Builder Help:
  • Create new plugins from templates
  • Validate and test plugin code
  • Generate documentation
  • Package plugins for distribution
  • Setup development environment

Commands:
  create     - Create a new plugin project
  templates  - List available plugin templates
  validate   - Validate existing plugin
  test       - Test plugin functionality
  build      - Build plugin package
  docs       - Generate documentation
  setup      - Setup development environment
  help       - Show this help
  quit       - Exit plugin builder

Type 'help' anytime for assistance.
        """
        print(banner)
    
    def interactive_create(self):
        """Interactive plugin creation process"""
        print("\n🔧 Plugin Creation Wizard")
        print("-" * 40)
        
        # Get project name
        while True:
            project_name = input("\n📝 Enter plugin name: ").strip()
            if project_name:
                break
            print("❌ Plugin name cannot be empty!")
        
        # List available templates
        print("\n📋 Available Plugin Templates:")
        templates = self.sdk.list_templates()
        for i, template in enumerate(templates, 1):
            print(f"  {i}. {template['name']} ({template['type']})")
            print(f"     {template['description']}")
        
        # Get template selection
        while True:
            try:
                choice = input(f"\n🔢 Select template (1-{len(templates)}): ").strip()
                template_index = int(choice) - 1
                if 0 <= template_index < len(templates):
                    selected_template = templates[template_index]
                    break
                else:
                    print(f"❌ Please enter a number between 1 and {len(templates)}")
            except ValueError:
                print("❌ Please enter a valid number")
        
        # Get author name
        author = input("\n👤 Enter author name (default: Developer): ").strip()
        if not author:
            author = "Developer"
        
        # Confirm creation
        print(f"\n📄 Plugin Summary:")
        print(f"  Name: {project_name}")
        print(f"  Template: {selected_template['name']}")
        print(f"  Author: {author}")
        print(f"  Type: {selected_template['type']}")
        
        confirm = input("\n✅ Create plugin? (y/n): ").strip().lower()
        if confirm != 'y':
            print("❌ Plugin creation cancelled.")
            return False
        
        # Create plugin project
        print(f"\n🚀 Creating plugin '{project_name}'...")
        try:
            self.current_project = self.sdk.create_plugin_project(
                project_name, selected_template['type'], author
            )
            print(f"✅ Plugin created successfully!")
            print(f"📁 Project location: {self.current_project.project_path}")
            
            # Show next steps
            self._show_next_steps()
            return True
            
        except Exception as e:
            print(f"❌ Failed to create plugin: {e}")
            return False
    
    def _show_next_steps(self):
        """Show next steps after plugin creation"""
        if not self.current_project:
            return
        
        print(f"\n🎉 Plugin '{self.current_project.name}' created successfully!")
        print("\n📋 Next Steps:")
        print("  1. Edit the plugin file to add your functionality")
        print("  2. Test the plugin: test")
        print("  3. Validate the plugin: validate")
        print("  4. Generate documentation: docs")
        print("  5. Build for distribution: build")
        print("\n📁 Key files:")
        plugin_file = self.current_project.project_path / f"{self.current_project.name}.py"
        config_file = self.current_project.project_path / "project.json"
        readme_file = self.current_project.project_path / "README.md"
        
        print(f"  Plugin Code: {plugin_file}")
        print(f"  Project Config: {config_file}")
        print(f"  Documentation: {readme_file}")
    
    def list_templates(self):
        """List all available plugin templates"""
        print("\n📋 Available Plugin Templates")
        print("=" * 50)
        
        templates = self.sdk.list_templates()
        for i, template in enumerate(templates, 1):
            print(f"\n{i}. {template['name']}")
            print(f"   Type: {template['type']}")
            print(f"   Description: {template['description']}")
            print(f"   Capabilities: {', '.join(template['capabilities'])}")
            print(f"   Required Methods: {', '.join(template['required_methods'])}")
            if template['dependencies']:
                print(f"   Dependencies: {', '.join(template['dependencies'])}")
    
    def validate_plugin(self, plugin_path: str = None):
        """Validate a plugin file"""
        print("\n🔍 Plugin Validation")
        print("-" * 30)
        
        if not plugin_path and self.current_project:
            plugin_path = str(self.current_project.project_path / f"{self.current_project.name}.py")
        elif not plugin_path:
            plugin_path = input("📄 Enter plugin file path: ").strip()
        
        plugin_file = Path(plugin_path)
        if not plugin_file.exists():
            print(f"❌ Plugin file not found: {plugin_path}")
            return False
        
        print(f"🔍 Validating plugin: {plugin_file.name}")
        
        try:
            validation = self.sdk.validate_plugin(plugin_file)
            
            print(f"\n📊 Validation Results:")
            print(f"  Score: {validation.get('score', 0)}/100")
            print(f"  Valid Syntax: {'✅' if validation.get('valid_syntax') else '❌'}")
            print(f"  Inherits BasePlugin: {'✅' if validation.get('inherits_from_base') else '❌'}")
            print(f"  Has Metadata: {'✅' if validation.get('has_metadata') else '❌'}")
            print(f"  Has Required Methods: {'✅' if validation.get('has_required_methods') else '❌'}")
            
            if validation.get('issues'):
                print(f"\n❌ Issues:")
                for issue in validation['issues']:
                    print(f"  • {issue}")
            
            if validation.get('warnings'):
                print(f"\n⚠️  Warnings:")
                for warning in validation['warnings']:
                    print(f"  • {warning}")
            
            if validation.get('recommendations'):
                print(f"\n💡 Recommendations:")
                for rec in validation['recommendations']:
                    print(f"  • {rec}")
            
            if validation.get('valid'):
                print(f"\n✅ Plugin is valid and ready to use!")
                return True
            else:
                print(f"\n❌ Plugin has issues that need to be fixed.")
                return False
                
        except Exception as e:
            print(f"❌ Validation failed: {e}")
            return False
    
    def test_plugin(self, plugin_path: str = None):
        """Test plugin functionality"""
        print("\n🧪 Plugin Testing")
        print("-" * 25)
        
        if not plugin_path and self.current_project:
            plugin_path = str(self.current_project.project_path / f"{self.current_project.name}.py")
        elif not plugin_path:
            plugin_path = input("📄 Enter plugin file path: ").strip()
        
        plugin_file = Path(plugin_path)
        if not plugin_file.exists():
            print(f"❌ Plugin file not found: {plugin_path}")
            return False
        
        print(f"🧪 Testing plugin: {plugin_file.name}")
        
        try:
            test_results = self.sdk.test_plugin(plugin_file)
            
            print(f"\n🧪 Test Results:")
            print(f"  Plugin Class: {test_results.get('plugin_class', 'Unknown')}")
            print(f"  Initialization: {'✅' if test_results.get('initialization') else '❌'}")
            print(f"  Capabilities: {len(test_results.get('capabilities', []))} found")
            print(f"  Command Handling: {'✅' if test_results.get('command_handling') else '❌'}")
            print(f"  Shutdown: {'✅' if test_results.get('shutdown') else '❌'}")
            
            if test_results.get('issues'):
                print(f"\n❌ Issues:")
                for issue in test_results['issues']:
                    print(f"  • {issue}")
            
            if test_results.get('success'):
                print(f"\n✅ Plugin tests passed!")
                return True
            else:
                print(f"\n❌ Plugin tests failed.")
                return False
                
        except Exception as e:
            print(f"❌ Testing failed: {e}")
            return False
    
    def analyze_code(self, plugin_path: str = None):
        """Analyze plugin code quality"""
        print("\n📈 Code Analysis")
        print("-" * 20)
        
        if not plugin_path and self.current_project:
            plugin_path = str(self.current_project.project_path / f"{self.current_project.name}.py")
        elif not plugin_path:
            plugin_path = input("📄 Enter plugin file path: ").strip()
        
        plugin_file = Path(plugin_path)
        if not plugin_file.exists():
            print(f"❌ Plugin file not found: {plugin_path}")
            return False
        
        print(f"📈 Analyzing code: {plugin_file.name}")
        
        try:
            analysis = self.sdk.analyze_code(plugin_file)
            
            print(f"\n📊 Code Analysis Results:")
            print(f"  File Size: {analysis.get('file_size', 0)} bytes")
            print(f"  Line Count: {analysis.get('line_count', 0)} lines")
            print(f"  Complexity Score: {analysis.get('complexity_score', 0)}")
            print(f"  Valid Syntax: {'✅' if analysis.get('syntax_valid') else '❌'}")
            
            if analysis.get('classes'):
                print(f"\n📚 Classes Found:")
                for cls in analysis['classes']:
                    print(f"  • {cls['name']} (line {cls['line']})")
            
            if analysis.get('functions'):
                print(f"\n🔧 Functions Found:")
                for func in analysis['functions']:
                    print(f"  • {func['name']}() (line {func['line']})")
            
            if analysis.get('issues'):
                print(f"\n❌ Issues:")
                for issue in analysis['issues']:
                    print(f"  • {issue}")
            
            if analysis.get('recommendations'):
                print(f"\n💡 Recommendations:")
                for rec in analysis['recommendations']:
                    print(f"  • {rec}")
            
            return True
            
        except Exception as e:
            print(f"❌ Code analysis failed: {e}")
            return False
    
    def generate_documentation(self, plugin_path: str = None, output_dir: str = None):
        """Generate plugin documentation"""
        print("\n📚 Documentation Generation")
        print("-" * 35)
        
        if not plugin_path and self.current_project:
            plugin_path = str(self.current_project.project_path / f"{self.current_project.name}.py")
        elif not plugin_path:
            plugin_path = input("📄 Enter plugin file path: ").strip()
        
        if not output_dir and self.current_project:
            output_dir = str(self.current_project.project_path / 'docs')
        elif not output_dir:
            output_dir = input("📁 Enter output directory (default: docs): ").strip() or 'docs'
        
        plugin_file = Path(plugin_path)
        docs_dir = Path(output_dir)
        
        if not plugin_file.exists():
            print(f"❌ Plugin file not found: {plugin_path}")
            return False
        
        print(f"📚 Generating documentation for: {plugin_file.name}")
        print(f"📁 Output directory: {docs_dir}")
        
        try:
            docs_result = self.sdk.generate_documentation(plugin_file, docs_dir)
            
            if docs_result.get('success'):
                print(f"✅ Documentation generated successfully!")
                print(f"📄 Documentation file: {docs_result['documentation_file']}")
                
                plugin_info = docs_result.get('plugin_info', {})
                if plugin_info:
                    print(f"\n📋 Plugin Information:")
                    print(f"  Name: {plugin_info.get('name', 'Unknown')}")
                    print(f"  Version: {plugin_info.get('version', 'Unknown')}")
                    print(f"  Author: {plugin_info.get('author', 'Unknown')}")
                    print(f"  Type: {plugin_info.get('plugin_type', 'Unknown')}")
                
                return True
            else:
                print(f"❌ Documentation generation failed: {docs_result.get('error')}")
                return False
                
        except Exception as e:
            print(f"❌ Documentation generation failed: {e}")
            return False
    
    def build_package(self, project_dir: str = None):
        """Build plugin package for distribution"""
        print("\n📦 Plugin Package Building")
        print("-" * 35)
        
        if not project_dir and self.current_project:
            project_dir = str(self.current_project.project_path)
        elif not project_dir:
            project_dir = input("📁 Enter project directory: ").strip()
        
        project_path = Path(project_dir)
        if not project_path.exists():
            print(f"❌ Project directory not found: {project_dir}")
            return False
        
        print(f"📦 Building package for: {project_path.name}")
        
        try:
            build_result = self.sdk.build_plugin_package(project_path)
            
            if build_result.get('success'):
                print(f"✅ Package built successfully!")
                print(f"📁 Package directory: {build_result['package_directory']}")
                if 'archive_path' in build_result:
                    print(f"📦 Archive file: {build_result['archive_path']}")
                
                metadata = build_result.get('metadata', {})
                if metadata:
                    print(f"\n📋 Package Metadata:")
                    print(f"  Name: {metadata.get('name', 'Unknown')}")
                    print(f"  Version: {metadata.get('version', 'Unknown')}")
                    print(f"  Files: {', '.join(metadata.get('files', []))}")
                
                return True
            else:
                print(f"❌ Package building failed: {build_result.get('error')}")
                return False
                
        except Exception as e:
            print(f"❌ Package building failed: {e}")
            return False
    
    def setup_development_environment(self):
        """Setup complete development environment"""
        print("\n🔧 Development Environment Setup")
        print("-" * 40)
        
        print("🔧 Setting up JARVIS plugin development environment...")
        
        try:
            if self.sdk.setup_development_environment():
                print("✅ Development environment setup complete!")
                
                print("\n📋 Environment Components:")
                print("  • Plugin templates and examples")
                print("  • Testing framework and configuration")
                print("  • Documentation generation tools")
                print("  • Package building tools")
                print("  • SDK configuration")
                
                print("\n📁 Directory Structure:")
                sdk_home = Path(self.jarvis_home) / 'sdk'
                print(f"  SDK Home: {sdk_home}")
                print(f"  Templates: {sdk_home / 'templates'}")
                print(f"  Examples: {sdk_home / 'examples'}")
                print(f"  Testing: {sdk_home / 'testing'}")
                print(f"  Distribution: {sdk_home / 'distribution'}")
                
                return True
            else:
                print("❌ Development environment setup failed.")
                return False
                
        except Exception as e:
            print(f"❌ Development environment setup failed: {e}")
            return False
    
    def show_help(self):
        """Show detailed help information"""
        help_text = """
🔧 JARVIS v11 Plugin Builder Help

COMMANDS:
  create     Create a new plugin project interactively
             Usage: create
  
  templates  List all available plugin templates
             Usage: templates
  
  validate   Validate plugin code and structure
             Usage: validate [plugin_file_path]
             Example: validate /path/to/plugin.py
  
  test       Test plugin functionality
             Usage: test [plugin_file_path]
             Example: test /path/to/plugin.py
  
  analyze    Analyze code quality and structure
             Usage: analyze [plugin_file_path]
             Example: analyze /path/to/plugin.py
  
  docs       Generate plugin documentation
             Usage: docs [plugin_file_path] [output_dir]
             Example: docs /path/to/plugin.py docs/
  
  build      Build plugin package for distribution
             Usage: build [project_directory]
             Example: build /path/to/project/
  
  setup      Setup development environment
             Usage: setup
  
  help       Show this help message
             Usage: help
  
  quit       Exit the plugin builder
             Usage: quit

PLUGIN TYPES:
  voice      Voice command handlers and speech processing
  api        External API integrations and data connectors
  data       Data processing and transformation tools
  ui         User interface enhancements and custom widgets
  automation Task automation and workflow management
  learning   Machine learning and AI-powered features

WORKFLOW:
  1. Use 'templates' to see available options
  2. Use 'create' to start the interactive creation wizard
  3. Use 'validate' to check plugin structure
  4. Use 'test' to verify functionality
  5. Use 'analyze' for code quality insights
  6. Use 'docs' to generate documentation
  7. Use 'build' to create distribution package

EXAMPLES:
  # Create a new voice plugin
  > create
  > select voice template
  > name: "Weather Voice"
  > author: "Your Name"

  # Validate an existing plugin
  > validate /home/user/my_plugin.py

  # Test a plugin
  > test /home/user/my_plugin.py

  # Generate documentation
  > docs /home/user/my_plugin.py docs/

  # Build a plugin package
  > build /home/user/my_plugin_project/

TIPS:
  • Always test plugins before distributing
  • Follow plugin development best practices
  • Use validation tools to catch issues early
  • Generate documentation for better user experience
  • Package plugins properly for easy installation
        """
        print(help_text)
    
    def interactive_mode(self):
        """Run plugin builder in interactive mode"""
        self.display_banner()
        
        while True:
            try:
                command = input("\n🔧 Plugin Builder> ").strip().lower()
                
                if command == 'quit' or command == 'exit':
                    print("👋 Goodbye!")
                    break
                elif command == 'create':
                    self.interactive_create()
                elif command == 'templates':
                    self.list_templates()
                elif command == 'validate':
                    plugin_path = input("📄 Plugin file path (or press Enter for current project): ").strip()
                    if not plugin_path:
                        plugin_path = None
                    self.validate_plugin(plugin_path)
                elif command == 'test':
                    plugin_path = input("📄 Plugin file path (or press Enter for current project): ").strip()
                    if not plugin_path:
                        plugin_path = None
                    self.test_plugin(plugin_path)
                elif command == 'analyze':
                    plugin_path = input("📄 Plugin file path (or press Enter for current project): ").strip()
                    if not plugin_path:
                        plugin_path = None
                    self.analyze_code(plugin_path)
                elif command == 'docs':
                    plugin_path = input("📄 Plugin file path (or press Enter for current project): ").strip()
                    if not plugin_path:
                        plugin_path = None
                    output_dir = input("📁 Output directory (or press Enter for default): ").strip()
                    if not output_dir:
                        output_dir = None
                    self.generate_documentation(plugin_path, output_dir)
                elif command == 'build':
                    project_dir = input("📁 Project directory (or press Enter for current project): ").strip()
                    if not project_dir:
                        project_dir = None
                    self.build_package(project_dir)
                elif command == 'setup':
                    self.setup_development_environment()
                elif command == 'help' or command == '?':
                    self.show_help()
                elif command == '':
                    continue
                else:
                    print(f"❌ Unknown command: {command}")
                    print("Type 'help' for available commands.")
                    
            except KeyboardInterrupt:
                print("\n\n👋 Interrupted by user. Goodbye!")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
    
    def command_line_mode(self, args):
        """Run plugin builder in command line mode"""
        try:
            if args.command == 'create':
                # Interactive creation
                self.interactive_create()
            elif args.command == 'templates':
                self.list_templates()
            elif args.command == 'validate':
                self.validate_plugin(args.plugin_path)
            elif args.command == 'test':
                self.test_plugin(args.plugin_path)
            elif args.command == 'analyze':
                self.analyze_code(args.plugin_path)
            elif args.command == 'docs':
                self.generate_documentation(args.plugin_path, args.output_dir)
            elif args.command == 'build':
                self.build_package(args.project_dir)
            elif args.command == 'setup':
                self.setup_development_environment()
            else:
                print(f"❌ Unknown command: {args.command}")
                return False
            
            return True
            
        except Exception as e:
            print(f"❌ Command failed: {e}")
            return False


def main():
    """Main entry point for plugin builder"""
    parser = argparse.ArgumentParser(
        description="JARVIS v11 Plugin Builder Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s create              # Interactive plugin creation
  %(prog)s templates           # List available templates
  %(prog)s validate plugin.py  # Validate plugin file
  %(prog)s test plugin.py      # Test plugin functionality
  %(prog)s docs plugin.py docs # Generate documentation
  %(prog)s build project/      # Build plugin package
  %(prog)s setup              # Setup development environment
        """
    )
    
    parser.add_argument(
        'command',
        choices=['create', 'templates', 'validate', 'test', 'analyze', 'docs', 'build', 'setup', 'help'],
        help='Command to execute'
    )
    
    parser.add_argument(
        '--plugin-path', '-p',
        help='Path to plugin file'
    )
    
    parser.add_argument(
        '--output-dir', '-o',
        help='Output directory for documentation'
    )
    
    parser.add_argument(
        '--project-dir', '-d',
        help='Project directory for building'
    )
    
    parser.add_argument(
        '--jarvis-home', '-j',
        help='JARVIS home directory'
    )
    
    parser.add_argument(
        '--interactive', '-i',
        action='store_true',
        help='Run in interactive mode'
    )
    
    args = parser.parse_args()
    
    # Create plugin builder
    builder = PluginBuilder(args.jarvis_home)
    
    if args.command == 'help':
        builder.show_help()
    elif args.interactive or args.command in ['create']:
        # Interactive mode
        builder.interactive_mode()
    else:
        # Command line mode
        success = builder.command_line_mode(args)
        sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()