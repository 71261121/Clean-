#!/usr/bin/env python3
"""
JARVIS v11 Enhanced Plugin Architecture System
Comprehensive Plugin Management System with Safety, Security, and Development Tools
"""

import os
import sys
import json
import hashlib
import importlib
import inspect
import threading
import time
import subprocess
import ast
import zipfile
import shutil
import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
from datetime import datetime
import traceback
import weakref
import asyncio
import tempfile
import pickle
import re
import contextlib
import io

# Plugin Architecture System for JARVIS v11 Enhanced
class PluginArchitecture:
    """Main Plugin Architecture System"""
    
    def __init__(self, jarvis_core=None):
        self.jarvis_core = jarvis_core
        self.version = "1.0.0"
        self.logger = self._setup_logging()
        
        # Core plugin system components
        self.plugin_manager = PluginManager(self)
        self.marketplace = PluginMarketplace(self)
        self.security_validator = SecurityValidator(self)
        self.communication_hub = PluginCommunicationHub(self)
        self.sandbox_manager = SandboxManager(self)
        self.sdk_manager = SDKManager(self)
        
        # Plugin registry and state
        self.loaded_plugins = {}
        self.plugin_metadata = {}
        self.plugin_events = {}
        self.plugin_hooks = {}
        
        # Initialize plugin directories
        self.plugin_dirs = {
            'user': Path.home() / '.jarvis' / 'plugins',
            'system': Path(__file__).parent.parent / 'plugins',
            'marketplace': Path.home() / '.jarvis' / 'marketplace'
        }
        
        self._ensure_plugin_directories()
        
        # Performance monitoring
        self.performance_monitor = PerformanceMonitor(self)
        
        self.logger.info("JARVIS v11 Plugin Architecture System initialized")
    
    def _setup_logging(self):
        """Setup logging for plugin system"""
        logger = logging.getLogger('jarvis_plugin_architecture')
        logger.setLevel(logging.INFO)
        
        # Create logs directory
        log_dir = Path.home() / '.jarvis' / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # File handler
        handler = logging.FileHandler(log_dir / 'plugin_architecture.log')
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def _ensure_plugin_directories(self):
        """Ensure all plugin directories exist"""
        for name, path in self.plugin_dirs.items():
            path.mkdir(parents=True, exist_ok=True)
            (path / '__init__.py').touch()
    
    def initialize_plugin_system(self):
        """Initialize the complete plugin system"""
        try:
            self.logger.info("Initializing Plugin Architecture System...")
            
            # Initialize core components
            self.plugin_manager.initialize()
            self.marketplace.initialize()
            self.security_validator.initialize()
            self.communication_hub.initialize()
            self.sandbox_manager.initialize()
            self.sdk_manager.initialize()
            
            # Load plugin database
            self._load_plugin_database()
            
            # Start background services
            self._start_background_services()
            
            self.logger.info("Plugin Architecture System initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize plugin system: {e}")
            return False
    
    def _load_plugin_database(self):
        """Load plugin metadata database"""
        db_path = Path.home() / '.jarvis' / 'plugin_database.db'
        self.plugin_db = PluginDatabase(db_path)
        self.plugin_db.initialize()
    
    def _start_background_services(self):
        """Start background plugin services"""
        # Start performance monitoring
        self.performance_monitor.start()
        
        # Start plugin update checker
        self.update_checker = PluginUpdateChecker(self)
        self.update_checker.start()
        
        # Start plugin health monitor
        self.health_monitor = PluginHealthMonitor(self)
        self.health_monitor.start()
    
    def shutdown(self):
        """Shutdown plugin system gracefully"""
        try:
            self.logger.info("Shutting down Plugin Architecture System...")
            
            # Stop background services
            if hasattr(self, 'performance_monitor'):
                self.performance_monitor.stop()
            if hasattr(self, 'update_checker'):
                self.update_checker.stop()
            if hasattr(self, 'health_monitor'):
                self.health_monitor.stop()
            
            # Unload all plugins
            for plugin_id in list(self.loaded_plugins.keys()):
                self.unload_plugin(plugin_id)
            
            # Shutdown core components
            if hasattr(self, 'plugin_db'):
                self.plugin_db.close()
            
            self.logger.info("Plugin Architecture System shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during shutdown: {e}")


# Plugin Manager - Core plugin lifecycle management
class PluginManager:
    """Plugin Manager handles plugin discovery, loading, and lifecycle"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.loaded_plugins = {}
        self.plugin_metadata = {}
        self.plugin_states = {}
    
    def initialize(self):
        """Initialize plugin manager"""
        self.logger.info("Initializing Plugin Manager...")
        
        # Discover available plugins
        self._discover_plugins()
        
        # Initialize plugin lifecycle management
        self.lifecycle_manager = PluginLifecycleManager(self)
        
        self.logger.info("Plugin Manager initialized")
    
    def _discover_plugins(self):
        """Discover all available plugins"""
        for plugin_type, directory in self.architecture.plugin_dirs.items():
            if directory.exists():
                self._scan_directory_for_plugins(directory, plugin_type)
    
    def _scan_directory_for_plugins(self, directory: Path, plugin_type: str):
        """Scan directory for plugins"""
        for plugin_file in directory.glob('*.py'):
            if plugin_file.name.startswith('__'):
                continue
                
            try:
                plugin_info = self._analyze_plugin(plugin_file, plugin_type)
                if plugin_info:
                    self.plugin_metadata[plugin_info['id']] = plugin_info
                    self.logger.info(f"Discovered plugin: {plugin_info['name']} v{plugin_info['version']}")
                    
            except Exception as e:
                self.logger.error(f"Failed to analyze plugin {plugin_file}: {e}")
    
    def _analyze_plugin(self, plugin_path: Path, plugin_type: str) -> Optional[Dict]:
        """Analyze plugin for metadata"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse plugin metadata
            metadata = self._extract_plugin_metadata(content)
            if not metadata:
                return None
            
            metadata.update({
                'id': self._generate_plugin_id(plugin_path),
                'path': str(plugin_path),
                'type': plugin_type,
                'file_hash': hashlib.sha256(content.encode()).hexdigest(),
                'discovered_at': datetime.now().isoformat()
            })
            
            return metadata
            
        except Exception as e:
            self.logger.error(f"Failed to analyze plugin {plugin_path}: {e}")
            return None
    
    def _extract_plugin_metadata(self, content: str) -> Optional[Dict]:
        """Extract plugin metadata from source code"""
        try:
            # Look for plugin metadata in docstring or comments
            metadata_pattern = r'PLUGIN_METADATA\s*=\s*(\{.*?\})'
            match = re.search(metadata_pattern, content, re.DOTALL)
            
            if match:
                metadata_str = match.group(1)
                metadata = eval(metadata_str)  # Safe eval for trusted code
                return metadata
            else:
                # Fallback: extract from class definition
                class_pattern = r'class\s+(\w+Plugin)\s*:\s*\n\s*"""(.*?)"""'
                class_match = re.search(class_pattern, content, re.DOTALL)
                
                if class_match:
                    class_name = class_match.group(1)
                    docstring = class_match.group(2).strip()
                    
                    return {
                        'name': class_name.replace('Plugin', ''),
                        'description': docstring,
                        'version': '1.0.0',
                        'author': 'Unknown',
                        'plugin_type': 'generic'
                    }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Failed to extract plugin metadata: {e}")
            return None
    
    def _generate_plugin_id(self, plugin_path: Path) -> str:
        """Generate unique plugin ID"""
        return hashlib.md5(f"{plugin_path.name}_{plugin_path.stat().st_mtime}".encode()).hexdigest()
    
    def load_plugin(self, plugin_id: str) -> bool:
        """Load a plugin by ID"""
        try:
            if plugin_id in self.loaded_plugins:
                self.logger.warning(f"Plugin {plugin_id} is already loaded")
                return True
            
            if plugin_id not in self.plugin_metadata:
                self.logger.error(f"Plugin {plugin_id} not found")
                return False
            
            plugin_info = self.plugin_metadata[plugin_id]
            
            # Security validation
            if not self.architecture.security_validator.validate_plugin(plugin_info):
                self.logger.error(f"Plugin {plugin_id} failed security validation")
                return False
            
            # Create plugin instance
            plugin_instance = self._create_plugin_instance(plugin_info)
            if not plugin_instance:
                self.logger.error(f"Failed to create plugin instance for {plugin_id}")
                return False
            
            # Initialize plugin
            if not plugin_instance.initialize():
                self.logger.error(f"Plugin {plugin_id} initialization failed")
                return False
            
            # Add to loaded plugins
            self.loaded_plugins[plugin_id] = plugin_instance
            self.plugin_states[plugin_id] = 'loaded'
            
            self.logger.info(f"Plugin {plugin_id} loaded successfully")
            
            # Notify plugin lifecycle manager
            self.lifecycle_manager.on_plugin_loaded(plugin_instance)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to load plugin {plugin_id}: {e}")
            return False
    
    def _create_plugin_instance(self, plugin_info: Dict) -> Optional['BasePlugin']:
        """Create plugin instance from metadata"""
        try:
            # Import plugin module
            plugin_path = Path(plugin_info['path'])
            module_name = plugin_path.stem
            
            spec = importlib.util.spec_from_file_location(module_name, plugin_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            
            # Find plugin class
            plugin_class = None
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if hasattr(obj, '_is_jarvis_plugin'):
                    plugin_class = obj
                    break
            
            if not plugin_class:
                self.logger.error("No valid plugin class found")
                return None
            
            # Create instance
            return plugin_class(self.architecture)
            
        except Exception as e:
            self.logger.error(f"Failed to create plugin instance: {e}")
            return None
    
    def unload_plugin(self, plugin_id: str) -> bool:
        """Unload a plugin by ID"""
        try:
            if plugin_id not in self.loaded_plugins:
                self.logger.warning(f"Plugin {plugin_id} is not loaded")
                return True
            
            plugin_instance = self.loaded_plugins[plugin_id]
            
            # Shutdown plugin
            plugin_instance.shutdown()
            
            # Remove from loaded plugins
            del self.loaded_plugins[plugin_id]
            del self.plugin_states[plugin_id]
            
            self.logger.info(f"Plugin {plugin_id} unloaded successfully")
            
            # Notify plugin lifecycle manager
            self.lifecycle_manager.on_plugin_unloaded(plugin_instance)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to unload plugin {plugin_id}: {e}")
            return False
    
    def get_plugin_info(self, plugin_id: str) -> Optional[Dict]:
        """Get plugin information"""
        return self.plugin_metadata.get(plugin_id)
    
    def list_plugins(self) -> List[Dict]:
        """List all discovered plugins"""
        return list(self.plugin_metadata.values())
    
    def list_loaded_plugins(self) -> List[str]:
        """List all loaded plugin IDs"""
        return list(self.loaded_plugins.keys())
    
    def get_plugin_state(self, plugin_id: str) -> str:
        """Get plugin state"""
        return self.plugin_states.get(plugin_id, 'unknown')


# Base Plugin Class - Interface for all plugins
class BasePlugin:
    """Base class for all JARVIS plugins"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.plugin_id = None
        self.metadata = {}
        self.state = 'initialized'
        self.dependencies = []
        self.provides_interfaces = []
        self.event_handlers = {}
        self.resources = {}
    
    def initialize(self) -> bool:
        """Initialize the plugin"""
        try:
            self.logger.info(f"Initializing plugin: {self.__class__.__name__}")
            self.state = 'initializing'
            
            # Load dependencies
            if not self._load_dependencies():
                return False
            
            # Register event handlers
            self._register_event_handlers()
            
            # Setup resources
            self._setup_resources()
            
            self.state = 'ready'
            self.logger.info(f"Plugin {self.__class__.__name__} initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to initialize plugin {self.__class__.__name__}: {e}")
            self.state = 'error'
            return False
    
    def shutdown(self):
        """Shutdown the plugin"""
        try:
            self.logger.info(f"Shutting down plugin: {self.__class__.__name__}")
            self.state = 'shutting_down'
            
            # Cleanup resources
            self._cleanup_resources()
            
            # Unregister event handlers
            self._unregister_event_handlers()
            
            self.state = 'shutdown'
            
        except Exception as e:
            self.logger.error(f"Error during plugin shutdown {self.__class__.__name__}: {e}")
    
    def _load_dependencies(self) -> bool:
        """Load plugin dependencies"""
        for dependency in self.dependencies:
            if not self.architecture.plugin_manager.load_plugin(dependency):
                self.logger.error(f"Failed to load dependency {dependency}")
                return False
        return True
    
    def _register_event_handlers(self):
        """Register plugin event handlers"""
        for event_type, handler in self.event_handlers.items():
            self.architecture.plugin_events[event_type] = self.architecture.plugin_events.get(event_type, [])
            self.architecture.plugin_events[event_type].append(handler)
    
    def _unregister_event_handlers(self):
        """Unregister plugin event handlers"""
        for event_type, handler in self.event_handlers.items():
            if event_type in self.architecture.plugin_events:
                if handler in self.architecture.plugin_events[event_type]:
                    self.architecture.plugin_events[event_type].remove(handler)
    
    def _setup_resources(self):
        """Setup plugin resources"""
        # Override in subclasses
        pass
    
    def _cleanup_resources(self):
        """Cleanup plugin resources"""
        # Override in subclasses
        pass
    
    def emit_event(self, event_type: str, data: Any = None):
        """Emit an event"""
        if event_type in self.architecture.plugin_events:
            for handler in self.architecture.plugin_events[event_type]:
                try:
                    handler(data)
                except Exception as e:
                    self.logger.error(f"Error in event handler: {e}")
    
    def request_permission(self, permission: str) -> bool:
        """Request permission from user"""
        # Default implementation - can be overridden
        return True
    
    def get_capabilities(self) -> List[str]:
        """Get plugin capabilities"""
        return []
    
    def handle_command(self, command: str, args: List[str]) -> Any:
        """Handle a command from JARVIS"""
        return None
    
    # Static method to mark classes as JARVIS plugins
    @staticmethod
    def _is_jarvis_plugin():
        return True


# Security Validator - Plugin security and safety validation
class SecurityValidator:
    """Plugin security and safety validation system"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.safety_rules = self._load_safety_rules()
        self.malware_signatures = self._load_malware_signatures()
    
    def initialize(self):
        """Initialize security validator"""
        self.logger.info("Initializing Security Validator...")
        self._update_safety_database()
        self.logger.info("Security Validator initialized")
    
    def _load_safety_rules(self) -> List[str]:
        """Load plugin safety rules"""
        return [
            r'import\s+os\.system',
            r'import\s+subprocess\.call',
            r'eval\s*\(',
            r'exec\s*\(',
            r'__import__',
            r'open\s*\(',
            r'file\s*\(',
            r'input\s*\(',
            r'raw_input',
        ]
    
    def _load_malware_signatures(self) -> List[str]:
        """Load malware signatures"""
        return [
            'malware',
            'virus',
            'trojan',
            'backdoor',
            'keylogger',
            'rootkit',
        ]
    
    def validate_plugin(self, plugin_info: Dict) -> bool:
        """Validate plugin security"""
        try:
            plugin_path = Path(plugin_info['path'])
            
            # Static code analysis
            if not self._static_code_analysis(plugin_path):
                return False
            
            # Check for malware signatures
            if self._check_malware_signatures(plugin_path):
                return False
            
            # Validate plugin structure
            if not self._validate_plugin_structure(plugin_path):
                return False
            
            # Check file permissions
            if not self._check_file_permissions(plugin_path):
                return False
            
            # Sandbox test
            if not self._sandbox_test(plugin_path):
                return False
            
            self.logger.info(f"Plugin {plugin_info['name']} passed security validation")
            return True
            
        except Exception as e:
            self.logger.error(f"Security validation failed for plugin {plugin_info['name']}: {e}")
            return False
    
    def _static_code_analysis(self, plugin_path: Path) -> bool:
        """Perform static code analysis"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check for dangerous patterns
            for rule in self.safety_rules:
                if re.search(rule, content):
                    self.logger.warning(f"Plugin {plugin_path.name} contains suspicious pattern: {rule}")
                    return False
            
            # AST analysis
            try:
                tree = ast.parse(content)
                # Additional AST-based checks can be added here
            except SyntaxError as e:
                self.logger.error(f"Plugin {plugin_path.name} has syntax errors: {e}")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Static code analysis failed: {e}")
            return False
    
    def _check_malware_signatures(self, plugin_path: Path) -> bool:
        """Check for malware signatures"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read().lower()
            
            for signature in self.malware_signatures:
                if signature in content:
                    self.logger.error(f"Plugin {plugin_path.name} contains malware signature: {signature}")
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Malware signature check failed: {e}")
            return False
    
    def _validate_plugin_structure(self, plugin_path: Path) -> bool:
        """Validate plugin structure"""
        try:
            with open(plugin_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check for required plugin class
            if not re.search(r'class\s+\w+Plugin\s*\(\s*BasePlugin\s*\)', content):
                self.logger.error(f"Plugin {plugin_path.name} does not inherit from BasePlugin")
                return False
            
            # Check for required methods
            required_methods = ['initialize', 'shutdown']
            for method in required_methods:
                if not re.search(rf'def\s+{method}\s*\(', content):
                    self.logger.warning(f"Plugin {plugin_path.name} missing required method: {method}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Plugin structure validation failed: {e}")
            return False
    
    def _check_file_permissions(self, plugin_path: Path) -> bool:
        """Check file permissions"""
        try:
            # Check if file is writable (potential security risk)
            if os.access(plugin_path, os.W_OK):
                self.logger.warning(f"Plugin {plugin_path.name} is writable - potential security risk")
                return True  # Allow but warn
            
            return True
            
        except Exception as e:
            self.logger.error(f"File permission check failed: {e}")
            return False
    
    def _sandbox_test(self, plugin_path: Path) -> bool:
        """Test plugin in sandbox environment"""
        try:
            # Create temporary sandbox environment
            with tempfile.TemporaryDirectory() as temp_dir:
                sandbox_path = Path(temp_dir) / 'sandbox_test.py'
                shutil.copy2(plugin_path, sandbox_path)
                
                # Try to import and test plugin
                result = subprocess.run([
                    sys.executable, '-c',
                    f'import sys; sys.path.insert(0, "{temp_dir}"); '
                    f'try: exec(open("{sandbox_path}").read()); print("SUCCESS")'
                    f'except Exception as e: print(f"ERROR: {{e}}")'
                ], capture_output=True, text=True, timeout=10)
                
                if "SUCCESS" in result.stdout:
                    return True
                else:
                    self.logger.error(f"Sandbox test failed: {result.stdout}")
                    return False
                    
        except Exception as e:
            self.logger.error(f"Sandbox test failed: {e}")
            return False
    
    def _update_safety_database(self):
        """Update safety database"""
        # This would typically fetch updated safety rules from a server
        self.logger.info("Safety database updated")


# Plugin Communication Hub - Inter-plugin communication
class PluginCommunicationHub:
    """Plugin communication and message passing system"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.message_handlers = {}
        self.message_queue = asyncio.Queue()
        self.running = False
    
    def initialize(self):
        """Initialize communication hub"""
        self.logger.info("Initializing Plugin Communication Hub...")
        self.running = True
        self._start_message_processor()
        self.logger.info("Plugin Communication Hub initialized")
    
    def _start_message_processor(self):
        """Start background message processor"""
        def process_messages():
            while self.running:
                try:
                    if not self.message_queue.empty():
                        message = self.message_queue.get_nowait()
                        self._process_message(message)
                    else:
                        time.sleep(0.1)
                except Exception as e:
                    self.logger.error(f"Message processing error: {e}")
        
        self.processor_thread = threading.Thread(target=process_messages, daemon=True)
        self.processor_thread.start()
    
    def _process_message(self, message: Dict):
        """Process a message between plugins"""
        try:
            sender = message.get('sender')
            receiver = message.get('receiver')
            message_type = message.get('type')
            data = message.get('data')
            
            if receiver:
                # Send to specific plugin
                self._send_to_plugin(receiver, message)
            else:
                # Broadcast to all plugins
                self._broadcast_message(message)
                
        except Exception as e:
            self.logger.error(f"Failed to process message: {e}")
    
    def _send_to_plugin(self, plugin_id: str, message: Dict):
        """Send message to specific plugin"""
        if plugin_id in self.architecture.loaded_plugins:
            plugin = self.architecture.loaded_plugins[plugin_id]
            try:
                plugin.handle_message(message)
            except Exception as e:
                self.logger.error(f"Failed to send message to plugin {plugin_id}: {e}")
    
    def _broadcast_message(self, message: Dict):
        """Broadcast message to all plugins"""
        for plugin_id, plugin in self.architecture.loaded_plugins.items():
            try:
                plugin.handle_message(message)
            except Exception as e:
                self.logger.error(f"Failed to broadcast message to plugin {plugin_id}: {e}")
    
    def send_message(self, sender: str, receiver: str, message_type: str, data: Any = None):
        """Send message between plugins"""
        message = {
            'sender': sender,
            'receiver': receiver,
            'type': message_type,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        self.message_queue.put_nowait(message)
    
    def broadcast_message(self, sender: str, message_type: str, data: Any = None):
        """Broadcast message to all plugins"""
        message = {
            'sender': sender,
            'receiver': None,
            'type': message_type,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        self.message_queue.put_nowait(message)
    
    def shutdown(self):
        """Shutdown communication hub"""
        self.running = False


# Sandbox Manager - Plugin isolation and resource management
class SandboxManager:
    """Plugin sandbox and resource isolation manager"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.sandboxes = {}
        self.resource_limits = self._load_resource_limits()
    
    def _load_resource_limits(self) -> Dict[str, int]:
        """Load resource limits for plugins"""
        return {
            'memory_mb': 256,
            'cpu_percent': 25,
            'disk_mb': 100,
            'network_connections': 5,
            'file_descriptors': 100
        }
    
    def create_sandbox(self, plugin_id: str) -> str:
        """Create sandbox for plugin"""
        sandbox_id = f"sandbox_{plugin_id}_{int(time.time())}"
        
        # Create sandbox directory
        sandbox_dir = Path.home() / '.jarvis' / 'sandbox' / sandbox_id
        sandbox_dir.mkdir(parents=True, exist_ok=True)
        
        # Create plugin-specific environment
        sandbox = {
            'id': sandbox_id,
            'plugin_id': plugin_id,
            'directory': sandbox_dir,
            'created_at': datetime.now().isoformat(),
            'resources_used': {},
            'isolated': True
        }
        
        self.sandboxes[sandbox_id] = sandbox
        return sandbox_id
    
    def cleanup_sandbox(self, sandbox_id: str):
        """Cleanup sandbox"""
        if sandbox_id in self.sandboxes:
            sandbox = self.sandboxes[sandbox_id]
            try:
                if sandbox['directory'].exists():
                    shutil.rmtree(sandbox['directory'])
                del self.sandboxes[sandbox_id]
            except Exception as e:
                self.logger.error(f"Failed to cleanup sandbox {sandbox_id}: {e}")
    
    def get_sandbox_directory(self, sandbox_id: str) -> Optional[Path]:
        """Get sandbox directory"""
        return self.sandboxes.get(sandbox_id, {}).get('directory')


# Plugin Marketplace - Curated plugin repository
class PluginMarketplace:
    """Plugin marketplace and discovery system"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.marketplace_cache = {}
        self.installed_plugins = set()
    
    def initialize(self):
        """Initialize plugin marketplace"""
        self.logger.info("Initializing Plugin Marketplace...")
        self._load_marketplace_cache()
        self.logger.info("Plugin Marketplace initialized")
    
    def _load_marketplace_cache(self):
        """Load marketplace plugin cache"""
        # This would typically fetch from remote marketplace
        # For now, create local cache
        self.marketplace_cache = {
            'voice-enhancer': {
                'name': 'Voice Enhancement Suite',
                'description': 'Advanced voice processing and enhancement',
                'version': '2.1.0',
                'author': 'JARVIS Community',
                'rating': 4.8,
                'downloads': 15420,
                'categories': ['voice', 'enhancement']
            },
            'weather-integration': {
                'name': 'Weather Integration',
                'description': 'Real-time weather data and forecasts',
                'version': '1.5.0',
                'author': 'Weather Corp',
                'rating': 4.6,
                'downloads': 8932,
                'categories': ['data', 'weather']
            },
            'smart-home': {
                'name': 'Smart Home Controller',
                'description': 'Control smart home devices via JARVIS',
                'version': '3.0.0',
                'author': 'SmartTech',
                'rating': 4.9,
                'downloads': 12450,
                'categories': ['automation', 'iot']
            }
        }
    
    def search_plugins(self, query: str) -> List[Dict]:
        """Search plugins in marketplace"""
        results = []
        query_lower = query.lower()
        
        for plugin_id, info in self.marketplace_cache.items():
            # Search in name and description
            if (query_lower in info['name'].lower() or 
                query_lower in info['description'].lower() or
                any(query_lower in cat.lower() for cat in info['categories'])):
                results.append({**info, 'id': plugin_id})
        
        return results
    
    def get_plugin_details(self, plugin_id: str) -> Optional[Dict]:
        """Get detailed plugin information"""
        if plugin_id in self.marketplace_cache:
            return {**self.marketplace_cache[plugin_id], 'id': plugin_id}
        return None
    
    def install_plugin(self, plugin_id: str) -> bool:
        """Install plugin from marketplace"""
        try:
            if plugin_id not in self.marketplace_cache:
                self.logger.error(f"Plugin {plugin_id} not found in marketplace")
                return False
            
            plugin_info = self.marketplace_cache[plugin_id]
            
            # Download and install plugin
            if self._download_and_install_plugin(plugin_info):
                self.installed_plugins.add(plugin_id)
                self.logger.info(f"Plugin {plugin_id} installed successfully")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to install plugin {plugin_id}: {e}")
            return False
    
    def _download_and_install_plugin(self, plugin_info: Dict) -> bool:
        """Download and install plugin"""
        # This would typically download from remote server
        # For now, create stub implementation
        try:
            plugin_dir = self.architecture.plugin_dirs['user']
            plugin_file = plugin_dir / f"{plugin_info['id']}.py"
            
            # Create sample plugin file
            sample_plugin = self._create_sample_plugin(plugin_info)
            with open(plugin_file, 'w') as f:
                f.write(sample_plugin)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to download and install plugin: {e}")
            return False
    
    def _create_sample_plugin(self, plugin_info: Dict) -> str:
        """Create sample plugin file"""
        return f'''#!/usr/bin/env python3
"""
Sample plugin: {plugin_info['name']}
{plugin_info['description']}
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {{
    'name': '{plugin_info['name']}',
    'description': '{plugin_info['description']}',
    'version': '{plugin_info['version']}',
    'author': '{plugin_info['author']}',
    'plugin_type': '{plugin_info['categories'][0] if plugin_info['categories'] else 'generic'}'
}}

class {plugin_info['name'].replace(' ', '').replace('-', '')}Plugin(BasePlugin):
    """Sample plugin from marketplace"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        # Plugin initialization code here
        return True
    
    def shutdown(self):
        """Shutdown the plugin"""
        super().shutdown()
        # Plugin cleanup code here
    
    def handle_command(self, command: str, args: list):
        """Handle commands"""
        if command == 'hello':
            return f"Hello from {PLUGIN_METADATA['name']}!"
        return None
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['sample', 'marketplace']
'''


# SDK Manager - Plugin development tools
class SDKManager:
    """Plugin SDK and development tools manager"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.templates = self._load_plugin_templates()
    
    def initialize(self):
        """Initialize SDK manager"""
        self.logger.info("Initializing Plugin SDK Manager...")
        self._setup_development_environment()
        self.logger.info("Plugin SDK Manager initialized")
    
    def _load_plugin_templates(self) -> Dict[str, str]:
        """Load plugin templates"""
        return {
            'voice': self._get_voice_plugin_template(),
            'api': self._get_api_plugin_template(),
            'data': self._get_data_plugin_template(),
            'ui': self._get_ui_plugin_template(),
            'automation': self._get_automation_plugin_template(),
            'learning': self._get_learning_plugin_template()
        }
    
    def _get_voice_plugin_template(self) -> str:
        """Get voice plugin template"""
        return '''#!/usr/bin/env python3
"""
Voice Plugin Template
Create custom voice command handlers
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'Voice Plugin Template',
    'description': 'Custom voice command plugin',
    'version': '1.0.0',
    'author': 'Your Name',
    'plugin_type': 'voice'
}

class VoicePlugin(BasePlugin):
    """Voice command plugin"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        # Register voice commands
        self.register_voice_command('hello', self.handle_hello)
        self.register_voice_command('goodbye', self.handle_goodbye)
        return True
    
    def register_voice_command(self, command: str, handler: callable):
        """Register voice command handler"""
        # This would integrate with JARVIS voice system
        pass
    
    def handle_hello(self, *args):
        """Handle hello command"""
        return "Hello! How can I help you today?"
    
    def handle_goodbye(self, *args):
        """Handle goodbye command"""
        return "Goodbye! See you later!"
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['voice_commands', 'custom_handlers']
'''
    
    def _get_api_plugin_template(self) -> str:
        """Get API plugin template"""
        return '''#!/usr/bin/env python3
"""
API Plugin Template
Create external service connectors
"""

import requests
from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'API Plugin Template',
    'description': 'External API integration plugin',
    'version': '1.0.0',
    'author': 'Your Name',
    'plugin_type': 'api'
}

class ApiPlugin(BasePlugin):
    """API integration plugin"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        self.api_base_url = "https://api.example.com"
        self.api_key = None
        return True
    
    def fetch_data(self, endpoint: str) -> dict:
        """Fetch data from API"""
        try:
            url = f"{self.api_base_url}/{endpoint}"
            headers = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            self.logger.error(f"API request failed: {e}")
            return {}
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['api_integration', 'data_fetching']
'''
    
    def _get_data_plugin_template(self) -> str:
        """Get data plugin template"""
        return '''#!/usr/bin/env python3
"""
Data Plugin Template
Create custom data processors
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'Data Plugin Template',
    'description': 'Custom data processing plugin',
    'version': '1.0.0',
    'author': 'Your Name',
    'plugin_type': 'data'
}

class DataPlugin(BasePlugin):
    """Data processing plugin"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        return True
    
    def process_data(self, data: list) -> list:
        """Process data"""
        # Implement your data processing logic
        processed_data = []
        for item in data:
            # Transform data here
            processed_item = self.transform_item(item)
            processed_data.append(processed_item)
        return processed_data
    
    def transform_item(self, item: dict) -> dict:
        """Transform individual data item"""
        # Implement transformation logic
        return item
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['data_processing', 'transformations']
'''
    
    def _get_ui_plugin_template(self) -> str:
        """Get UI plugin template"""
        return '''#!/usr/bin/env python3
"""
UI Plugin Template
Create interface improvements
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'UI Plugin Template',
    'description': 'User interface enhancement plugin',
    'version': '1.0.0',
    'author': 'Your Name',
    'plugin_type': 'ui'
}

class UiPlugin(BasePlugin):
    """UI enhancement plugin"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        return True
    
    def enhance_interface(self):
        """Enhance JARVIS interface"""
        # Implement UI enhancements
        pass
    
    def add_notification_handler(self, handler: callable):
        """Add custom notification handler"""
        # Implement custom notifications
        pass
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['ui_enhancement', 'notifications']
'''
    
    def _get_automation_plugin_template(self) -> str:
        """Get automation plugin template"""
        return '''#!/usr/bin/env python3
"""
Automation Plugin Template
Create task automation workflows
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'Automation Plugin Template',
    'description': 'Task automation plugin',
    'version': '1.0.0',
    'author': 'Your Name',
    'plugin_type': 'automation'
}

class AutomationPlugin(BasePlugin):
    """Task automation plugin"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        self.workflows = {}
        return True
    
    def create_workflow(self, name: str, steps: list):
        """Create automation workflow"""
        self.workflows[name] = {
            'steps': steps,
            'created_at': datetime.now().isoformat()
        }
    
    def execute_workflow(self, name: str) -> bool:
        """Execute automation workflow"""
        if name not in self.workflows:
            return False
        
        workflow = self.workflows[name]
        for step in workflow['steps']:
            if not self.execute_step(step):
                return False
        return True
    
    def execute_step(self, step: dict) -> bool:
        """Execute individual workflow step"""
        # Implement step execution logic
        return True
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['automation', 'workflows']
'''
    
    def _get_learning_plugin_template(self) -> str:
        """Get learning plugin template"""
        return '''#!/usr/bin/env python3
"""
Learning Plugin Template
Create custom learning algorithms
"""

from core.plugin_architecture import BasePlugin

PLUGIN_METADATA = {
    'name': 'Learning Plugin Template',
    'description': 'Custom learning algorithm plugin',
    'version': '1.0.0',
    'author': 'Your Name',
    'plugin_type': 'learning'
}

class LearningPlugin(BasePlugin):
    """Learning algorithm plugin"""
    
    def initialize(self):
        """Initialize the plugin"""
        super().initialize()
        self.model = None
        self.training_data = []
        return True
    
    def train_model(self, data: list, labels: list):
        """Train machine learning model"""
        # Implement training logic
        self.training_data = list(zip(data, labels))
        self.model = "trained_model"  # Placeholder
    
    def predict(self, input_data: list) -> list:
        """Make predictions using trained model"""
        if not self.model:
            return []
        
        # Implement prediction logic
        predictions = []
        for item in input_data:
            # Predict here
            prediction = self.predict_item(item)
            predictions.append(prediction)
        return predictions
    
    def predict_item(self, item) -> str:
        """Predict single item"""
        # Implement individual prediction
        return "prediction"
    
    def get_capabilities(self):
        """Get plugin capabilities"""
        return ['machine_learning', 'predictions']
'''
    
    def create_plugin(self, plugin_name: str, plugin_type: str, description: str = "") -> str:
        """Create new plugin from template"""
        if plugin_type not in self.templates:
            raise ValueError(f"Unknown plugin type: {plugin_type}")
        
        # Get template
        template = self.templates[plugin_type]
        
        # Replace placeholders
        plugin_code = template.replace('Voice Plugin Template', plugin_name)
        plugin_code = plugin_code.replace('Custom voice command plugin', description)
        
        # Save plugin file
        plugin_dir = self.architecture.plugin_dirs['user']
        plugin_file = plugin_dir / f"{plugin_name.lower().replace(' ', '_')}.py"
        
        with open(plugin_file, 'w') as f:
            f.write(plugin_code)
        
        return str(plugin_file)
    
    def _setup_development_environment(self):
        """Setup development environment"""
        # Create development directories
        dev_dir = Path.home() / '.jarvis' / 'development'
        dev_dir.mkdir(parents=True, exist_ok=True)
        
        # Create plugin templates directory
        templates_dir = dev_dir / 'templates'
        templates_dir.mkdir(exist_ok=True)
        
        # Save templates
        for name, template in self.templates.items():
            template_file = templates_dir / f"{name}_template.py"
            with open(template_file, 'w') as f:
                f.write(template)


# Plugin Lifecycle Manager
class PluginLifecycleManager:
    """Plugin lifecycle event management"""
    
    def __init__(self, plugin_manager):
        self.plugin_manager = plugin_manager
        self.architecture = plugin_manager.architecture
        self.logger = self.architecture.logger
    
    def on_plugin_loaded(self, plugin: BasePlugin):
        """Handle plugin loaded event"""
        try:
            # Register plugin capabilities
            capabilities = plugin.get_capabilities()
            for capability in capabilities:
                self._register_capability(plugin, capability)
            
            # Emit loaded event
            plugin.emit_event('plugin_loaded', {'plugin_id': plugin.plugin_id})
            
        except Exception as e:
            self.logger.error(f"Error handling plugin loaded event: {e}")
    
    def on_plugin_unloaded(self, plugin: BasePlugin):
        """Handle plugin unloaded event"""
        try:
            # Unregister capabilities
            capabilities = plugin.get_capabilities()
            for capability in capabilities:
                self._unregister_capability(plugin, capability)
            
            # Emit unloaded event
            plugin.emit_event('plugin_unloaded', {'plugin_id': plugin.plugin_id})
            
        except Exception as e:
            self.logger.error(f"Error handling plugin unloaded event: {e}")
    
    def _register_capability(self, plugin: BasePlugin, capability: str):
        """Register plugin capability"""
        if capability not in self.architecture.plugin_hooks:
            self.architecture.plugin_hooks[capability] = []
        self.architecture.plugin_hooks[capability].append(plugin)
    
    def _unregister_capability(self, plugin: BasePlugin, capability: str):
        """Unregister plugin capability"""
        if capability in self.architecture.plugin_hooks:
            if plugin in self.architecture.plugin_hooks[capability]:
                self.architecture.plugin_hooks[capability].remove(plugin)


# Performance Monitor
class PerformanceMonitor:
    """Plugin performance monitoring"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.running = False
        self.metrics = {}
    
    def start(self):
        """Start performance monitoring"""
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        self.logger.info("Performance monitoring started")
    
    def stop(self):
        """Stop performance monitoring"""
        self.running = False
        self.logger.info("Performance monitoring stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                self._collect_metrics()
                time.sleep(30)  # Monitor every 30 seconds
            except Exception as e:
                self.logger.error(f"Performance monitoring error: {e}")
    
    def _collect_metrics(self):
        """Collect plugin performance metrics"""
        for plugin_id, plugin in self.architecture.loaded_plugins.items():
            try:
                # Collect basic metrics
                metrics = {
                    'plugin_id': plugin_id,
                    'state': plugin.state,
                    'timestamp': datetime.now().isoformat()
                }
                
                self.metrics[plugin_id] = metrics
                
            except Exception as e:
                self.logger.error(f"Failed to collect metrics for plugin {plugin_id}: {e}")


# Plugin Update Checker
class PluginUpdateChecker:
    """Plugin update checker"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.running = False
    
    def start(self):
        """Start update checker"""
        self.running = True
        self.checker_thread = threading.Thread(target=self._check_loop, daemon=True)
        self.checker_thread.start()
        self.logger.info("Plugin update checker started")
    
    def stop(self):
        """Stop update checker"""
        self.running = False
        self.logger.info("Plugin update checker stopped")
    
    def _check_loop(self):
        """Update checking loop"""
        while self.running:
            try:
                self._check_for_updates()
                time.sleep(3600)  # Check every hour
            except Exception as e:
                self.logger.error(f"Update check error: {e}")
    
    def _check_for_updates(self):
        """Check for plugin updates"""
        # This would check remote repositories for updates
        # For now, just log that we're checking
        self.logger.info("Checking for plugin updates...")


# Plugin Health Monitor
class PluginHealthMonitor:
    """Plugin health monitoring"""
    
    def __init__(self, architecture):
        self.architecture = architecture
        self.logger = architecture.logger
        self.running = False
    
    def start(self):
        """Start health monitor"""
        self.running = True
        self.health_thread = threading.Thread(target=self._health_loop, daemon=True)
        self.health_thread.start()
        self.logger.info("Plugin health monitor started")
    
    def stop(self):
        """Stop health monitor"""
        self.running = False
        self.logger.info("Plugin health monitor stopped")
    
    def _health_loop(self):
        """Health monitoring loop"""
        while self.running:
            try:
                self._check_plugin_health()
                time.sleep(60)  # Check every minute
            except Exception as e:
                self.logger.error(f"Health check error: {e}")
    
    def _check_plugin_health(self):
        """Check health of all loaded plugins"""
        for plugin_id, plugin in self.architecture.loaded_plugins.items():
            try:
                if plugin.state == 'error':
                    self.logger.warning(f"Plugin {plugin_id} is in error state")
                    # Attempt to recover
                    self._attempt_plugin_recovery(plugin_id)
                    
            except Exception as e:
                self.logger.error(f"Health check failed for plugin {plugin_id}: {e}")
    
    def _attempt_plugin_recovery(self, plugin_id: str):
        """Attempt to recover a failed plugin"""
        try:
            self.logger.info(f"Attempting to recover plugin {plugin_id}")
            
            # Unload and reload plugin
            self.architecture.plugin_manager.unload_plugin(plugin_id)
            time.sleep(1)
            self.architecture.plugin_manager.load_plugin(plugin_id)
            
        except Exception as e:
            self.logger.error(f"Failed to recover plugin {plugin_id}: {e}")


# Plugin Database
class PluginDatabase:
    """Plugin metadata database"""
    
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.connection = None
    
    def initialize(self):
        """Initialize database"""
        self.connection = sqlite3.connect(str(self.db_path))
        self._create_tables()
    
    def _create_tables(self):
        """Create database tables"""
        cursor = self.connection.cursor()
        
        # Plugins table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS plugins (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                version TEXT NOT NULL,
                description TEXT,
                author TEXT,
                plugin_type TEXT,
                file_hash TEXT,
                installed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used TIMESTAMP
            )
        ''')
        
        # Plugin ratings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS plugin_ratings (
                plugin_id TEXT,
                user_id TEXT,
                rating INTEGER,
                review TEXT,
                rated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (plugin_id, user_id),
                FOREIGN KEY (plugin_id) REFERENCES plugins (id)
            )
        ''')
        
        self.connection.commit()
    
    def insert_plugin(self, plugin_info: Dict):
        """Insert plugin information"""
        cursor = self.connection.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO plugins 
            (id, name, version, description, author, plugin_type, file_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            plugin_info.get('id'),
            plugin_info.get('name'),
            plugin_info.get('version'),
            plugin_info.get('description'),
            plugin_info.get('author'),
            plugin_info.get('plugin_type'),
            plugin_info.get('file_hash')
        ))
        self.connection.commit()
    
    def get_plugin(self, plugin_id: str) -> Optional[Dict]:
        """Get plugin information"""
        cursor = self.connection.cursor()
        cursor.execute('SELECT * FROM plugins WHERE id = ?', (plugin_id,))
        row = cursor.fetchone()
        
        if row:
            return {
                'id': row[0],
                'name': row[1],
                'version': row[2],
                'description': row[3],
                'author': row[4],
                'plugin_type': row[5],
                'file_hash': row[6],
                'installed_at': row[7],
                'last_used': row[8]
            }
        return None
    
    def close(self):
        """Close database connection"""
        if self.connection:
            self.connection.close()


# Main initialization function
def initialize_plugin_architecture(jarvis_core=None) -> PluginArchitecture:
    """Initialize the plugin architecture system"""
    architecture = PluginArchitecture(jarvis_core)
    
    if architecture.initialize_plugin_system():
        return architecture
    else:
        raise RuntimeError("Failed to initialize plugin architecture")


if __name__ == "__main__":
    # Test the plugin architecture system
    print("JARVIS v11 Plugin Architecture System Test")
    print("=" * 50)
    
    try:
        # Initialize the system
        plugin_system = initialize_plugin_architecture()
        
        print("✓ Plugin Architecture System initialized successfully")
        print(f"✓ Version: {plugin_system.version}")
        print(f"✓ Loaded plugins: {len(plugin_system.loaded_plugins)}")
        print(f"✓ Discovered plugins: {len(plugin_system.plugin_metadata)}")
        
        # Test plugin discovery
        discovered = plugin_system.plugin_manager.list_plugins()
        print(f"✓ Discovered {len(discovered)} plugins")
        
        # Test marketplace
        weather_plugins = plugin_system.marketplace.search_plugins('weather')
        print(f"✓ Found {len(weather_plugins)} weather plugins in marketplace")
        
        print("\n" + "=" * 50)
        print("Plugin Architecture System test completed successfully!")
        
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        if 'plugin_system' in locals():
            plugin_system.shutdown()