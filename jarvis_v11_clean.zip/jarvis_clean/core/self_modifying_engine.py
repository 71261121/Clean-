#!/usr/bin/env python3
"""
JARVIS v11 Enhanced - Advanced Self-Modifying Code Engine
========================================================

एक comprehensive self-modifying code engine जो runtime पर code को safely modify कर सकती है।
Termux compatibility और advanced security features के साथ।

Author: JARVIS v11 Enhanced
Version: 1.0.0
Date: 2025-11-01
"""

import ast
import sys
import os
import time
import hashlib
import json
import zipfile
import shutil
import subprocess
import importlib
import types
import traceback
import pickle
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Set
from contextlib import contextmanager
import threading
import warnings

# Termux API integration (optional)
try:
    import termux_api
    TERMUX_AVAILABLE = True
except ImportError:
    TERMUX_AVAILABLE = False

class SecurityError(Exception):
    """Custom exception for security violations."""
    pass

class CodeValidationError(Exception):
    """Custom exception for code validation failures."""
    pass

class ModuleReloadError(Exception):
    """Custom exception for module reload failures."""
    pass

class SelfModifyingEngine:
    """
    Advanced Self-Modifying Code Engine for JARVIS v11
    
    Features:
    - Dynamic code injection with safety validation
    - Real-time module hot-swapping
    - Version control for code changes
    - Automatic backups and recovery
    - AST-based security analysis
    - Safe execution sandbox
    """
    
    def __init__(self, workspace_dir: str = None, backup_enabled: bool = True):
        """Initialize the self-modifying engine."""
        self.workspace_dir = Path(workspace_dir or os.getcwd())
        self.backup_enabled = backup_enabled
        self.backup_dir = self.workspace_dir / "code_backups"
        self.change_history = self.workspace_dir / "change_history"
        self.whitelist_file = self.workspace_dir / "code_whitelist.json"
        self.sandbox_dir = self.workspace_dir / "sandbox"
        
        # Setup directories
        self._setup_directories()
        
        # Security and validation settings
        self.dangerous_imports = {
            'os', 'sys', 'subprocess', 'eval', 'exec', 'compile',
            '__import__', 'open', 'file', 'input', 'raw_input'
        }
        self.allowed_functions = {
            'print', 'len', 'str', 'int', 'float', 'bool', 'list',
            'dict', 'tuple', 'set', 'range', 'enumerate', 'zip'
        }
        
        # Version control
        self.version_file = self.workspace_dir / "version_history.json"
        self.current_version = self._load_current_version()
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Logging
        self._setup_logging()
        
        # Initialize whitelist
        self._load_whitelist()
        
        self.logger.info("Self-Modifying Engine initialized successfully")
    
    def _setup_directories(self):
        """Setup required directories."""
        directories = [
            self.backup_dir,
            self.change_history,
            self.sandbox_dir,
            self.workspace_dir / "temp"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def _setup_logging(self):
        """Setup logging for the engine."""
        log_file = self.workspace_dir / "logs" / "self_modifying_engine.log"
        log_file.parent.mkdir(exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        
        self.logger = logging.getLogger('SelfModifyingEngine')
    
    def _load_current_version(self) -> Dict[str, Any]:
        """Load current version information."""
        if self.version_file.exists():
            try:
                with open(self.version_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.warning(f"Could not load version file: {e}")
        
        return {
            "version": "1.0.0",
            "build": int(time.time()),
            "changes": [],
            "last_updated": datetime.now().isoformat()
        }
    
    def _save_version_info(self):
        """Save version information."""
        try:
            with open(self.version_file, 'w', encoding='utf-8') as f:
                json.dump(self.current_version, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.logger.error(f"Failed to save version info: {e}")
    
    def _load_whitelist(self):
        """Load code injection whitelist."""
        if self.whitelist_file.exists():
            try:
                with open(self.whitelist_file, 'r', encoding='utf-8') as f:
                    self.whitelist = json.load(f)
            except Exception as e:
                self.logger.warning(f"Could not load whitelist: {e}")
                self.whitelist = {"functions": [], "modules": [], "classes": []}
        else:
            self.whitelist = {"functions": [], "modules": [], "classes": []}
            self._save_whitelist()
    
    def _save_whitelist(self):
        """Save whitelist to file."""
        try:
            with open(self.whitelist_file, 'w', encoding='utf-8') as f:
                json.dump(self.whitelist, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.logger.error(f"Failed to save whitelist: {e}")
    
    @contextmanager
    def _safe_execution_context(self):
        """Context manager for safe code execution."""
        original_stdout = sys.stdout
        original_stderr = sys.stderr
        
        try:
            # Redirect output to capture any prints
            safe_output = []
            
            class SafeOutput:
                def write(self, text):
                    safe_output.append(text)
                    return len(text)
                
                def flush(self):
                    pass
            
            sys.stdout = SafeOutput()
            sys.stderr = SafeOutput()
            
            yield safe_output
            
        finally:
            sys.stdout = original_stdout
            sys.stderr = original_stderr
    
    def validate_code_safety(self, code: str) -> Tuple[bool, List[str]]:
        """
        Validate code for safety using AST parsing and security checks.
        
        Args:
            code: Python code to validate
            
        Returns:
            Tuple of (is_safe, warnings)
        """
        warnings_list = []
        
        try:
            # Parse AST
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, [f"Syntax error: {e}"]
        
        # Security analysis
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name in self.dangerous_imports:
                        warnings_list.append(f"Potentially dangerous import: {alias.name}")
            
            elif isinstance(node, ast.ImportFrom):
                if node.module in self.dangerous_imports:
                    warnings_list.append(f"Potentially dangerous import: {node.module}")
            
            elif isinstance(node, ast.Call):
                # Check for dangerous function calls
                if hasattr(node.func, 'id'):
                    if node.func.id in ['eval', 'exec', 'compile']:
                        warnings_list.append(f"Dangerous function call: {node.func.id}")
        
        # Check against whitelist
        is_whitelisted = self._check_whitelist(code)
        if not is_whitelisted and warnings_list:
            warnings_list.append("Code not in whitelist - manual review recommended")
        
        return len([w for w in warnings_list if 'dangerous' in w.lower()]) == 0, warnings_list
    
    def _check_whitelist(self, code: str) -> bool:
        """Check if code matches whitelist patterns."""
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if node.name not in self.whitelist["functions"]:
                        return False
                elif isinstance(node, ast.ClassDef):
                    if node.name not in self.whitelist["classes"]:
                        return False
            
            return True
        except:
            return False
    
    def create_backup(self, file_path: str) -> str:
        """
        Create backup of file before modification.
        
        Args:
            file_path: Path to file to backup
            
        Returns:
            Backup file path
        """
        with self._lock:
            if not self.backup_enabled:
                return None
            
            source_path = Path(file_path)
            if not source_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{source_path.stem}_{timestamp}{source_path.suffix}"
            backup_path = self.backup_dir / backup_name
            
            try:
                shutil.copy2(source_path, backup_path)
                self.logger.info(f"Backup created: {backup_path}")
                return str(backup_path)
            except Exception as e:
                self.logger.error(f"Failed to create backup: {e}")
                raise
    
    def inject_code(self, target_file: str, code_to_add: str, 
                   position: str = "append", line_number: int = None) -> bool:
        """
        Inject code into target file.
        
        Args:
            target_file: File to inject code into
            code_to_add: Code to inject
            position: Where to inject ('append', 'prepend', 'insert')
            line_number: Line number for 'insert' position
            
        Returns:
            Success status
        """
        with self._lock:
            try:
                # Validate code safety
                is_safe, warnings = self.validate_code_safety(code_to_add)
                if not is_safe:
                    raise SecurityError(f"Code failed safety validation: {warnings}")
                
                target_path = Path(target_file)
                if not target_path.exists():
                    raise FileNotFoundError(f"Target file not found: {target_file}")
                
                # Create backup
                backup_path = self.create_backup(str(target_path))
                
                # Read existing code
                with open(target_path, 'r', encoding='utf-8') as f:
                    original_code = f.read()
                
                # Inject code
                if position == "append":
                    new_code = original_code + "\n\n" + code_to_add + "\n"
                elif position == "prepend":
                    new_code = code_to_add + "\n\n" + original_code
                elif position == "insert" and line_number is not None:
                    lines = original_code.split('\n')
                    lines.insert(line_number - 1, code_to_add)
                    new_code = '\n'.join(lines)
                else:
                    raise ValueError(f"Invalid position: {position}")
                
                # Write modified code
                with open(target_path, 'w', encoding='utf-8') as f:
                    f.write(new_code)
                
                # Record change
                self._record_change(target_file, "inject", {
                    "position": position,
                    "line_number": line_number,
                    "backup": backup_path,
                    "warnings": warnings
                })
                
                self.logger.info(f"Code injected into {target_file}")
                return True
                
            except Exception as e:
                self.logger.error(f"Code injection failed: {e}")
                # Try to restore from backup if available
                if 'backup_path' in locals() and backup_path and Path(backup_path).exists():
                    try:
                        shutil.copy2(backup_path, target_path)
                        self.logger.info("Restored from backup")
                    except Exception as restore_error:
                        self.logger.error(f"Backup restoration failed: {restore_error}")
                raise
    
    def hot_reload_module(self, module_path: str) -> bool:
        """
        Hot reload a Python module without restarting.
        
        Args:
            module_path: Path to Python module
            
        Returns:
            Success status
        """
        with self._lock:
            try:
                module_name = Path(module_path).stem
                
                # Remove from sys.modules if loaded
                if module_name in sys.modules:
                    del sys.modules[module_name]
                
                # Load module using importlib
                spec = importlib.util.spec_from_file_location(module_name, module_path)
                if spec is None:
                    raise ModuleReloadError(f"Could not create module spec for {module_path}")
                
                module = importlib.util.module_from_spec(spec)
                
                # Execute in controlled context
                with self._safe_execution_context() as output:
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)
                
                self.logger.info(f"Module hot-reloaded: {module_path}")
                return True
                
            except Exception as e:
                self.logger.error(f"Hot reload failed: {e}")
                raise ModuleReloadError(f"Failed to reload module {module_path}: {e}")
    
    def replace_function(self, module_path: str, function_name: str, 
                        new_function_code: str) -> bool:
        """
        Replace a specific function in a module.
        
        Args:
            module_path: Path to Python module
            function_name: Name of function to replace
            new_function_code: New function code
            
        Returns:
            Success status
        """
        with self._lock:
            try:
                # Validate new function
                is_safe, warnings = self.validate_code_safety(new_function_code)
                if not is_safe:
                    raise SecurityError(f"Function replacement failed safety validation: {warnings}")
                
                # Read current module
                module_path_obj = Path(module_path)
                with open(module_path_obj, 'r', encoding='utf-8') as f:
                    module_code = f.read()
                
                # Parse AST to find function
                tree = ast.parse(module_code)
                
                function_found = False
                new_lines = []
                
                for i, line in enumerate(module_code.split('\n')):
                    # Look for function definition
                    if f"def {function_name}(" in line:
                        # Skip until end of function
                        indent_level = len(line) - len(line.lstrip())
                        new_lines.append(line)  # Keep original for now
                        
                        # Read function body until matching indentation
                        function_lines = [line]
                        j = i + 1
                        while j < len(module_code.split('\n')):
                            next_line = module_code.split('\n')[j]
                            if next_line.strip() and len(next_line) - len(next_line.lstrip()) <= indent_level:
                                break
                            function_lines.append(next_line)
                            j += 1
                        
                        # Add new function code
                        new_lines.append(new_function_code)
                        new_lines.append("")  # Add empty line
                        
                        # Skip old function lines
                        for _ in range(j - i - 1):
                            if j < len(module_code.split('\n')):
                                j += 1
                        
                        function_found = True
                    else:
                        new_lines.append(line)
                
                if not function_found:
                    # Function not found, add it
                    new_lines.append("\n")
                    new_lines.append(new_function_code)
                
                # Write modified code
                new_code = '\n'.join(new_lines)
                
                # Create backup
                backup_path = self.create_backup(str(module_path))
                
                # Write new code
                with open(module_path_obj, 'w', encoding='utf-8') as f:
                    f.write(new_code)
                
                # Hot reload module
                self.hot_reload_module(str(module_path))
                
                # Record change
                self._record_change(module_path, "replace_function", {
                    "function_name": function_name,
                    "backup": backup_path,
                    "warnings": warnings
                })
                
                self.logger.info(f"Function {function_name} replaced in {module_path}")
                return True
                
            except Exception as e:
                self.logger.error(f"Function replacement failed: {e}")
                raise
    
    def update_from_github(self, repo_url: str, branch: str = "main") -> bool:
        """
        Update code from GitHub repository.
        
        Args:
            repo_url: GitHub repository URL
            branch: Branch to update from
            
        Returns:
            Success status
        """
        with self._lock:
            try:
                # Download repository as zip
                zip_url = f"{repo_url}/archive/{branch}.zip"
                zip_path = self.workspace_dir / "temp" / "update.zip"
                
                # Use wget/curl to download (termux compatible)
                result = subprocess.run([
                    'wget', '-q', '-O', str(zip_path), zip_url
                ], capture_output=True, text=True)
                
                if result.returncode != 0:
                    # Try curl if wget fails
                    result = subprocess.run([
                        'curl', '-L', '-o', str(zip_path), zip_url
                    ], capture_output=True, text=True)
                
                if result.returncode != 0:
                    raise Exception(f"Failed to download repository: {result.stderr}")
                
                # Extract and apply updates
                extract_dir = self.workspace_dir / "temp" / "extracted"
                extract_dir.mkdir(exist_ok=True)
                
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)
                
                # Find extracted directory
                extracted_dirs = [d for d in extract_dir.iterdir() if d.is_dir()]
                if not extracted_dirs:
                    raise Exception("No directories found in extracted archive")
                
                repo_dir = extracted_dirs[0]
                
                # Apply updates with backup
                self._backup_all_code()
                
                # Copy files (excluding unwanted ones)
                for file_path in repo_dir.rglob('*'):
                    if file_path.is_file():
                        relative_path = file_path.relative_to(repo_dir)
                        target_path = self.workspace_dir / relative_path
                        
                        # Skip certain files
                        if any(part.startswith('.') for part in relative_path.parts):
                            continue
                        if 'test' in str(relative_path).lower():
                            continue
                        
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(file_path, target_path)
                
                # Clean up
                shutil.rmtree(extract_dir)
                zip_path.unlink()
                
                # Update version
                self._increment_version("github_update", {
                    "repo_url": repo_url,
                    "branch": branch
                })
                
                self.logger.info(f"Successfully updated from GitHub: {repo_url}")
                return True
                
            except Exception as e:
                self.logger.error(f"GitHub update failed: {e}")
                raise
    
    def _backup_all_code(self):
        """Create backup of all code files."""
        if not self.backup_enabled:
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        full_backup = self.backup_dir / f"full_backup_{timestamp}.zip"
        
        with zipfile.ZipFile(full_backup, 'w') as zip_ref:
            for file_path in self.workspace_dir.rglob('*.py'):
                if 'backup' not in str(file_path) and 'temp' not in str(file_path):
                    arc_name = file_path.relative_to(self.workspace_dir)
                    zip_ref.write(file_path, arc_name)
        
        self.logger.info(f"Full code backup created: {full_backup}")
    
    def _record_change(self, file_path: str, change_type: str, details: Dict[str, Any]):
        """Record change in history."""
        change_record = {
            "timestamp": datetime.now().isoformat(),
            "file": file_path,
            "type": change_type,
            "details": details,
            "version": self.current_version["version"],
            "build": self.current_version["build"]
        }
        
        history_file = self.change_history / f"changes_{datetime.now().strftime('%Y%m%d')}.json"
        
        # Append to daily change file
        changes = []
        if history_file.exists():
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    changes = json.load(f)
            except:
                changes = []
        
        changes.append(change_record)
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(changes, f, indent=2, ensure_ascii=False)
    
    def _increment_version(self, change_type: str, details: Dict[str, Any]):
        """Increment version after changes."""
        self.current_version["build"] += 1
        self.current_version["last_updated"] = datetime.now().isoformat()
        
        change_entry = {
            "build": self.current_version["build"],
            "type": change_type,
            "details": details,
            "timestamp": datetime.now().isoformat()
        }
        
        self.current_version["changes"].append(change_entry)
        self._save_version_info()
    
    def rollback_change(self, change_id: str) -> bool:
        """
        Rollback to a previous version.
        
        Args:
            change_id: Change ID or build number to rollback to
            
        Returns:
            Success status
        """
        with self._lock:
            try:
                # Find the change to rollback to
                target_build = None
                if change_id.isdigit():
                    target_build = int(change_id)
                else:
                    # Search in history files
                    for history_file in self.change_history.glob("changes_*.json"):
                        with open(history_file, 'r', encoding='utf-8') as f:
                            changes = json.load(f)
                            for change in changes:
                                if change.get("timestamp") == change_id or change.get("id") == change_id:
                                    target_build = change.get("build")
                                    break
                        if target_build:
                            break
                
                if target_build is None:
                    raise ValueError(f"Could not find change: {change_id}")
                
                # Get the target version
                target_version = None
                for change in reversed(self.current_version["changes"]):
                    if change["build"] <= target_build:
                        target_version = change
                        break
                
                if not target_version:
                    raise ValueError(f"Could not rollback to build {target_build}")
                
                # Find appropriate backup
                backup_files = list(self.backup_dir.glob("*.py"))
                if not backup_files:
                    raise FileNotFoundError("No backup files found")
                
                # Simple rollback - restore from latest backup
                # In a full implementation, this would be more sophisticated
                latest_backup = max(backup_files, key=lambda x: x.stat().st_mtime)
                shutil.copy2(latest_backup, self.workspace_dir / latest_backup.name)
                
                self.logger.info(f"Rolled back to build {target_build}")
                return True
                
            except Exception as e:
                self.logger.error(f"Rollback failed: {e}")
                raise
    
    def get_code_signature(self, file_path: str) -> str:
        """
        Get cryptographic signature of code file.
        
        Args:
            file_path: Path to file
            
        Returns:
            SHA256 hash of file content
        """
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
                return hashlib.sha256(content).hexdigest()
        except Exception as e:
            self.logger.error(f"Failed to get code signature: {e}")
            raise
    
    def verify_code_integrity(self, file_path: str, expected_signature: str) -> bool:
        """
        Verify code file integrity.
        
        Args:
            file_path: Path to file
            expected_signature: Expected SHA256 hash
            
        Returns:
            Integrity check result
        """
        try:
            actual_signature = self.get_code_signature(file_path)
            return actual_signature == expected_signature
        except Exception as e:
            self.logger.error(f"Integrity verification failed: {e}")
            return False
    
    def list_changes(self, days: int = 7) -> List[Dict[str, Any]]:
        """
        List recent code changes.
        
        Args:
            days: Number of days to look back
            
        Returns:
            List of change records
        """
        changes = []
        cutoff_date = datetime.now().timestamp() - (days * 24 * 3600)
        
        for history_file in self.change_history.glob("changes_*.json"):
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    file_changes = json.load(f)
                    
                for change in file_changes:
                    change_time = datetime.fromisoformat(change["timestamp"]).timestamp()
                    if change_time >= cutoff_date:
                        changes.append(change)
            except Exception as e:
                self.logger.warning(f"Could not read history file {history_file}: {e}")
        
        return sorted(changes, key=lambda x: x["timestamp"], reverse=True)
    
    def export_whitelist(self, file_path: str):
        """Export current whitelist to file."""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(self.whitelist, f, indent=2, ensure_ascii=False)
            self.logger.info(f"Whitelist exported to {file_path}")
        except Exception as e:
            self.logger.error(f"Failed to export whitelist: {e}")
            raise
    
    def import_whitelist(self, file_path: str):
        """Import whitelist from file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                self.whitelist = json.load(f)
            self._save_whitelist()
            self.logger.info(f"Whitelist imported from {file_path}")
        except Exception as e:
            self.logger.error(f"Failed to import whitelist: {e}")
            raise
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get system information relevant to self-modifying engine."""
        return {
            "termux_available": TERMUX_AVAILABLE,
            "python_version": sys.version,
            "workspace_dir": str(self.workspace_dir),
            "backup_enabled": self.backup_enabled,
            "current_version": self.current_version,
            "whitelist_size": {
                "functions": len(self.whitelist.get("functions", [])),
                "modules": len(self.whitelist.get("modules", [])),
                "classes": len(self.whitelist.get("classes", []))
            },
            "backup_dir": str(self.backup_dir),
            "change_history_dir": str(self.change_history)
        }
    
    def health_check(self) -> Dict[str, Any]:
        """Perform health check of the engine."""
        health = {
            "status": "healthy",
            "checks": {},
            "warnings": [],
            "errors": []
        }
        
        # Check directories
        dirs_to_check = [self.backup_dir, self.change_history, self.sandbox_dir]
        for directory in dirs_to_check:
            try:
                if directory.exists():
                    health["checks"][f"directory_{directory.name}"] = "ok"
                else:
                    health["checks"][f"directory_{directory.name}"] = "missing"
                    health["warnings"].append(f"Missing directory: {directory}")
            except Exception as e:
                health["checks"][f"directory_{directory.name}"] = "error"
                health["errors"].append(f"Directory check failed for {directory}: {e}")
        
        # Check permissions
        try:
            test_file = self.sandbox_dir / "test_permissions.tmp"
            test_file.write_text("test")
            test_file.unlink()
            health["checks"]["file_permissions"] = "ok"
        except Exception as e:
            health["checks"]["file_permissions"] = "error"
            health["errors"].append(f"File permission check failed: {e}")
        
        # Check disk space
        try:
            stat = shutil.disk_usage(self.workspace_dir)
            free_gb = stat.free / (1024**3)
            if free_gb < 1:
                health["warnings"].append(f"Low disk space: {free_gb:.2f}GB free")
            health["checks"]["disk_space"] = f"{free_gb:.2f}GB free"
        except Exception as e:
            health["checks"]["disk_space"] = "unknown"
            health["warnings"].append(f"Could not check disk space: {e}")
        
        # Overall status
        if health["errors"]:
            health["status"] = "error"
        elif health["warnings"]:
            health["status"] = "warning"
        
        return health


# Utility functions for external use

def create_safe_execution_environment():
    """Create a safe execution environment for running modified code."""
    safe_globals = {
        '__builtins__': {
            'print': print,
            'len': len,
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict,
            'tuple': tuple,
            'set': set,
            'range': range,
            'enumerate': enumerate,
            'zip': zip,
            'type': type,
            'isinstance': isinstance,
            'hasattr': hasattr,
            'getattr': getattr,
            'setattr': setattr,
        }
    }
    safe_locals = {}
    return safe_globals, safe_locals

def safe_eval(expression: str, safe_globals: Dict = None, safe_locals: Dict = None) -> Any:
    """
    Safely evaluate an expression with restricted execution.
    
    Args:
        expression: Expression to evaluate
        safe_globals: Safe global variables
        safe_locals: Safe local variables
        
    Returns:
        Evaluation result
    """
    if safe_globals is None or safe_locals is None:
        safe_globals, safe_locals = create_safe_execution_environment()
    
    # Additional safety checks
    dangerous_patterns = ['eval', 'exec', 'compile', '__import__', 'open', 'file']
    for pattern in dangerous_patterns:
        if pattern in expression:
            raise SecurityError(f"Dangerous pattern detected: {pattern}")
    
    try:
        # Parse and validate AST
        tree = ast.parse(expression)
        
        # Check AST for dangerous constructs
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom, ast.Call)):
                if hasattr(node, 'func') and hasattr(node.func, 'id'):
                    if node.func.id in dangerous_patterns:
                        raise SecurityError(f"Dangerous function call: {node.func.id}")
        
        # Safe evaluation
        return eval(expression, safe_globals, safe_locals)
    except Exception as e:
        raise SecurityError(f"Safe evaluation failed: {e}")


# Example usage and testing
if __name__ == "__main__":
    # Initialize engine
    engine = SelfModifyingEngine()
    
    # Health check
    health = engine.health_check()
    print(f"Engine health: {health}")
    
    # System info
    info = engine.get_system_info()
    print(f"System info: {info}")
    
    # Example code validation
    test_code = """
def safe_function(x, y):
    return x + y

result = safe_function(1, 2)
print(result)
"""
    
    is_safe, warnings = engine.validate_code_safety(test_code)
    print(f"Code safety: {is_safe}, Warnings: {warnings}")
    
    print("Self-Modifying Engine initialized and ready!")