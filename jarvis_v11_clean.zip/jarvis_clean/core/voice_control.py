#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JARVIS v11 Enhanced - Voice Control System
Comprehensive voice control implementation with termux integration

Features:
- Speech-to-Text recognition using termux API
- Text-to-Speech with natural AI responses
- Continuous voice listening (always-on)
- Wake word detection ("Hey JARVIS")
- Multi-language support (Hindi + English)
- Voice command parsing and execution
- Background voice service
- Error handling and graceful degradation
"""

import os
import sys
import json
import time
import threading
import subprocess
import queue
import logging
from typing import Optional, Dict, List, Callable, Any
from datetime import datetime
from pathlib import Path
import re
from dataclasses import dataclass
from enum import Enum

# Termux API imports (for Android devices)
try:
    import speech_recognition as sr
    from termux_tts import TTS
except ImportError:
    # Fallback for non-termux environments
    sr = None
    TTS = None

# Core JARVIS imports
try:
    from .ai_engine import EnhancedAIEngine
    from .world_data import WorldDataManager
except ImportError:
    # For standalone testing
    from ai_engine import EnhancedAIEngine
    from world_data import WorldDataManager

# Configure logging
log_dir = os.path.join(os.path.dirname(__file__), '..', 'logs')
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, 'voice_control.log')),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class VoiceState(Enum):
    """Voice control states"""
    INACTIVE = "inactive"
    LISTENING = "listening" 
    PROCESSING = "processing"
    SPEAKING = "speaking"
    ERROR = "error"


@dataclass
class VoiceCommand:
    """Voice command structure"""
    command: str
    parameters: List[str]
    confidence: float
    timestamp: datetime
    language: str = "en"


class VoiceActivityDetector:
    """Voice activity detection for continuous listening"""
    
    def __init__(self, energy_threshold: float = 300.0):
        self.energy_threshold = energy_threshold
        self.is_termux = self._check_termux_environment()
        
    def _check_termux_environment(self) -> bool:
        """Check if running in termux environment"""
        return (
            os.path.exists('/data/data/com.termux') or
            os.path.exists('/system/build.prop') or
            'TERMUX_VERSION' in os.environ
        )
    
    def detect_speech_activity(self, audio_data) -> bool:
        """Detect if there's speech activity in audio"""
        if not audio_data:
            return False
            
        try:
            # Calculate RMS (Root Mean Square) for energy detection using built-in math
            if not audio_data:
                return False
            
            # Simple RMS calculation without numpy
            sum_squares = sum(x * x for x in audio_data)
            if len(audio_data) > 0:
                rms = (sum_squares / len(audio_data)) ** 0.5
            else:
                rms = 0.0
            
            return rms > self.energy_threshold
        except Exception:
            # Fallback simple detection
            return len(audio_data) > 1000


class WakeWordDetector:
    """Wake word detection for "Hey JARVIS" activation"""
    
    def __init__(self):
        self.wake_words = [
            "hey jarvis", "jarvis", "hey jarvis",
            "जार्विस", "हे जार्विस", "जार्विस जी",
            "जैरविस", "हे जैरविस"
        ]
        self.is_active = False
        
    def detect_wake_word(self, text: str) -> bool:
        """Detect if wake word is present in text"""
        text_lower = text.lower().strip()
        
        for wake_word in self.wake_words:
            if wake_word in text_lower:
                logger.info(f"Wake word detected: '{wake_word}'")
                return True
        return False


class VoiceCommandParser:
    """Parse and execute voice commands"""
    
    def __init__(self):
        self.command_patterns = {
            # System commands
            'battery': [
                r'.*battery.*status.*',
                r'.*बैटरी.*स्थिति.*',
                r'.*बैटरी.*कैसी.*',
                r'.*पावर.*कैसी.*'
            ],
            'system_check': [
                r'.*system.*check.*',
                r'.*सिस्टम.*चेक.*',
                r'.*सिस्टम.*टेस्ट.*',
                r'.*जांच.*करो.*'
            ],
            'camera': [
                r'.*open.*camera.*',
                r'.*कैमरा.*खोलो.*',
                r'.*कैमरा.*चालू.*',
                r'.*camera.*खोलो.*'
            ],
            'install': [
                r'.*install.*',
                r'.*इंस्टॉल.*करो.*',
                r'.*डाउनलोड.*',
                r'.*सेटअप.*'
            ],
            'find': [
                r'.*find.*',
                r'.*खोजो.*',
                r'.*ढूंढो.*',
                r'.*search.*'
            ]
        }
    
    def parse_command(self, text: str) -> Optional[VoiceCommand]:
        """Parse voice command text"""
        text_clean = re.sub(r'[^\w\s]', ' ', text.lower())
        text_clean = ' '.join(text_clean.split())
        
        # Try to match command patterns
        for command_type, patterns in self.command_patterns.items():
            for pattern in patterns:
                if re.match(pattern, text_clean):
                    parameters = self._extract_parameters(text_clean)
                    return VoiceCommand(
                        command=command_type,
                        parameters=parameters,
                        confidence=0.9,
                        timestamp=datetime.now(),
                        language=self._detect_language(text)
                    )
        
        # If no pattern matches, treat as general query
        return VoiceCommand(
            command='general_query',
            parameters=[text_clean],
            confidence=0.7,
            timestamp=datetime.now(),
            language=self._detect_language(text)
        )
    
    def _extract_parameters(self, text: str) -> List[str]:
        """Extract parameters from command text"""
        # Simple parameter extraction - can be enhanced
        words = text.split()
        if len(words) > 1:
            return words[1:]
        return []
    
    def _detect_language(self, text: str) -> str:
        """Detect language of the input text"""
        # Simple detection based on Hindi characters
        hindi_chars = 'अआइईउऊऋॠऌॡओऔंकखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह'
        return 'hi' if any(char in text for char in hindi_chars) else 'en'


class TermuxTTS:
    """Text-to-Speech using termux-tts-speak"""
    
    def __init__(self):
        self.is_termux = self._check_termux()
        
    def _check_termux(self) -> bool:
        """Check if termux-tts-speak is available"""
        try:
            result = subprocess.run(
                ['which', 'termux-tts-speak'],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def speak(self, text: str, language: str = "en") -> bool:
        """Speak text using TTS"""
        try:
            if self.is_termux:
                # Use termux-tts-speak
                cmd = ['termux-tts-speak']
                if language == 'hi':
                    cmd.extend(['-l', 'hi'])
                cmd.append(text)
                
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                return result.returncode == 0
            else:
                # Fallback to pyttsx3 or system TTS
                return self._fallback_tts(text, language)
        except Exception as e:
            logger.error(f"TTS Error: {e}")
            return False
    
    def _fallback_tts(self, text: str, language: str) -> bool:
        """Fallback TTS implementation"""
        try:
            if TTS:
                tts = TTS()
                if language == 'hi':
                    tts.set_language('hi')
                tts.say(text)
                return True
            else:
                # Simple text output fallback
                print(f"🔊 JARVIS: {text}")
                return True
        except Exception as e:
            logger.error(f"Fallback TTS Error: {e}")
            return False


class TermuxSTT:
    """Speech-to-Text using termux-speech-to-text"""
    
    def __init__(self):
        self.recognizer = None
        self.microphone = None
        self.is_termux = self._check_termux()
        self._initialize_audio()
    
    def _check_termux(self) -> bool:
        """Check if termux-speech-to-text is available"""
        try:
            result = subprocess.run(
                ['which', 'termux-speech-to-text'],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def _initialize_audio(self):
        """Initialize audio devices"""
        try:
            if sr:
                self.recognizer = sr.Recognizer()
                self.microphone = sr.Microphone()
                # Adjust for ambient noise
                with self.microphone as source:
                    self.recognizer.adjust_for_ambient_noise(source, duration=1)
        except Exception as e:
            logger.warning(f"Audio initialization failed: {e}")
    
    def listen(self, timeout: int = 5) -> Optional[str]:
        """Listen for speech and convert to text"""
        try:
            if self.is_termux:
                return self._termux_stt(timeout)
            else:
                return self._fallback_stt(timeout)
        except Exception as e:
            logger.error(f"STT Error: {e}")
            return None
    
    def _termux_stt(self, timeout: int) -> Optional[str]:
        """Use termux-speech-to-text"""
        try:
            result = subprocess.run(
                ['termux-speech-to-text', '-t', str(timeout)],
                capture_output=True,
                text=True,
                timeout=timeout + 2
            )
            
            if result.returncode == 0:
                text = result.stdout.strip()
                logger.info(f"STT Result: {text}")
                return text
            return None
        except Exception as e:
            logger.error(f"Termux STT Error: {e}")
            return None
    
    def _fallback_stt(self, timeout: int) -> Optional[str]:
        """Fallback STT using speech_recognition"""
        try:
            if not self.recognizer or not self.microphone:
                return None
            
            with self.microphone as source:
                logger.info("🎤 Listening...")
                audio = self.recognizer.listen(source, timeout=timeout)
                
                # Try multiple recognition services
                services = [
                    lambda: self.recognizer.recognize_google(audio, language='en-US'),
                    lambda: self.recognizer.recognize_google(audio, language='hi-IN')
                ]
                
                for service in services:
                    try:
                        text = service()
                        logger.info(f"STT Result: {text}")
                        return text
                    except sr.UnknownValueError:
                        continue
                    except sr.RequestError:
                        continue
                
                return None
        except Exception as e:
            logger.error(f"Fallback STT Error: {e}")
            return None


class VoiceCommandExecutor:
    """Execute voice commands"""
    
    def __init__(self):
        self.ai_engine = EnhancedAIEngine()
        self.world_data = WorldDataManager()
        self.command_handlers = {
            'battery': self._handle_battery_status,
            'system_check': self._handle_system_check,
            'camera': self._handle_camera,
            'install': self._handle_install,
            'find': self._handle_find,
            'general_query': self._handle_general_query
        }
    
    def execute_command(self, command: VoiceCommand) -> str:
        """Execute voice command and return response"""
        try:
            handler = self.command_handlers.get(command.command)
            if handler:
                return handler(command)
            else:
                return "अदृश्य कमांड, कृपया दोबारा कोशिश करें।"
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            return "कमांड execution में error हुआ है।"
    
    def _handle_battery_status(self, command: VoiceCommand) -> str:
        """Handle battery status query"""
        try:
            if self._check_termux():
                result = subprocess.run(
                    ['termux-battery-status'],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0:
                    battery_data = json.loads(result.stdout)
                    percentage = battery_data.get('percentage', 'Unknown')
                    status = battery_data.get('status', 'Unknown')
                    return f"बैटरी {percentage}% है, स्थिति: {status}"
            else:
                # Desktop fallback
                import psutil
                battery = psutil.sensors_battery()
                if battery:
                    percentage = battery.percent
                    return f"बैटरी {percentage}% है।"
        except Exception as e:
            logger.error(f"Battery check error: {e}")
        
        return "बैटरी स्थिति जांचने में समस्या हुई है।"
    
    def _handle_system_check(self, command: VoiceCommand) -> str:
        """Handle system check"""
        try:
            # Simple system check implementation
            import platform
            system_info = {
                'OS': platform.system(),
                'Version': platform.version(),
                'Machine': platform.machine(),
                'Python': platform.python_version()
            }
            
            response = "सिस्टम चेक परिणाम: "
            for key, value in system_info.items():
                response += f"{key} {value}, "
            
            return response[:-2] + "।"
        except Exception as e:
            logger.error(f"System check error: {e}")
            return "सिस्टम चेक में error हुआ है।"
    
    def _handle_camera(self, command: VoiceCommand) -> str:
        """Handle camera open command"""
        try:
            if self._check_termux():
                # Try to open camera app on Android
                result = subprocess.run(
                    ['termux-open', '/system/bin/_camera'],
                    capture_output=True
                )
                if result.returncode == 0:
                    return "कैमरा खोल दिया गया है।"
            
            return "कैमरा खोलने की सुविधा उपलब्ध नहीं है।"
        except Exception as e:
            logger.error(f"Camera error: {e}")
            return "कैमरा खोलने में समस्या हुई है।"
    
    def _handle_install(self, command: VoiceCommand) -> str:
        """Handle package installation"""
        if not command.parameters:
            return "कृपया बताएं कि कौन सा package install करना है।"
        
        package_name = ' '.join(command.parameters)
        
        try:
            if self._check_termux():
                result = subprocess.run(
                    ['pkg', 'install', '-y', package_name],
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0:
                    return f"{package_name} successfully install हो गया है।"
                else:
                    return f"{package_name} install करने में समस्या हुई है।"
            else:
                return "Package installation केवल termux में available है।"
        except Exception as e:
            logger.error(f"Installation error: {e}")
            return "Installation में error हुआ है।"
    
    def _handle_find(self, command: VoiceCommand) -> str:
        """Handle file find command"""
        if not command.parameters:
            return "कृपया बताएं कि क्या खोजना है।"
        
        search_term = ' '.join(command.parameters)
        
        try:
            if self._check_termux():
                result = subprocess.run(
                    ['find', '/data/data/com.termux', '-name', f'*{search_term}*', '-type', 'f'],
                    capture_output=True,
                    text=True
                )
                if result.stdout.strip():
                    files = result.stdout.strip().split('\n')[:5]  # Show first 5 results
                    return f"मिले files: {' '.join(files[:3])}"
                else:
                    return f"'{search_term}' कोई file नहीं मिली।"
            else:
                return "File search केवल termux में available है।"
        except Exception as e:
            logger.error(f"Find error: {e}")
            return "File खोजने में समस्या हुई है।"
    
    def _handle_general_query(self, command: VoiceCommand) -> str:
        """Handle general queries using AI engine"""
        try:
            query = ' '.join(command.parameters)
            response = self.ai_engine.generate_response(query)
            return response
        except Exception as e:
            logger.error(f"General query error: {e}")
            return "Query process करने में समस्या हुई है।"
    
    def _check_termux(self) -> bool:
        """Check if running in termux"""
        return (
            os.path.exists('/data/data/com.termux') or
            'TERMUX_VERSION' in os.environ
        )


class VoiceControlSystem:
    """Main voice control system for JARVIS"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.state = VoiceState.INACTIVE
        self.is_listening = False
        self.is_running = False
        
        # Initialize components
        self.stt = TermuxSTT()
        self.tts = TermuxTTS()
        self.wake_word_detector = WakeWordDetector()
        self.voice_activity_detector = VoiceActivityDetector()
        self.command_parser = VoiceCommandParser()
        self.command_executor = VoiceCommandExecutor()
        
        # Voice queue for command processing
        self.command_queue = queue.Queue()
        self.response_queue = queue.Queue()
        
        # Threading for background processing
        self.background_thread = None
        
        logger.info("Voice Control System initialized")
    
    def start_voice_control(self) -> bool:
        """Start continuous voice control"""
        try:
            if self.is_running:
                logger.warning("Voice control already running")
                return False
            
            self.is_running = True
            self.is_listening = True
            self.state = VoiceState.LISTENING
            
            # Start background listening thread
            self.background_thread = threading.Thread(
                target=self._continuous_listening,
                daemon=True
            )
            self.background_thread.start()
            
            # Start command processing thread
            processing_thread = threading.Thread(
                target=self._process_commands,
                daemon=True
            )
            processing_thread.start()
            
            logger.info("🎤 Voice control started - Say 'Hey JARVIS' to activate")
            self._speak_response("Voice control शुरू हो गया। Hey JARVIS कहें to activate करने के लिए।")
            
            return True
        except Exception as e:
            logger.error(f"Failed to start voice control: {e}")
            return False
    
    def stop_voice_control(self):
        """Stop voice control"""
        try:
            self.is_running = False
            self.is_listening = False
            self.state = VoiceState.INACTIVE
            
            logger.info("Voice control stopped")
            self._speak_response("Voice control बंद कर दिया गया।")
        except Exception as e:
            logger.error(f"Error stopping voice control: {e}")
    
    def _continuous_listening(self):
        """Continuous voice listening in background"""
        logger.info("Continuous listening started")
        
        while self.is_running:
            try:
                if self.is_listening:
                    # Check for voice activity
                    audio = self._record_audio()
                    if audio and self.voice_activity_detector.detect_speech_activity(audio):
                        self._process_voice_input()
                
                time.sleep(0.1)  # Small delay to prevent excessive CPU usage
                
            except Exception as e:
                logger.error(f"Continuous listening error: {e}")
                time.sleep(1)  # Longer delay on error
    
    def _record_audio(self) -> Optional[bytes]:
        """Record audio for voice activity detection"""
        try:
            # Simple audio recording - can be enhanced with proper audio handling
            # For now, return dummy audio data to simulate detection
            return b"audio_data_sample"
        except Exception:
            return None
    
    def _process_voice_input(self):
        """Process incoming voice input"""
        try:
            self.state = VoiceState.LISTENING
            
            # Listen for speech
            text = self.stt.listen(timeout=3)
            
            if text:
                logger.info(f"Received: {text}")
                
                # Check for wake word
                if self.wake_word_detector.detect_wake_word(text):
                    self._handle_wake_word_activation()
                else:
                    # If already activated, process as command
                    if self.is_listening:
                        self._process_command(text)
            
        except Exception as e:
            logger.error(f"Voice input processing error: {e}")
            self.state = VoiceState.ERROR
    
    def _handle_wake_word_activation(self):
        """Handle wake word activation"""
        logger.info("🔊 Wake word activated - Now listening for commands")
        self._speak_response("हाँ, मैं सुन रहा हूं।")
        
        # Listen for command
        command_text = self.stt.listen(timeout=5)
        
        if command_text:
            self._process_command(command_text)
        else:
            self._speak_response("कोई कमांड नहीं मिली।")
    
    def _process_command(self, command_text: str):
        """Process voice command"""
        try:
            self.state = VoiceState.PROCESSING
            
            # Parse command
            command = self.command_parser.parse_command(command_text)
            
            if command:
                logger.info(f"Executing command: {command.command}")
                self.command_queue.put(command)
            else:
                self._speak_response("कमांड समझ नहीं आया। कृपया दोबारा कहें।")
        
        except Exception as e:
            logger.error(f"Command processing error: {e}")
            self._speak_response("कमांड process करने में error हुआ है।")
    
    def _process_commands(self):
        """Process commands from queue"""
        logger.info("Command processing started")
        
        while self.is_running:
            try:
                if not self.command_queue.empty():
                    command = self.command_queue.get(timeout=1)
                    response = self.command_executor.execute_command(command)
                    self._speak_response(response)
                    self.command_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Command processing thread error: {e}")
    
    def _speak_response(self, text: str):
        """Speak response using TTS"""
        try:
            self.state = VoiceState.SPEAKING
            
            # Detect language for TTS
            language = self._detect_language_for_tts(text)
            
            # Speak the response
            if self.tts.speak(text, language):
                logger.info(f"🔊 Spoke: {text}")
            else:
                # Fallback to text display
                print(f"🔊 JARVIS: {text}")
            
            self.state = VoiceState.LISTENING
            
        except Exception as e:
            logger.error(f"TTS error: {e}")
            self.state = VoiceState.ERROR
    
    def _detect_language_for_tts(self, text: str) -> str:
        """Detect language for TTS output"""
        hindi_chars = 'अआइईउऊऋॠऌॡओऔंकखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसह'
        return 'hi' if any(char in text for char in hindi_chars) else 'en'
    
    def get_status(self) -> Dict[str, Any]:
        """Get voice control system status"""
        return {
            'state': self.state.value,
            'is_running': self.is_running,
            'is_listening': self.is_listening,
            'queue_size': self.command_queue.qsize(),
            'termux_available': self.stt.is_termux,
            'tts_available': self.tts.is_termux
        }
    
    def is_voice_available(self) -> bool:
        """Check if voice features are available"""
        return self.stt.is_termux or sr is not None


# Example usage and testing functions
def test_voice_system():
    """Test the voice control system"""
    print("JARVIS v11 - Voice Control System Test")
    print("=" * 50)
    
    # Initialize voice control
    voice_system = VoiceControlSystem()
    
    # Check availability
    if not voice_system.is_voice_available():
        print("❌ Voice features not available on this system")
        return
    
    print("✅ Voice features available")
    
    # Test TTS
    print("\n🧪 Testing Text-to-Speech...")
    if voice_system.tts.speak("JARVIS voice control system test", "en"):
        print("✅ TTS working")
    else:
        print("❌ TTS failed")
    
    # Test wake word detection
    print("\n🧪 Testing Wake Word Detection...")
    test_phrases = ["Hey JARVIS", "हे जार्विस", "hello jarvis"]
    for phrase in test_phrases:
        detected = voice_system.wake_word_detector.detect_wake_word(phrase)
        print(f"'{phrase}' → {'✅' if detected else '❌'}")
    
    # Test command parsing
    print("\n🧪 Testing Command Parsing...")
    test_commands = [
        "JARVIS, what's my battery status?",
        "JARVIS, run system check",
        "जार्विस, बैटरी स्थिति बताओ",
        "JARVIS, install python"
    ]
    
    for cmd in test_commands:
        parsed = voice_system.command_parser.parse_command(cmd)
        if parsed:
            print(f"✅ '{cmd}' → {parsed.command}")
        else:
            print(f"❌ '{cmd}' → Not parsed")
    
    print("\n🎯 Voice control system ready!")


if __name__ == "__main__":
    # Run tests if executed directly
    test_voice_system()