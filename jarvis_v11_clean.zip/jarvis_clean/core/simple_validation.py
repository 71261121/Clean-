"""
JARVIS v11 - Simple Validation System
Pydantic replacement using built-in dataclasses and type hints
Zero compilation issues, pure Python implementation
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union, Type, get_type_hints
import json
import re
from datetime import datetime


class ValidationError(Exception):
    """Custom validation error"""
    pass


class SimpleValidator:
    """Simple validation utilities without Pydantic"""
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def validate_url(url: str) -> bool:
        """Validate URL format"""
        pattern = r'^https?://[^\s/$.?#].[^\s]*$'
        return bool(re.match(pattern, url))
    
    @staticmethod
    def validate_phone(phone: str) -> bool:
        """Validate phone number format"""
        pattern = r'^\+?1?\d{9,15}$'
        return bool(re.match(pattern, phone.replace(' ', '').replace('-', '')))
    
    @staticmethod
    def validate_range(value: Union[int, float], min_val: Union[int, float], max_val: Union[int, float]) -> bool:
        """Validate value is within range"""
        return min_val <= value <= max_val
    
    @staticmethod
    def validate_choices(value: Any, choices: List[Any]) -> bool:
        """Validate value is in allowed choices"""
        return value in choices


@dataclass
class SimpleBaseModel:
    """Base model with basic validation capabilities"""
    
    def __post_init__(self):
        """Run validation after initialization"""
        self.validate()
    
    def validate(self):
        """Validate all fields"""
        for field_name, field_info in self.__dataclass_fields__.items():
            value = getattr(self, field_name, None)
            if value is not None:
                self._validate_field(field_name, value, field_info.type)
    
    def _validate_field(self, name: str, value: Any, field_type: Type):
        """Validate individual field"""
        # Type validation
        if not self._check_type(value, field_type):
            raise ValidationError(f"Field '{name}' must be of type {field_type.__name__}")
    
    def _check_type(self, value: Any, expected_type: Type) -> bool:
        """Check if value matches expected type"""
        if hasattr(expected_type, '__origin__'):
            # Handle generic types like List, Optional, etc.
            return self._check_generic_type(value, expected_type)
        return isinstance(value, expected_type)
    
    def _check_generic_type(self, value: Any, expected_type) -> bool:
        """Handle generic types like List, Optional, Dict"""
        origin = getattr(expected_type, '__origin__', None)
        
        if origin is list:
            return isinstance(value, list)
        elif origin is dict:
            return isinstance(value, dict)
        elif origin is Union:
            # Handle Optional (Union with None)
            return value is None or any(
                isinstance(value, arg) for arg in expected_type.__args__
                if arg is not type(None)
            )
        return False
    
    def dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {field.name: getattr(self, field.name) for field in self.__dataclass_fields__.values()}
    
    def json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.dict(), default=str)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SimpleBaseModel':
        """Create instance from dictionary"""
        return cls(**data)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'SimpleBaseModel':
        """Create instance from JSON string"""
        data = json.loads(json_str)
        return cls.from_dict(data)


# Pre-built validator classes
class StringValidator:
    """String validation utilities"""
    
    @staticmethod
    def min_length(value: str, min_len: int) -> bool:
        return len(value) >= min_len
    
    @staticmethod
    def max_length(value: str, max_len: int) -> bool:
        return len(value) <= max_len
    
    @staticmethod
    def pattern(value: str, pattern: str) -> bool:
        return bool(re.match(pattern, value))


class NumberValidator:
    """Number validation utilities"""
    
    @staticmethod
    def positive(value: Union[int, float]) -> bool:
        return value > 0
    
    @staticmethod
    def non_negative(value: Union[int, float]) -> bool:
        return value >= 0
    
    @staticmethod
    def integer(value: Any) -> bool:
        return isinstance(value, int) and not isinstance(value, bool)
    
    @staticmethod
    def decimal(value: Any) -> bool:
        return isinstance(value, (int, float)) and not isinstance(value, bool)


# Example usage classes
@dataclass
class User(SimpleBaseModel):
    """Simple user model"""
    name: str
    email: str
    age: Optional[int] = None
    
    def __post_init__(self):
        # Custom validation
        if not StringValidator.min_length(self.name, 2):
            raise ValidationError("Name must be at least 2 characters")
        if not SimpleValidator.validate_email(self.email):
            raise ValidationError("Invalid email format")
        if self.age is not None and not NumberValidator.positive(self.age):
            raise ValidationError("Age must be positive")
        super().__post_init__()


@dataclass
class Config(SimpleBaseModel):
    """Simple config model"""
    app_name: str
    version: str
    debug: bool = False
    max_connections: int = 100
    
    def __post_init__(self):
        if not NumberValidator.positive(self.max_connections):
            raise ValidationError("Max connections must be positive")
        super().__post_init__()


@dataclass
class ApiResponse(SimpleBaseModel):
    """Simple API response model"""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if not isinstance(self.success, bool):
            raise ValidationError("Success must be boolean")
        super().__post_init__()


# Validation decorators
def validate_types(**type_hints):
    """Decorator for function parameter validation"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            import inspect
            sig = inspect.signature(func)
            
            # Validate positional arguments
            for i, (param_name, param) in enumerate(sig.parameters.items()):
                if i < len(args) and param.annotation != inspect.Parameter.empty:
                    if not isinstance(args[i], param.annotation):
                        raise ValidationError(f"Parameter '{param_name}' must be of type {param.annotation.__name__}")
            
            # Validate keyword arguments
            for param_name, value in kwargs.items():
                if param_name in sig.parameters:
                    param = sig.parameters[param_name]
                    if param.annotation != inspect.Parameter.empty:
                        if not isinstance(value, param.annotation):
                            raise ValidationError(f"Parameter '{param_name}' must be of type {param.annotation.__name__}")
            
            return func(*args, **kwargs)
        return wrapper
    return decorator


# Built-in type validators
class TypeValidators:
    """Built-in type validation functions"""
    
    @staticmethod
    def is_string(value: Any) -> bool:
        return isinstance(value, str)
    
    @staticmethod
    def is_integer(value: Any) -> bool:
        return isinstance(value, int) and not isinstance(value, bool)
    
    @staticmethod
    def is_float(value: Any) -> bool:
        return isinstance(value, float)
    
    @staticmethod
    def is_boolean(value: Any) -> bool:
        return isinstance(value, bool)
    
    @staticmethod
    def is_list(value: Any) -> bool:
        return isinstance(value, list)
    
    @staticmethod
    def is_dict(value: Any) -> bool:
        return isinstance(value, dict)
    
    @staticmethod
    def is_none(value: Any) -> bool:
        return value is None
    
    @staticmethod
    def is_optional(value: Any, expected_type: Type) -> bool:
        return value is None or isinstance(value, expected_type)


# Export all utilities
__all__ = [
    'SimpleBaseModel',
    'SimpleValidator', 
    'StringValidator',
    'NumberValidator',
    'ValidationError',
    'validate_types',
    'TypeValidators',
    'User',
    'Config', 
    'ApiResponse'
]