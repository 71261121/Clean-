"""
JARVIS v11 - Enhanced AI Engine
100% Secure, No Hardcoded API Keys
Mobile-optimized with fallbacks
"""

import os
import json
import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import httpx

logger = logging.getLogger(__name__)

# Safe aiofiles import with fallback
try:
    import aiofiles
    AIOFILES_AVAILABLE = True
except ImportError:
    AIOFILES_AVAILABLE = False
    logger.warning("⚠️ aiofiles not available, file operations will be limited")

logger = logging.getLogger(__name__)

@dataclass
class AIModel:
    name: str
    provider: str
    max_tokens: int
    cost_per_token: float
    description: str

@dataclass
class AIResponse:
    content: str
    model: str
    tokens_used: int
    cost: float
    response_time: float
    success: bool
    error_message: Optional[str] = None

class EnhancedAIEngine:
    """Enhanced AI engine with multiple provider support and fallbacks"""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)
        self.models = self._load_models()
        self.usage_stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'total_tokens': 0,
            'total_cost': 0.0
        }
    
    def _load_models(self) -> List[AIModel]:
        """Load available AI models"""
        return [
            AIModel(
                name="meta-llama/llama-3.2-3b-instruct:free",
                provider="openrouter",
                max_tokens=2048,
                cost_per_token=0.0,
                description="Free Llama 3.2 3B model"
            ),
            AIModel(
                name="meta-llama/llama-3.2-1b-instruct:free",
                provider="openrouter",
                max_tokens=1024,
                cost_per_token=0.0,
                description="Free Llama 3.2 1B model"
            ),
            AIModel(
                name="qwen/qwen-2-7b-instruct:free",
                provider="openrouter",
                max_tokens=2048,
                cost_per_token=0.0,
                description="Free Qwen 2 7B model"
            ),
            AIModel(
                name="microsoft/phi-3-mini-128k-instruct:free",
                provider="openrouter",
                max_tokens=1024,
                cost_per_token=0.0,
                description="Free Phi-3 Mini model"
            ),
            AIModel(
                name="google/gemma-2-2b-it:free",
                provider="openrouter",
                max_tokens=1024,
                cost_per_token=0.0,
                description="Free Gemma 2 2B model"
            )
        ]
    
    def get_api_key(self) -> str:
        """Get API key from environment with validation"""
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError(
                "OPENROUTER_API_KEY environment variable not found. "
                "Please set your OpenRouter API key: "
                "export OPENROUTER_API_KEY='your-api-key-here'"
            )
        return api_key
    
    async def chat(self, 
                   message: str, 
                   system_prompt: str = "", 
                   model_preference: Optional[str] = None) -> AIResponse:
        """
        Send chat request to AI with fallback models
        
        Args:
            message: User message
            system_prompt: System instructions
            model_preference: Preferred model name
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            # Get API key
            api_key = self.get_api_key()
            
            # Select model (try preference first, then fallback)
            models_to_try = self._select_models(model_preference)
            
            for model in models_to_try:
                response = await self._try_model(model, message, system_prompt, api_key)
                if response.success:
                    return response
            
            # If all models failed
            end_time = asyncio.get_event_loop().time()
            return AIResponse(
                content="Sorry, I'm unable to respond right now. All AI services are currently unavailable.",
                model="none",
                tokens_used=0,
                cost=0.0,
                response_time=end_time - start_time,
                success=False,
                error_message="All models failed"
            )
            
        except Exception as e:
            end_time = asyncio.get_event_loop().time()
            logger.error(f"AI chat error: {e}")
            return AIResponse(
                content=f"Error: {str(e)}",
                model="error",
                tokens_used=0,
                cost=0.0,
                response_time=end_time - start_time,
                success=False,
                error_message=str(e)
            )
    
    def _select_models(self, preference: Optional[str] = None) -> List[AIModel]:
        """Select models to try (preference first, then fallbacks)"""
        if preference:
            # Find preferred model
            for model in self.models:
                if preference.lower() in model.name.lower():
                    # Put preferred first, then others
                    return [model] + [m for m in self.models if m != model]
        
        # Return all models in order
        return self.models
    
    async def _try_model(self, model: AIModel, message: str, system_prompt: str, api_key: str) -> AIResponse:
        """Try a specific model"""
        try:
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://jarvis-v11.termux.ai",
                "X-Title": "JARVIS v11 - Advanced AI Assistant"
            }
            
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": message})
            
            payload = {
                "model": model.name,
                "messages": messages,
                "max_tokens": model.max_tokens,
                "temperature": 0.7,
                "stream": False
            }
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers=headers,
                    json=payload
                )
            
            if response.status_code == 200:
                data = response.json()
                content = data['choices'][0]['message']['content']
                tokens_used = data.get('usage', {}).get('total_tokens', 0)
                cost = tokens_used * model.cost_per_token
                
                # Update stats
                self._update_stats(tokens_used, cost)
                
                return AIResponse(
                    content=content,
                    model=model.name,
                    tokens_used=tokens_used,
                    cost=cost,
                    response_time=0.0,  # Will be set by caller
                    success=True
                )
            else:
                logger.warning(f"Model {model.name} failed with status {response.status_code}")
                return AIResponse(
                    content="",
                    model=model.name,
                    tokens_used=0,
                    cost=0.0,
                    response_time=0.0,
                    success=False,
                    error_message=f"HTTP {response.status_code}: {response.text}"
                )
                
        except Exception as e:
            logger.warning(f"Model {model.name} error: {e}")
            return AIResponse(
                content="",
                model=model.name,
                tokens_used=0,
                cost=0.0,
                response_time=0.0,
                success=False,
                error_message=str(e)
            )
    
    def _update_stats(self, tokens: int, cost: float):
        """Update usage statistics"""
        self.usage_stats['total_requests'] += 1
        self.usage_stats['successful_requests'] += 1
        self.usage_stats['total_tokens'] += tokens
        self.usage_stats['total_cost'] += cost
    
    async def analyze_code(self, code: str) -> AIResponse:
        """Analyze code with AI"""
        system_prompt = (
            "You are a code analysis expert. Analyze the provided code and give "
            "detailed feedback on:\n"
            "1. Code quality and structure\n"
            "2. Potential bugs or issues\n"
            "3. Performance improvements\n"
            "4. Security concerns\n"
            "5. Best practices recommendations\n\n"
            "Provide specific, actionable suggestions."
        )
        
        return await self.chat(
            f"Analyze this Python code:\n\n```{code}\n```",
            system_prompt
        )
    
    async def explain_concept(self, concept: str) -> AIResponse:
        """Explain a technical concept"""
        system_prompt = (
            "You are a knowledgeable technical educator. Explain concepts clearly "
            "and concisely, using examples when helpful. Adapt your explanation "
            "level based on the complexity of the topic."
        )
        
        return await self.chat(
            f"Explain the concept of {concept} in detail:",
            system_prompt
        )
    
    async def generate_code(self, requirement: str, language: str = "python") -> AIResponse:
        """Generate code based on requirements"""
        system_prompt = (
            f"You are an expert {language} programmer. Generate clean, efficient, "
            "and well-documented code that meets the requirements. Include "
            "comments explaining the logic."
        )
        
        return await self.chat(
            f"Generate {language} code for the following requirement:\n{requirement}",
            system_prompt
        )
    
    async def debug_code(self, code: str, error: str = "") -> AIResponse:
        """Help debug code"""
        system_prompt = (
            "You are an expert debugger. Analyze the code and error, identify "
            "the root cause, and provide a clear fix with explanation."
        )
        
        message = f"Debug this {error or 'code'}:\n\n```{code}\n```"
        if error:
            message = f"Error: {error}\n\nCode:\n```{code}\n```"
        
        return await self.chat(message, system_prompt)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get usage statistics"""
        success_rate = 0
        if self.usage_stats['total_requests'] > 0:
            success_rate = (self.usage_stats['successful_requests'] / 
                          self.usage_stats['total_requests']) * 100
        
        return {
            **self.usage_stats,
            'success_rate': success_rate,
            'available_models': len(self.models)
        }
    
    async def save_conversation(self, conversation_data: Dict[str, Any], filename: str = None):
        """Save conversation to file"""
        if not filename:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"conversation_{timestamp}.json"
        
        filepath = os.path.join(os.path.expanduser("~"), "jarvis_v11", "conversations", filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        conversation_data['timestamp'] = asyncio.get_event_loop().time()
        conversation_data['stats'] = self.get_stats()
        
        async with aiofiles.open(filepath, 'w') as f:
            await f.write(json.dumps(conversation_data, indent=2))
        
        logger.info(f"Conversation saved to {filepath}")
        return filepath
    
    async def load_conversations(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Load recent conversations"""
        conversations_dir = os.path.join(os.path.expanduser("~"), "jarvis_v11", "conversations")
        
        if not os.path.exists(conversations_dir):
            return []
        
        conversations = []
        for filename in os.listdir(conversations_dir):
            if filename.endswith('.json'):
                try:
                    filepath = os.path.join(conversations_dir, filename)
                    async with aiofiles.open(filepath, 'r') as f:
                        content = await f.read()
                        conversation = json.loads(content)
                        conversations.append(conversation)
                except Exception as e:
                    logger.warning(f"Failed to load conversation {filename}: {e}")
        
        # Sort by timestamp and return most recent
        conversations.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        return conversations[:limit]
    
    async def close(self):
        """Close the HTTP client"""
        await self.client.aclose()

# Create global instance
ai_engine = EnhancedAIEngine()