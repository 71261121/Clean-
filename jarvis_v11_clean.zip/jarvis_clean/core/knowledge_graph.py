"""
JARVIS v11 Enhanced - Knowledge Graph Engine
Advanced interconnected knowledge representation and reasoning system
Mobile-optimized with continuous learning capabilities
"""

import asyncio
import json
import logging
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Any, Set, Tuple
from dataclasses import dataclass, field
from collections import defaultdict, deque
# Simple graph representation (replace networkx)
class SimpleGraph:
    def __init__(self):
        self.nodes = defaultdict(set)
        self.edges = defaultdict(int)
        self.node_data = {}
    
    def add_node(self, node_id, **properties):
        """Add a node to the graph"""
        if node_id not in self.nodes:
            self.nodes[node_id] = set()
        self.node_data[node_id] = properties
    
    def add_nodes_from(self, node_ids):
        """Add multiple nodes to the graph"""
        for node_id in node_ids:
            self.add_node(node_id)
    
    def add_edge(self, from_node, to_node, weight=1, **properties):
        """Add an edge to the graph"""
        self.nodes[from_node].add(to_node)
        self.edges[(from_node, to_node)] = weight
    
    def add_edges_from(self, edge_list):
        """Add multiple edges to the graph"""
        for from_node, to_node in edge_list:
            self.add_edge(from_node, to_node)
    
    def neighbors(self, node):
        """Get neighbors of a node"""
        return self.nodes.get(node, set())
    
    def degree(self, node):
        """Get degree of a node"""
        return len(self.nodes.get(node, set()))
    
    def degree_items(self):
        """Return iterator of (node, degree) pairs like networkx"""
        for node_id in self.nodes:
            yield (node_id, self.degree(node_id))
    
    def to_undirected(self):
        """Convert to undirected graph (make edges bidirectional)"""
        undirected = SimpleGraph()
        undirected.nodes = defaultdict(set)
        undirected.edges = defaultdict(int)
        undirected.node_data = self.node_data.copy()
        
        for from_node, neighbors in self.nodes.items():
            for to_node in neighbors:
                undirected.nodes[from_node].add(to_node)
                undirected.nodes[to_node].add(from_node)
                undirected.edges[(from_node, to_node)] = self.edges.get((from_node, to_node), 1)
                undirected.edges[(to_node, from_node)] = self.edges.get((from_node, to_node), 1)
        
        return undirected
    
    def clear(self):
        """Clear all nodes and edges"""
        self.nodes.clear()
        self.edges.clear()
        self.node_data.clear()
    
    def nodes(self):
        """Get all nodes"""
        return list(self.nodes.keys())
    
    def has_node(self, node_id):
        """Check if node exists"""
        return node_id in self.nodes
    
    # Graph analysis methods
    def density(self):
        """Calculate graph density"""
        n = len(self.nodes)
        if n <= 1:
            return 0.0
        e = len(self.edges)
        return e / (n * (n - 1))
    
    def average_clustering(self):
        """Calculate average clustering coefficient"""
        if not self.nodes:
            return 0.0
        
        clustering_sum = 0.0
        node_count = 0
        
        for node_id, neighbors in self.nodes.items():
            neighbors = list(neighbors)
            if len(neighbors) < 2:
                continue
            
            possible_edges = len(neighbors) * (len(neighbors) - 1) / 2
            actual_edges = 0
            
            for i, n1 in enumerate(neighbors):
                for j, n2 in enumerate(neighbors):
                    if i < j and n2 in self.nodes[n1]:
                        actual_edges += 1
            
            if possible_edges > 0:
                clustering_sum += actual_edges / possible_edges
                node_count += 1
        
        return clustering_sum / node_count if node_count > 0 else 0.0
    
    def degree_centrality(self):
        """Calculate degree centrality for all nodes"""
        if not self.nodes:
            return {}
        
        max_degree = max(self.degree(node_id) for node_id in self.nodes)
        if max_degree == 0:
            return {node_id: 0.0 for node_id in self.nodes}
        
        centrality = {}
        for node_id in self.nodes:
            degree = self.degree(node_id)
            centrality[node_id] = degree / max_degree
        
        return centrality
    
    def betweenness_centrality(self):
        """Calculate betweenness centrality (simplified)"""
        if not self.nodes:
            return {}
        
        centrality = {node_id: 0.0 for node_id in self.nodes}
        all_nodes = list(self.nodes.keys())
        
        # Simplified betweenness calculation
        for source in all_nodes:
            if source not in self.nodes:
                continue
            
            shortest_paths = self._shortest_paths(source)
            for target in all_nodes:
                if target != source and target in shortest_paths:
                    paths_through = 0
                    all_shortest = self._all_shortest_paths(source, target)
                    
                    if all_shortest:
                        for path in all_shortest:
                            if len(path) > 2:  # source -> intermediate -> target
                                intermediate_nodes = path[1:-1]
                                for intermediate in intermediate_nodes:
                                    if intermediate != source and intermediate != target:
                                        paths_through += 1
                        
                        total_paths = len(all_shortest)
                        if total_paths > 0:
                            centrality[source] += paths_through / total_paths
        
        # Normalize
        n = len(all_nodes)
        if n > 2:
            normalization = 2.0 / ((n - 1) * (n - 2))
            for node_id in centrality:
                centrality[node_id] *= normalization
        
        return centrality
    
    def closeness_centrality(self):
        """Calculate closeness centrality"""
        if not self.nodes:
            return {}
        
        centrality = {}
        all_nodes = list(self.nodes.keys())
        
        for node_id in all_nodes:
            distances = self._shortest_paths(node_id)
            valid_distances = [d for d in distances.values() if d > 0]
            
            if valid_distances:
                centrality[node_id] = len(valid_distances) / sum(valid_distances)
            else:
                centrality[node_id] = 0.0
        
        return centrality
    
    def _shortest_paths(self, source):
        """Calculate shortest paths from source to all nodes"""
        distances = {node_id: float('inf') for node_id in self.nodes}
        distances[source] = 0
        queue = deque([source])
        visited = set()
        
        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            
            for neighbor in self.nodes[current]:
                distance = distances[current] + 1
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    queue.append(neighbor)
        
        return distances
    
    def _all_shortest_paths(self, source, target):
        """Find all shortest paths between source and target"""
        paths = []
        
        def dfs(current, target, path, visited):
            if current == target:
                paths.append(path[:])
                return
            
            for neighbor in self.nodes[current]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    path.append(neighbor)
                    dfs(neighbor, target, path, visited)
                    path.pop()
                    visited.remove(neighbor)
        
        visited = {source}
        dfs(source, target, [source], visited)
        return paths
    
    def shortest_path(self, source, target, weight=None):
        """Find shortest path between source and target"""
        distances = self._shortest_paths(source)
        
        if distances.get(target, float('inf')) == float('inf'):
            return None  # No path found
        
        # Reconstruct path
        path = []
        current = target
        while current != source:
            path.append(current)
            # Find predecessor
            for neighbor in self.nodes[current]:
                if distances[neighbor] == distances[current] - 1:
                    current = neighbor
                    break
            else:
                return None  # Path broken
        path.append(source)
        return list(reversed(path))
    
    def greedy_modularity_communities(self):
        """Simple community detection using greedy modularity"""
        if not self.nodes:
            return []
        
        # Convert to undirected for community detection
        undirected = self.to_undirected()
        
        # Start with each node in its own community
        communities = []
        for node_id in undirected.nodes:
            communities.append([node_id])
        
        best_communities = communities[:]
        best_modularity = self._calculate_modularity(best_communities, undirected)
        
        # Try merging communities
        improved = True
        while improved:
            improved = False
            for i in range(len(communities)):
                for j in range(i + 1, len(communities)):
                    merged = communities[i] + communities[j]
                    current_communities = communities[:]
                    current_communities[i] = merged
                    current_communities.pop(j)
                    
                    modularity = self._calculate_modularity(current_communities, undirected)
                    
                    if modularity > best_modularity:
                        best_communities = current_communities[:]
                        best_modularity = modularity
                        improved = True
        
        return best_communities
    
    def _calculate_modularity(self, communities, graph):
        """Calculate modularity score for communities"""
        if not communities:
            return 0.0
        
        total_edges = len(graph.edges)
        if total_edges == 0:
            return 0.0
        
        modularity = 0.0
        for community in communities:
            community_nodes = set(community)
            edges_in_community = 0
            edges_total = 0
            
            for node_id in community_nodes:
                neighbors = graph.neighbors(node_id)
                edges_total += len(neighbors)
                edges_in_community += len(community_nodes & neighbors)
            
            if edges_total > 0:
                modularity += edges_in_community / edges_total
        
        return modularity / len(communities) if communities else 0.0
import re
import math
from collections import defaultdict, Counter
from collections import deque

logger = logging.getLogger(__name__)

@dataclass
class KnowledgeNode:
    """Represents a node in the knowledge graph"""
    node_id: str
    node_type: str  # 'pattern', 'capability', 'technology', 'repository', 'concept'
    label: str
    properties: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=asyncio.get_event_loop().time)
    updated_at: float = field(default_factory=asyncio.get_event_loop().time)
    confidence_score: float = 0.0
    usage_count: int = 0

@dataclass
class KnowledgeEdge:
    """Represents an edge in the knowledge graph"""
    edge_id: str
    from_node: str
    to_node: str
    relationship_type: str  # 'implements', 'uses', 'depends_on', 'related_to', 'similar_to'
    weight: float = 1.0
    properties: Dict[str, Any] = field(default_factory=dict)
    confidence_score: float = 0.0
    created_at: float = field(default_factory=asyncio.get_event_loop().time)

@dataclass
class KnowledgeCluster:
    """Represents a cluster of related knowledge nodes"""
    cluster_id: str
    cluster_type: str  # 'pattern_cluster', 'technology_stack', 'domain_knowledge'
    nodes: List[str]
    center_node: Optional[str] = None
    cohesion_score: float = 0.0
    properties: Dict[str, Any] = field(default_factory=dict)

class AdvancedKnowledgeGraph:
    """Advanced knowledge graph with reasoning and learning capabilities"""
    
    def __init__(self, config_path: str = None):
        # Core graph structures
        self.nodes: Dict[str, KnowledgeNode] = {}
        self.edges: Dict[str, KnowledgeEdge] = {}
        self.clusters: Dict[str, KnowledgeCluster] = {}
        
        # Simple graph for advanced analysis (replacing networkx)
        self.nx_graph = SimpleGraph()
        
        # Simple text analysis (replacing TfidfVectorizer)
        self.word_frequency = defaultdict(int)
        self.stop_words = {
            'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
            'is', 'are', 'was', 'were', 'been', 'be', 'have', 'has', 'had', 'do', 'does', 'did',
            'this', 'that', 'these', 'those', 'a', 'an', 'as', 'if', 'then', 'else', 'when',
            'where', 'why', 'how', 'what', 'which', 'who', 'whom', 'whose', 'can', 'could',
            'should', 'would', 'will', 'shall', 'may', 'might', 'must', 'not', 'no', 'yes'
        }
        self.node_vectors = {}
        self.concept_embeddings = {}
        
        # Analytics and insights
        self.graph_analytics = {
            "node_count": 0,
            "edge_count": 0,
            "cluster_count": 0,
            "avg_clustering_coefficient": 0.0,
            "graph_density": 0.0,
            "centrality_scores": {},
            "community_detection": {}
        }
        
        # Learning and reasoning
        self.reasoning_rules = {}
        self.inference_cache = {}
        self.similarity_threshold = 0.7
        
        # Configuration
        self.config = self._load_config(config_path)
        
        # Performance tracking
        self.operation_stats = {
            "nodes_added": 0,
            "edges_added": 0,
            "clusters_formed": 0,
            "inferences_made": 0,
            "similarity_queries": 0
        }
    
    # Text Analysis Methods (replacing TfidfVectorizer)
    def _simple_text_similarity(self, text1: str, text2: str) -> float:
        """Calculate simple word overlap similarity"""
        words1 = set(text1.lower().split()) - self.stop_words
        words2 = set(text2.lower().split()) - self.stop_words
        if not words1 or not words2:
            return 0.0
        intersection = len(words1 & words2)
        union = len(words1 | words2)
        return intersection / union if union > 0 else 0.0
    
    def _get_text_vector(self, text: str) -> Dict[str, int]:
        """Convert text to simple word frequency vector"""
        words = text.lower().split()
        word_freq = {}
        total_words = len(words)
        
        for word in words:
            if word in self.stop_words:
                continue
            word_freq[word] = word_freq.get(word, 0) + 1
        
        # Normalize by total words
        for word in word_freq:
            word_freq[word] = word_freq[word] / total_words
        
        return word_freq
    
    def _cosine_similarity_simple(self, vector1: Dict[str, int], vector2: Dict[str, int]) -> float:
        """Calculate cosine similarity between two simple vectors"""
        if not vector1 or not vector2:
            return 0.0
        
        # Find common words
        common_words = set(vector1.keys()) & set(vector2.keys())
        if not common_words:
            return 0.0
        
        # Calculate dot product
        dot_product = sum(vector1[word] * vector2[word] for word in common_words)
        
        # Calculate magnitudes
        magnitude1 = math.sqrt(sum(v**2 for v in vector1.values()))
        magnitude2 = math.sqrt(sum(v**2 for v in vector2.values()))
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration for knowledge graph"""
        default_config = {
            "graph": {
                "max_nodes": 10000,
                "max_edges": 50000,
                "similarity_threshold": 0.7,
                "clustering_threshold": 0.6
            },
            "reasoning": {
                "enable_inference": True,
                "max_inference_depth": 3,
                "confidence_threshold": 0.5
            },
            "analytics": {
                "update_analytics_interval": 100,  # Update every 100 operations
                "track_centrality": True,
                "detect_communities": True
            },
            "storage": {
                "enable_persistence": True,
                "auto_save_interval": 1000,  # Save every 1000 operations
                "backup_count": 3
            }
        }
        
        if config_path and Path(config_path).exists():
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                default_config.update(user_config)
            except Exception as e:
                logger.warning(f"Could not load config from {config_path}: {e}")
        
        return default_config
    
    async def add_knowledge_node(self, 
                                node_type: str,
                                label: str,
                                properties: Dict[str, Any] = None,
                                metadata: Dict[str, Any] = None) -> str:
        """Add a knowledge node to the graph"""
        try:
            # Generate unique node ID
            node_id = self._generate_node_id(node_type, label, properties)
            
            # Create node
            node = KnowledgeNode(
                node_id=node_id,
                node_type=node_type,
                label=label,
                properties=properties or {},
                metadata=metadata or {},
                confidence_score=properties.get('confidence_score', 0.0) if properties else 0.0
            )
            
            # Add to storage
            self.nodes[node_id] = node
            self.nx_graph.add_node(node_id, **node.properties)
            
            # Update analytics
            await self._update_node_analytics(node_id)
            
            # Check for similar nodes
            similar_nodes = await self._find_similar_nodes(node_id)
            if similar_nodes:
                await self._create_similarity_edges(node_id, similar_nodes)
            
            # Update operation stats
            self.operation_stats["nodes_added"] += 1
            
            # Auto-save if enabled
            if self.config['storage']['enable_persistence']:
                await self._auto_save()
            
            logger.info(f"Added knowledge node: {node_id}")
            return node_id
            
        except Exception as e:
            logger.error(f"Failed to add knowledge node: {e}")
            raise
    
    async def add_knowledge_edge(self,
                                from_node_id: str,
                                to_node_id: str,
                                relationship_type: str,
                                weight: float = 1.0,
                                properties: Dict[str, Any] = None) -> str:
        """Add a knowledge edge to the graph"""
        try:
            # Validate nodes exist
            if from_node_id not in self.nodes or to_node_id not in self.nodes:
                raise ValueError("One or both nodes do not exist")
            
            # Generate edge ID
            edge_id = self._generate_edge_id(from_node_id, to_node_id, relationship_type)
            
            # Check if edge already exists
            if edge_id in self.edges:
                logger.info(f"Edge already exists: {edge_id}")
                return edge_id
            
            # Create edge
            edge = KnowledgeEdge(
                edge_id=edge_id,
                from_node=from_node_id,
                to_node=to_node_id,
                relationship_type=relationship_type,
                weight=weight,
                properties=properties or {},
                confidence_score=properties.get('confidence_score', weight) if properties else weight
            )
            
            # Add to storage
            self.edges[edge_id] = edge
            self.nx_graph.add_edge(from_node_id, to_node_id, **edge.properties)
            
            # Update analytics
            await self._update_edge_analytics(edge_id)
            
            # Check for cluster formation
            await self._check_cluster_formation(from_node_id, to_node_id)
            
            # Trigger reasoning if enabled
            if self.config['reasoning']['enable_inference']:
                await self._trigger_reasoning(from_node_id, to_node_id, relationship_type)
            
            # Update operation stats
            self.operation_stats["edges_added"] += 1
            
            # Auto-save if enabled
            if self.config['storage']['enable_persistence']:
                await self._auto_save()
            
            logger.info(f"Added knowledge edge: {edge_id}")
            return edge_id
            
        except Exception as e:
            logger.error(f"Failed to add knowledge edge: {e}")
            raise
    
    def _generate_node_id(self, node_type: str, label: str, properties: Dict[str, Any]) -> str:
        """Generate unique node ID"""
        # Create hash from type, label, and properties
        content = f"{node_type}_{label}_{json.dumps(properties, sort_keys=True) if properties else ''}"
        hash_suffix = hashlib.md5(content.encode()).hexdigest()[:8]
        return f"{node_type}_{hash_suffix}"
    
    def _generate_edge_id(self, from_node: str, to_node: str, relationship_type: str) -> str:
        """Generate unique edge ID"""
        content = f"{from_node}_{relationship_type}_{to_node}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    async def _find_similar_nodes(self, node_id: str, threshold: float = None) -> List[Tuple[str, float]]:
        """Find nodes similar to the given node"""
        try:
            if threshold is None:
                threshold = self.similarity_threshold
            
            target_node = self.nodes[node_id]
            similar_nodes = []
            
            # Get or create node vector
            target_vector = await self._get_node_vector(node_id)
            
            for other_id, other_node in self.nodes.items():
                if other_id == node_id:
                    continue
                
                # Get or create other node vector
                other_vector = await self._get_node_vector(other_id)
                
                if target_vector is not None and other_vector is not None:
                    similarity = cosine_similarity([target_vector], [other_vector])[0][0]
                    if similarity >= threshold:
                        similar_nodes.append((other_id, similarity))
            
            # Sort by similarity
            similar_nodes.sort(key=lambda x: x[1], reverse=True)
            return similar_nodes[:10]  # Return top 10 similar nodes
            
        except Exception as e:
            logger.warning(f"Similar node search failed: {e}")
            return []
    
    async def _get_node_vector(self, node_id: str) -> Optional[List[float]]:
        """Get or create vector representation of a node"""
        try:
            if node_id in self.node_vectors:
                return self.node_vectors[node_id]
            
            node = self.nodes[node_id]
            
            # Create text representation
            text_parts = [
                node.label,
                node.node_type,
                " ".join(node.properties.get('description', '').split()) if node.properties.get('description') else ''
            ]
            
            # Add property values
            for key, value in node.properties.items():
                if isinstance(value, (str, int, float)):
                    text_parts.append(str(value))
            
            text_representation = " ".join(text_parts)
            
            # Vectorize if we have enough text
            if len(text_representation.strip()) > 0:
                vector = self.vectorizer.fit_transform([text_representation]).toarray()[0]
                self.node_vectors[node_id] = vector
                return vector
            
            return None
            
        except Exception as e:
            logger.warning(f"Node vector creation failed: {e}")
            return None
    
    async def _create_similarity_edges(self, node_id: str, similar_nodes: List[Tuple[str, float]]):
        """Create similarity edges between nodes"""
        try:
            for similar_id, similarity_score in similar_nodes:
                # Create similarity edge if it doesn't exist
                if not await self._edge_exists(node_id, similar_id, "similar_to"):
                    await self.add_knowledge_edge(
                        from_node_id=node_id,
                        to_node_id=similar_id,
                        relationship_type="similar_to",
                        weight=similarity_score,
                        properties={"confidence_score": similarity_score}
                    )
        except Exception as e:
            logger.warning(f"Similarity edge creation failed: {e}")
    
    async def _edge_exists(self, from_node: str, to_node: str, relationship_type: str) -> bool:
        """Check if an edge already exists"""
        return any(
            edge.from_node == from_node and 
            edge.to_node == to_node and 
            edge.relationship_type == relationship_type
            for edge in self.edges.values()
        )
    
    async def _update_node_analytics(self, node_id: str):
        """Update analytics when a node is added"""
        try:
            if len(self.nodes) % self.config['analytics']['update_analytics_interval'] == 0:
                await self._calculate_graph_analytics()
        except Exception as e:
            logger.warning(f"Node analytics update failed: {e}")
    
    async def _update_edge_analytics(self, edge_id: str):
        """Update analytics when an edge is added"""
        try:
            if len(self.edges) % self.config['analytics']['update_analytics_interval'] == 0:
                await self._calculate_graph_analytics()
        except Exception as e:
            logger.warning(f"Edge analytics update failed: {e}")
    
    async def _calculate_graph_analytics(self):
        """Calculate comprehensive graph analytics"""
        try:
            if not self.nx_graph.nodes():
                return
            
            # Basic metrics
            self.graph_analytics["node_count"] = len(self.nodes)
            self.graph_analytics["edge_count"] = len(self.edges)
            
            # Graph density
            if len(self.nodes) > 1:
                density = self.nx_graph.density()
                self.graph_analytics["graph_density"] = density
            
            # Clustering coefficient
            if len(self.nodes) > 2:
                clustering = self.nx_graph.average_clustering()
                self.graph_analytics["avg_clustering_coefficient"] = clustering
            
            # Centrality measures
            if self.config['analytics']['track_centrality'] and len(self.nodes) > 3:
                centrality_scores = self.nx_graph.degree_centrality()
                self.graph_analytics["centrality_scores"] = centrality_scores
            
            # Community detection
            if self.config['analytics']['detect_communities'] and len(self.nodes) > 10:
                communities = self.nx_graph.greedy_modularity_communities()
                self.graph_analytics["community_detection"] = {
                    f"community_{i}": list(community) 
                    for i, community in enumerate(communities)
                }
            
            logger.info("Graph analytics updated")
            
        except Exception as e:
            logger.warning(f"Graph analytics calculation failed: {e}")
    
    async def _check_cluster_formation(self, from_node: str, to_node: str):
        """Check if adding this edge creates a new cluster"""
        try:
            # Simple cluster detection based on node types and relationships
            from_node_obj = self.nodes[from_node]
            to_node_obj = self.nodes[to_node]
            
            # Create clusters for related technologies
            if (from_node_obj.node_type == "technology" and to_node_obj.node_type == "technology" and
                await self._are_technologies_related(from_node, to_node)):
                
                cluster_id = self._generate_cluster_id("technology_stack", [from_node, to_node])
                
                if cluster_id not in self.clusters:
                    await self._create_technology_cluster(cluster_id, [from_node, to_node])
            
            # Create clusters for pattern families
            if (from_node_obj.node_type == "pattern" and to_node_obj.node_type == "pattern" and
                await self._are_patterns_related(from_node, to_node)):
                
                cluster_id = self._generate_cluster_id("pattern_cluster", [from_node, to_node])
                
                if cluster_id not in self.clusters:
                    await self._create_pattern_cluster(cluster_id, [from_node, to_node])
                    
        except Exception as e:
            logger.warning(f"Cluster formation check failed: {e}")
    
    async def _are_technologies_related(self, tech1_id: str, tech2_id: str) -> bool:
        """Check if two technologies are related"""
        try:
            tech1 = self.nodes[tech1_id]
            tech2 = self.nodes[tech2_id]
            
            # Check for direct relationship
            if await self._edge_exists(tech1_id, tech2_id, "compatible_with"):
                return True
            
            # Check for common usage patterns
            tech1_props = tech1.properties
            tech2_props = tech2.properties
            
            # Common category
            if (tech1_props.get('category') == tech2_props.get('category') and 
                tech1_props.get('category') is not None):
                return True
            
            # High similarity in properties
            if self._calculate_node_similarity(tech1_props, tech2_props) > 0.8:
                return True
            
            return False
            
        except Exception as e:
            logger.warning(f"Technology relationship check failed: {e}")
            return False
    
    async def _are_patterns_related(self, pattern1_id: str, pattern2_id: str) -> bool:
        """Check if two patterns are related"""
        try:
            pattern1 = self.nodes[pattern1_id]
            pattern2 = self.nodes[pattern2_id]
            
            # Same pattern type
            if pattern1.properties.get('pattern_type') == pattern2.properties.get('pattern_type'):
                return True
            
            # Similar complexity scores
            complexity1 = pattern1.properties.get('complexity_score', 0)
            complexity2 = pattern2.properties.get('complexity_score', 0)
            
            if abs(complexity1 - complexity2) < 1.0:  # Similar complexity
                return True
            
            # High semantic similarity
            if await self._get_similarity_score(pattern1_id, pattern2_id) > 0.7:
                return True
            
            return False
            
        except Exception as e:
            logger.warning(f"Pattern relationship check failed: {e}")
            return False
    
    def _calculate_node_similarity(self, props1: Dict[str, Any], props2: Dict[str, Any]) -> float:
        """Calculate similarity between node properties"""
        try:
            common_keys = set(props1.keys()) & set(props2.keys())
            if not common_keys:
                return 0.0
            
            similarity_scores = []
            for key in common_keys:
                val1, val2 = props1[key], props2[key]
                
                if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                    # Numerical similarity
                    max_val = max(abs(val1), abs(val2))
                    if max_val > 0:
                        similarity = 1.0 - abs(val1 - val2) / max_val
                        similarity_scores.append(similarity)
                
                elif isinstance(val1, str) and isinstance(val2, str):
                    # String similarity (simple)
                    if val1.lower() == val2.lower():
                        similarity_scores.append(1.0)
                    elif val1.lower() in val2.lower() or val2.lower() in val1.lower():
                        similarity_scores.append(0.7)
                    else:
                        similarity_scores.append(0.0)
            
            return sum(similarity_scores) / len(similarity_scores) if similarity_scores else 0.0
            
        except Exception as e:
            logger.warning(f"Node similarity calculation failed: {e}")
            return 0.0
    
    async def _get_similarity_score(self, node1_id: str, node2_id: str) -> float:
        """Get similarity score between two nodes"""
        try:
            node1_vector = await self._get_node_vector(node1_id)
            node2_vector = await self._get_node_vector(node2_id)
            
            if node1_vector is not None and node2_vector is not None:
                return cosine_similarity([node1_vector], [node2_vector])[0][0]
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"Similarity score calculation failed: {e}")
            return 0.0
    
    def _generate_cluster_id(self, cluster_type: str, node_ids: List[str]) -> str:
        """Generate unique cluster ID"""
        content = f"{cluster_type}_{'_'.join(sorted(node_ids))}"
        return f"cluster_{hashlib.md5(content.encode()).hexdigest()[:8]}"
    
    async def _create_technology_cluster(self, cluster_id: str, node_ids: List[str]):
        """Create a technology stack cluster"""
        try:
            # Calculate cluster cohesion
            cohesion_score = await self._calculate_cluster_cohesion(node_ids)
            
            cluster = KnowledgeCluster(
                cluster_id=cluster_id,
                cluster_type="technology_stack",
                nodes=node_ids,
                cohesion_score=cohesion_score,
                properties={"description": "Technologies that work well together"}
            )
            
            self.clusters[cluster_id] = cluster
            self.operation_stats["clusters_formed"] += 1
            
            logger.info(f"Created technology cluster: {cluster_id}")
            
        except Exception as e:
            logger.warning(f"Technology cluster creation failed: {e}")
    
    async def _create_pattern_cluster(self, cluster_id: str, node_ids: List[str]):
        """Create a pattern family cluster"""
        try:
            # Calculate cluster cohesion
            cohesion_score = await self._calculate_cluster_cohesion(node_ids)
            
            cluster = KnowledgeCluster(
                cluster_id=cluster_id,
                cluster_type="pattern_cluster",
                nodes=node_ids,
                cohesion_score=cohesion_score,
                properties={"description": "Related code patterns"}
            )
            
            self.clusters[cluster_id] = cluster
            self.operation_stats["clusters_formed"] += 1
            
            logger.info(f"Created pattern cluster: {cluster_id}")
            
        except Exception as e:
            logger.warning(f"Pattern cluster creation failed: {e}")
    
    async def _calculate_cluster_cohesion(self, node_ids: List[str]) -> float:
        """Calculate cohesion score for a cluster"""
        try:
            if len(node_ids) < 2:
                return 1.0
            
            total_similarity = 0.0
            pair_count = 0
            
            for i in range(len(node_ids)):
                for j in range(i + 1, len(node_ids)):
                    similarity = await self._get_similarity_score(node_ids[i], node_ids[j])
                    total_similarity += similarity
                    pair_count += 1
            
            return total_similarity / pair_count if pair_count > 0 else 0.0
            
        except Exception as e:
            logger.warning(f"Cluster cohesion calculation failed: {e}")
            return 0.0
    
    async def _trigger_reasoning(self, from_node: str, to_node: str, relationship_type: str):
        """Trigger reasoning when a new edge is added"""
        try:
            if not self.config['reasoning']['enable_inference']:
                return
            
            # Simple reasoning rules
            await self._apply_transitivity_rule(from_node, to_node, relationship_type)
            await self._apply_composition_rule(from_node, to_node, relationship_type)
            await self._apply_inference_rules(from_node, to_node, relationship_type)
            
            self.operation_stats["inferences_made"] += 1
            
        except Exception as e:
            logger.warning(f"Reasoning trigger failed: {e}")
    
    async def _apply_transitivity_rule(self, from_node: str, to_node: str, relationship_type: str):
        """Apply transitivity reasoning rule"""
        try:
            # If A implements B and B implements C, then A might implement C
            if relationship_type == "implements":
                # Find other implementations of 'to_node'
                for edge in self.edges.values():
                    if (edge.to_node == to_node and 
                        edge.relationship_type == "implements" and 
                        edge.from_node != from_node):
                        
                        # Create inferred relationship
                        inferred_relationship = "might_implement"
                        if not await self._edge_exists(from_node, edge.from_node, inferred_relationship):
                            await self.add_knowledge_edge(
                                from_node_id=from_node,
                                to_node_id=edge.from_node,
                                relationship_type=inferred_relationship,
                                weight=0.5,  # Lower confidence for inferred relationship
                                properties={"inferred": True, "confidence_score": 0.5}
                            )
        except Exception as e:
            logger.warning(f"Transitivity rule application failed: {e}")
    
    async def _apply_composition_rule(self, from_node: str, to_node: str, relationship_type: str):
        """Apply composition reasoning rule"""
        try:
            # If a pattern uses a technology, and technology has certain properties,
            # the pattern might inherit those properties
            if relationship_type == "uses":
                from_node_obj = self.nodes[from_node]
                to_node_obj = self.nodes[to_node]
                
                if (from_node_obj.node_type == "pattern" and 
                    to_node_obj.node_type == "technology"):
                    
                    # Create property inheritance edge
                    if not await self._edge_exists(from_node, to_node, "inherits_properties"):
                        await self.add_knowledge_edge(
                            from_node_id=from_node,
                            to_node_id=to_node,
                            relationship_type="inherits_properties",
                            weight=0.7,
                            properties={"inferred": True, "confidence_score": 0.7}
                        )
        except Exception as e:
            logger.warning(f"Composition rule application failed: {e}")
    
    async def _apply_inference_rules(self, from_node: str, to_node: str, relationship_type: str):
        """Apply general inference rules"""
        try:
            from_node_obj = self.nodes[from_node]
            to_node_obj = self.nodes[to_node]
            
            # If pattern similar to another pattern, and that pattern has capabilities,
            # the current pattern might have similar capabilities
            if (from_node_obj.node_type == "pattern" and 
                to_node_obj.node_type == "pattern" and
                relationship_type == "similar_to"):
                
                # Find capabilities of similar patterns
                similar_capabilities = await self._find_similar_capabilities(to_node)
                for cap_id in similar_capabilities:
                    if not await self._edge_exists(from_node, cap_id, "might_have_capability"):
                        await self.add_knowledge_edge(
                            from_node_id=from_node,
                            to_node_id=cap_id,
                            relationship_type="might_have_capability",
                            weight=0.6,
                            properties={"inferred": True, "confidence_score": 0.6}
                        )
        except Exception as e:
            logger.warning(f"Inference rule application failed: {e}")
    
    async def _find_similar_capabilities(self, pattern_id: str) -> List[str]:
        """Find capabilities associated with similar patterns"""
        try:
            # Get capabilities directly associated with the pattern
            direct_capabilities = []
            for edge in self.edges.values():
                if edge.from_node == pattern_id and edge.relationship_type == "enables":
                    direct_capabilities.append(edge.to_node)
            
            return direct_capabilities
            
        except Exception as e:
            logger.warning(f"Similar capability search failed: {e}")
            return []
    
    async def _auto_save(self):
        """Auto-save graph if threshold is reached"""
        try:
            total_operations = (self.operation_stats["nodes_added"] + 
                              self.operation_stats["edges_added"])
            
            if total_operations % self.config['storage']['auto_save_interval'] == 0:
                await self.save_knowledge_graph(f"auto_save_{total_operations}.json")
                
        except Exception as e:
            logger.warning(f"Auto-save failed: {e}")
    
    async def query_knowledge(self, 
                            query_type: str, 
                            parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query the knowledge graph"""
        try:
            if query_type == "find_similar_nodes":
                return await self._query_similar_nodes(parameters)
            elif query_type == "find_paths":
                return await self._query_paths(parameters)
            elif query_type == "find_clusters":
                return await self._query_clusters(parameters)
            elif query_type == "central_nodes":
                return await self._query_central_nodes(parameters)
            elif query_type == "recommend_integration":
                return await self._query_integration_recommendations(parameters)
            else:
                return await self._query_general(parameters)
                
        except Exception as e:
            logger.error(f"Knowledge query failed: {e}")
            return []
    
    async def _query_similar_nodes(self, parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query for similar nodes"""
        try:
            node_id = parameters.get("node_id")
            threshold = parameters.get("threshold", self.similarity_threshold)
            limit = parameters.get("limit", 10)
            
            if node_id not in self.nodes:
                return []
            
            similar_nodes = await self._find_similar_nodes(node_id, threshold)
            
            results = []
            for similar_id, similarity_score in similar_nodes[:limit]:
                similar_node = self.nodes[similar_id]
                results.append({
                    "node_id": similar_id,
                    "label": similar_node.label,
                    "node_type": similar_node.node_type,
                    "similarity_score": similarity_score,
                    "properties": similar_node.properties
                })
            
            return results
            
        except Exception as e:
            logger.warning(f"Similar nodes query failed: {e}")
            return []
    
    async def _query_paths(self, parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query for paths between nodes"""
        try:
            start_node = parameters.get("start_node")
            end_node = parameters.get("end_node")
            max_depth = parameters.get("max_depth", 5)
            
            if start_node not in self.nodes or end_node not in self.nodes:
                return []
            
            try:
                # Find shortest path
                path = self.nx_graph.shortest_path(start_node, end_node)
                
                if path:
                    path_info = []
                    for i, node_id in enumerate(path):
                        node = self.nodes[node_id]
                        path_info.append({
                            "node_id": node_id,
                            "label": node.label,
                            "node_type": node.node_type,
                            "position": i
                        })
                    
                    return [{"path": path_info, "length": len(path) - 1}]
                
            except Exception:
                # No direct path found
                return []
            
            return []
            
        except Exception as e:
            logger.warning(f"Path query failed: {e}")
            return []
    
    async def _query_clusters(self, parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query for knowledge clusters"""
        try:
            cluster_type = parameters.get("cluster_type")
            min_cohesion = parameters.get("min_cohesion", 0.5)
            
            results = []
            for cluster_id, cluster in self.clusters.items():
                if cluster_type and cluster.cluster_type != cluster_type:
                    continue
                
                if cluster.cohesion_score >= min_cohesion:
                    cluster_nodes = []
                    for node_id in cluster.nodes:
                        if node_id in self.nodes:
                            node = self.nodes[node_id]
                            cluster_nodes.append({
                                "node_id": node_id,
                                "label": node.label,
                                "node_type": node.node_type
                            })
                    
                    results.append({
                        "cluster_id": cluster_id,
                        "cluster_type": cluster.cluster_type,
                        "cohesion_score": cluster.cohesion_score,
                        "node_count": len(cluster_nodes),
                        "nodes": cluster_nodes,
                        "properties": cluster.properties
                    })
            
            return results
            
        except Exception as e:
            logger.warning(f"Cluster query failed: {e}")
            return []
    
    async def _query_central_nodes(self, parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query for central/important nodes"""
        try:
            centrality_type = parameters.get("centrality_type", "degree")
            limit = parameters.get("limit", 10)
            
            if not self.nx_graph.nodes():
                return []
            
            if centrality_type == "degree":
                centrality_scores = self.nx_graph.degree_centrality()
            elif centrality_type == "betweenness":
                centrality_scores = self.nx_graph.betweenness_centrality()
            elif centrality_type == "closeness":
                centrality_scores = self.nx_graph.closeness_centrality()
            else:
                centrality_scores = self.nx_graph.degree_centrality()
            
            # Sort by centrality score
            sorted_nodes = sorted(centrality_scores.items(), key=lambda x: x[1], reverse=True)
            
            results = []
            for node_id, score in sorted_nodes[:limit]:
                if node_id in self.nodes:
                    node = self.nodes[node_id]
                    results.append({
                        "node_id": node_id,
                        "label": node.label,
                        "node_type": node.node_type,
                        "centrality_score": score,
                        "properties": node.properties
                    })
            
            return results
            
        except Exception as e:
            logger.warning(f"Central nodes query failed: {e}")
            return []
    
    async def _query_integration_recommendations(self, parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query for integration recommendations"""
        try:
            node_id = parameters.get("node_id")
            recommendation_type = parameters.get("type", "compatible_technologies")
            
            if node_id not in self.nodes:
                return []
            
            node = self.nodes[node_id]
            recommendations = []
            
            if recommendation_type == "compatible_technologies" and node.node_type == "pattern":
                # Find compatible technologies
                for edge in self.edges.values():
                    if (edge.from_node == node_id and 
                        edge.relationship_type == "uses" and
                        edge.to_node in self.nodes):
                        
                        tech_node = self.nodes[edge.to_node]
                        if tech_node.node_type == "technology":
                            recommendations.append({
                                "recommendation_type": "compatible_technology",
                                "technology": {
                                    "node_id": edge.to_node,
                                    "label": tech_node.label,
                                    "category": tech_node.properties.get("category"),
                                    "confidence": edge.confidence_score
                                },
                                "reason": "Used in similar patterns"
                            })
            
            elif recommendation_type == "similar_patterns" and node.node_type == "technology":
                # Find similar patterns
                for edge in self.edges.values():
                    if (edge.to_node == node_id and 
                        edge.relationship_type == "uses" and
                        edge.from_node in self.nodes):
                        
                        pattern_node = self.nodes[edge.from_node]
                        if pattern_node.node_type == "pattern":
                            recommendations.append({
                                "recommendation_type": "similar_pattern",
                                "pattern": {
                                    "node_id": edge.from_node,
                                    "label": pattern_node.label,
                                    "pattern_type": pattern_node.properties.get("pattern_type"),
                                    "confidence": edge.confidence_score
                                },
                                "reason": "Uses this technology"
                            })
            
            return recommendations
            
        except Exception as e:
            logger.warning(f"Integration recommendations query failed: {e}")
            return []
    
    async def _query_general(self, parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """General knowledge query"""
        try:
            node_type = parameters.get("node_type")
            label_filter = parameters.get("label_contains", "")
            limit = parameters.get("limit", 20)
            
            results = []
            for node_id, node in self.nodes.items():
                if node_type and node.node_type != node_type:
                    continue
                
                if label_filter and label_filter.lower() not in node.label.lower():
                    continue
                
                results.append({
                    "node_id": node_id,
                    "label": node.label,
                    "node_type": node.node_type,
                    "confidence_score": node.confidence_score,
                    "properties": node.properties,
                    "metadata": node.metadata
                })
                
                if len(results) >= limit:
                    break
            
            return results
            
        except Exception as e:
            logger.warning(f"General query failed: {e}")
            return []
    
    async def get_knowledge_insights(self) -> Dict[str, Any]:
        """Get comprehensive knowledge insights"""
        try:
            insights = {
                "graph_statistics": self.graph_analytics,
                "operation_statistics": self.operation_stats,
                "top_central_nodes": await self._get_top_central_nodes(5),
                "largest_clusters": await self._get_largest_clusters(5),
                "most_connected_relationships": await self._get_most_connected_relationships(),
                "knowledge_gaps": await self._identify_knowledge_gaps(),
                "recommendations": await self._generate_knowledge_recommendations()
            }
            
            return insights
            
        except Exception as e:
            logger.error(f"Knowledge insights generation failed: {e}")
            return {"error": str(e)}
    
    async def _get_top_central_nodes(self, limit: int) -> List[Dict[str, Any]]:
        """Get top central nodes by degree centrality"""
        try:
            if not self.nx_graph.nodes():
                return []
            
            centrality_scores = self.nx_graph.degree_centrality()
            sorted_nodes = sorted(centrality_scores.items(), key=lambda x: x[1], reverse=True)
            
            results = []
            for node_id, score in sorted_nodes[:limit]:
                if node_id in self.nodes:
                    node = self.nodes[node_id]
                    results.append({
                        "node_id": node_id,
                        "label": node.label,
                        "node_type": node.node_type,
                        "centrality_score": score
                    })
            
            return results
            
        except Exception as e:
            logger.warning(f"Top central nodes query failed: {e}")
            return []
    
    async def _get_largest_clusters(self, limit: int) -> List[Dict[str, Any]]:
        """Get largest knowledge clusters"""
        try:
            sorted_clusters = sorted(
                self.clusters.items(),
                key=lambda x: len(x[1].nodes),
                reverse=True
            )
            
            results = []
            for cluster_id, cluster in sorted_clusters[:limit]:
                results.append({
                    "cluster_id": cluster_id,
                    "cluster_type": cluster.cluster_type,
                    "node_count": len(cluster.nodes),
                    "cohesion_score": cluster.cohesion_score
                })
            
            return results
            
        except Exception as e:
            logger.warning(f"Largest clusters query failed: {e}")
            return []
    
    async def _get_most_connected_relationships(self) -> List[Dict[str, Any]]:
        """Get most frequently connected relationship types"""
        try:
            relationship_counts = defaultdict(int)
            for edge in self.edges.values():
                relationship_counts[edge.relationship_type] += 1
            
            sorted_relationships = sorted(
                relationship_counts.items(),
                key=lambda x: x[1],
                reverse=True
            )
            
            return [
                {"relationship_type": rel_type, "count": count}
                for rel_type, count in sorted_relationships[:10]
            ]
            
        except Exception as e:
            logger.warning(f"Most connected relationships query failed: {e}")
            return []
    
    async def _identify_knowledge_gaps(self) -> List[str]:
        """Identify potential knowledge gaps"""
        try:
            gaps = []
            
            # Check for isolated nodes
            isolated_nodes = [n for n, degree in self.nx_graph.degree_items() if degree == 0]
            if isolated_nodes:
                gaps.append(f"Isolated nodes detected: {len(isolated_nodes)}")
            
            # Check for nodes with low connectivity
            low_connectivity = [n for n, degree in self.nx_graph.degree_items() if degree < 2]
            if low_connectivity:
                gaps.append(f"Low connectivity nodes: {len(low_connectivity)}")
            
            # Check for missing technology relationships
            pattern_nodes = [n for n in self.nodes.values() if n.node_type == "pattern"]
            patterns_without_tech = []
            for pattern in pattern_nodes:
                has_tech_edge = any(
                    edge.from_node == pattern.node_id and 
                    self.nodes.get(edge.to_node, {}).node_type == "technology"
                    for edge in self.edges.values()
                )
                if not has_tech_edge:
                    patterns_without_tech.append(pattern.node_id)
            
            if patterns_without_tech:
                gaps.append(f"Patterns without technology associations: {len(patterns_without_tech)}")
            
            return gaps
            
        except Exception as e:
            logger.warning(f"Knowledge gap identification failed: {e}")
            return ["Knowledge gap analysis completed"]
    
    async def _generate_knowledge_recommendations(self) -> List[str]:
        """Generate recommendations for improving knowledge graph"""
        try:
            recommendations = []
            
            # Density recommendation
            if self.graph_analytics["graph_density"] < 0.1:
                recommendations.append("Consider adding more connections between nodes to improve graph density")
            
            # Clustering recommendation
            if len(self.clusters) < len(self.nodes) * 0.1:
                recommendations.append("More clusters could be formed to group related knowledge")
            
            # Centrality recommendation
            top_central = await self._get_top_central_nodes(1)
            if top_central and top_central[0]["centrality_score"] > 0.5:
                recommendations.append("Consider adding alternative paths to reduce dependency on highly central nodes")
            
            # Technology coverage recommendation
            tech_nodes = [n for n in self.nodes.values() if n.node_type == "technology"]
            if len(tech_nodes) < 5:
                recommendations.append("Add more technology nodes to improve technology coverage")
            
            return recommendations
            
        except Exception as e:
            logger.warning(f"Knowledge recommendations generation failed: {e}")
            return ["Knowledge recommendations analysis completed"]
    
    async def save_knowledge_graph(self, file_path: str) -> bool:
        """Save knowledge graph to file"""
        try:
            export_data = {
                "nodes": {
                    node_id: {
                        "node_id": node.node_id,
                        "node_type": node.node_type,
                        "label": node.label,
                        "properties": node.properties,
                        "metadata": node.metadata,
                        "confidence_score": node.confidence_score,
                        "usage_count": node.usage_count
                    }
                    for node_id, node in self.nodes.items()
                },
                "edges": {
                    edge_id: {
                        "edge_id": edge.edge_id,
                        "from_node": edge.from_node,
                        "to_node": edge.to_node,
                        "relationship_type": edge.relationship_type,
                        "weight": edge.weight,
                        "properties": edge.properties,
                        "confidence_score": edge.confidence_score
                    }
                    for edge_id, edge in self.edges.items()
                },
                "clusters": {
                    cluster_id: {
                        "cluster_id": cluster.cluster_id,
                        "cluster_type": cluster.cluster_type,
                        "nodes": cluster.nodes,
                        "center_node": cluster.center_node,
                        "cohesion_score": cluster.cohesion_score,
                        "properties": cluster.properties
                    }
                    for cluster_id, cluster in self.clusters.items()
                },
                "analytics": self.graph_analytics,
                "operation_stats": self.operation_stats,
                "config": self.config,
                "export_timestamp": asyncio.get_event_loop().time()
            }
            
            import aiofiles
            async with aiofiles.write(file_path, 'w') as f:
                await f.write(json.dumps(export_data, indent=2))
            
            logger.info(f"Knowledge graph saved to {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Knowledge graph save failed: {e}")
            return False
    
    async def load_knowledge_graph(self, file_path: str) -> bool:
        """Load knowledge graph from file"""
        try:
            import aiofiles
            async with aiofiles.read(file_path, 'r') as f:
                data = json.loads(await f.read())
            
            # Load nodes
            self.nodes.clear()
            for node_id, node_data in data.get("nodes", {}).items():
                node = KnowledgeNode(**node_data)
                self.nodes[node_id] = node
            
            # Load edges
            self.edges.clear()
            for edge_id, edge_data in data.get("edges", {}).items():
                edge = KnowledgeEdge(**edge_data)
                self.edges[edge_id] = edge
            
            # Load clusters
            self.clusters.clear()
            for cluster_id, cluster_data in data.get("clusters", {}).items():
                cluster = KnowledgeCluster(**cluster_data)
                self.clusters[cluster_id] = cluster
            
            # Load analytics and stats
            self.graph_analytics = data.get("analytics", {})
            self.operation_stats = data.get("operation_stats", {})
            
            # Rebuild NetworkX graph
            self.nx_graph.clear()
            self.nx_graph.add_nodes_from(self.nodes.keys())
            self.nx_graph.add_edges_from(
                (edge.from_node, edge.to_node, edge.properties)
                for edge in self.edges.values()
            )
            
            logger.info(f"Knowledge graph loaded from {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Knowledge graph load failed: {e}")
            return False
    
    def get_knowledge_summary(self) -> Dict[str, Any]:
        """Get summary of knowledge graph state"""
        try:
            return {
                "node_count": len(self.nodes),
                "edge_count": len(self.edges),
                "cluster_count": len(self.clusters),
                "node_types": Counter(node.node_type for node in self.nodes.values()),
                "relationship_types": Counter(edge.relationship_type for edge in self.edges.values()),
                "graph_density": self.graph_analytics.get("graph_density", 0.0),
                "operation_stats": self.operation_stats,
                "knowledge_quality_score": self._calculate_knowledge_quality_score()
            }
        except Exception as e:
            logger.warning(f"Knowledge summary generation failed: {e}")
            return {"error": str(e)}
    
    def _calculate_knowledge_quality_score(self) -> float:
        """Calculate overall knowledge quality score"""
        try:
            # Factors: connectivity, clustering, diversity, coverage
            scores = []
            
            # Connectivity score
            if self.graph_analytics.get("graph_density", 0) > 0:
                scores.append(min(self.graph_analytics["graph_density"] * 5, 1.0))
            
            # Clustering score
            if len(self.clusters) > 0:
                avg_cohesion = sum(c.cohesion_score for c in self.clusters.values()) / len(self.clusters)
                scores.append(avg_cohesion)
            
            # Node type diversity
            unique_types = len(set(node.node_type for node in self.nodes.values()))
            if len(self.nodes) > 0:
                diversity_score = min(unique_types / 5.0, 1.0)  # Assume 5 types is good diversity
                scores.append(diversity_score)
            
            # Node coverage
            avg_usage = sum(node.usage_count for node in self.nodes.values()) / len(self.nodes) if self.nodes else 0
            coverage_score = min(avg_usage / 10.0, 1.0)  # Assume 10 usages is good coverage
            scores.append(coverage_score)
            
            return sum(scores) / len(scores) if scores else 0.0
            
        except Exception as e:
            logger.warning(f"Knowledge quality score calculation failed: {e}")
            return 0.0

# Global instance
knowledge_graph = AdvancedKnowledgeGraph()

# Convenience functions
async def add_knowledge_node(node_type: str, label: str, properties: Dict[str, Any] = None):
    """Add a knowledge node"""
    return await knowledge_graph.add_knowledge_node(node_type, label, properties)

async def add_knowledge_edge(from_node: str, to_node: str, relationship_type: str, weight: float = 1.0):
    """Add a knowledge edge"""
    return await knowledge_graph.add_knowledge_edge(from_node, to_node, relationship_type, weight)

async def query_knowledge(query_type: str, parameters: Dict[str, Any]):
    """Query the knowledge graph"""
    return await knowledge_graph.query_knowledge(query_type, parameters)

async def get_knowledge_insights():
    """Get knowledge insights"""
    return await knowledge_graph.get_knowledge_insights()