#!/usr/bin/env python3
"""
JARVIS v11 Enhanced - Service Health Monitor
===========================================

Monitors JARVIS daemon health and provides auto-restart capabilities.
Designed to work alongside the background daemon system.
"""

import asyncio
import json
import logging
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
import os
import signal

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'health_monitor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class HealthMonitor:
    """Monitor JARVIS daemon health and manage restarts"""
    
    def __init__(self):
        self.jarvis_home = Path("/data/data/com.termux/files/home/jarvis_v11")
        self.pid_file = self.jarvis_home / "daemon.pid"
        self.state_file = self.jarvis_home / "data" / "daemon_state.json"
        self.config_file = self.jarvis_home / "config" / "health_monitor.json"
        
        # Configuration
        self.config = self._load_config()
        
        # Health metrics
        self.health_history = []
        self.crash_count = 0
        self.last_restart = None
        self.monitoring = False
        
        # Thresholds
        self.crash_threshold = self.config.get('crash_threshold', 5)
        self.health_check_interval = self.config.get('health_check_interval', 60)
        self.restart_delay = self.config.get('restart_delay', 30)
        self.max_memory_usage = self.config.get('max_memory_usage', 80)  # MB
        
    def _load_config(self) -> Dict[str, Any]:
        """Load health monitor configuration"""
        default_config = {
            'crash_threshold': 5,
            'health_check_interval': 60,
            'restart_delay': 30,
            'max_memory_usage': 80,
            'enable_auto_restart': True,
            'enable_notifications': True,
            'enable_cleanup': True,
            'health_score_threshold': 70
        }
        
        try:
            if self.config_file.exists():
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    default_config.update(config)
            else:
                # Create default config file
                self.config_file.parent.mkdir(parents=True, exist_ok=True)
                with open(self.config_file, 'w') as f:
                    json.dump(default_config, f, indent=2)
                logger.info("Created default health monitor config")
                
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
        
        return default_config
    
    def _save_config(self):
        """Save health monitor configuration"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save config: {e}")
    
    def is_daemon_running(self) -> bool:
        """Check if JARVIS daemon is running"""
        try:
            if not self.pid_file.exists():
                return False
            
            with open(self.pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            # Check if process exists
            # Check if process exists using shell command
            try:
                result = subprocess.run(['ps', '-p', str(pid)], capture_output=True)
                process_exists = result.returncode == 0
            except:
                process_exists = False
            
            if process_exists:
                # Check if it's actually our daemon using ps command
                try:
                    result = subprocess.run(['ps', '-p', str(pid), '-o', 'command'], capture_output=True, text=True)
                    if result.returncode == 0:
                        cmdline = result.stdout.strip()
                        return 'background_daemon.py' in cmdline
                except:
                    pass
            
            return False
            
        except (FileNotFoundError, ValueError, subprocess.CalledProcessError):
            return False
    
    def get_daemon_status(self) -> Dict[str, Any]:
        """Get detailed daemon status"""
        status = {
            'running': False,
            'pid': None,
            'memory_usage': 0,
            'cpu_usage': 0,
            'uptime': 0,
            'health_score': 0,
            'last_error': None,
            'total_tasks_processed': 0,
            'active_services': []
        }
        
        try:
            if not self.is_daemon_running():
                return status
            
            with open(self.pid_file, 'r') as f:
                pid = int(f.read().strip())
            
            # Use shell command to get process info
            try:
                result = subprocess.run(['ps', '-p', str(pid), '-o', 'pid,ppid,pcpu,pmem,etime,command'], capture_output=True, text=True)
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')[1:]  # Skip header
                    if lines:
                        parts = lines[0].split()
                        # Return process info as dict-like object
                        return {
                            'pid': int(parts[0]) if parts[0].isdigit() else None,
                            'cpu_percent': float(parts[2]) if len(parts) > 2 and parts[2].replace('.', '').isdigit() else 0.0,
                            'memory_percent': float(parts[3]) if len(parts) > 3 and parts[3].replace('.', '').isdigit() else 0.0
                        }
            except:
                pass
            status['running'] = True
            status['pid'] = pid
            status['memory_usage'] = process.memory_info().rss / (1024 * 1024)  # MB
            status['cpu_usage'] = process.cpu_percent()
            status['uptime'] = time.time() - process.create_time()
            
            # Load daemon state if available
            if self.state_file.exists():
                with open(self.state_file, 'r') as f:
                    state = json.load(f)
                    status['health_score'] = state.get('health_score', 0)
                    status['total_tasks_processed'] = state.get('total_tasks_processed', 0)
                    status['last_error'] = state.get('last_error', None)
                    status['active_services'] = state.get('active_services', [])
            
            # Calculate health score
            status['health_score'] = self._calculate_health_score(status)
            
        except Exception as e:
            logger.error(f"Error getting daemon status: {e}")
            status['last_error'] = str(e)
        
        return status
    
    def _calculate_health_score(self, status: Dict[str, Any]) -> int:
        """Calculate daemon health score"""
        score = 100
        
        # Deduct for high resource usage
        if status['memory_usage'] > self.max_memory_usage:
            score -= 30
        elif status['memory_usage'] > self.max_memory_usage * 0.7:
            score -= 15
        
        if status['cpu_usage'] > 80:
            score -= 20
        elif status['cpu_usage'] > 50:
            score -= 10
        
        # Deduct for low uptime (potential crashes)
        if status['uptime'] < 300:  # Less than 5 minutes
            score -= 25
        
        # Add for good performance
        if status['cpu_usage'] < 10 and status['memory_usage'] < 50:
            score += 10
        
        return max(0, min(100, score))
    
    async def monitor_daemon(self):
        """Main monitoring loop"""
        logger.info("Starting health monitoring...")
        self.monitoring = True
        
        while self.monitoring:
            try:
                status = self.get_daemon_status()
                
                # Log current status
                logger.info(f"Daemon status: Running={status['running']}, "
                           f"Health={status['health_score']}%, "
                           f"Memory={status['memory_usage']:.1f}MB, "
                           f"CPU={status['cpu_usage']:.1f}%")
                
                # Check daemon health
                if not status['running']:
                    await self._handle_daemon_down()
                elif status['health_score'] < self.config['health_score_threshold']:
                    await self._handle_degraded_health(status)
                elif status['memory_usage'] > self.max_memory_usage:
                    await self._handle_high_memory_usage(status)
                
                # Record health history
                self.health_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'status': status
                })
                
                # Keep only recent history
                if len(self.health_history) > 100:
                    self.health_history = self.health_history[-100:]
                
                # Check for crash patterns
                await self._check_crash_pattern()
                
                await asyncio.sleep(self.health_check_interval)
                
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(30)  # Wait longer on error
    
    async def _handle_daemon_down(self):
        """Handle daemon not running"""
        self.crash_count += 1
        logger.warning(f"Daemon is down (crash count: {self.crash_count})")
        
        # Send notification
        if self.config['enable_notifications']:
            await self._send_notification(
                "JARVIS v11 Alert",
                f"Daemon is down. Crash count: {self.crash_count}",
                priority="high"
            )
        
        # Attempt restart if enabled and threshold not exceeded
        if (self.config['enable_auto_restart'] and 
            self.crash_count <= self.crash_threshold):
            
            logger.info(f"Attempting restart in {self.restart_delay} seconds...")
            await asyncio.sleep(self.restart_delay)
            
            success = await self._restart_daemon()
            if success:
                logger.info("Daemon restart successful")
                self.last_restart = datetime.now()
                self.crash_count = 0
                
                if self.config['enable_notifications']:
                    await self._send_notification(
                        "JARVIS v11",
                        "Daemon restarted successfully",
                        priority="normal"
                    )
            else:
                logger.error("Daemon restart failed")
                if self.config['enable_notifications']:
                    await self._send_notification(
                        "JARVIS v11 Error",
                        "Daemon restart failed",
                        priority="high"
                    )
        else:
            logger.error(f"Crash threshold exceeded ({self.crash_count}/{self.crash_threshold})")
            if self.config['enable_notifications']:
                await self._send_notification(
                    "JARVIS v11 Critical",
                    f"Daemon crash threshold exceeded ({self.crash_count}/{self.crash_threshold})",
                    priority="high"
                )
    
    async def _handle_degraded_health(self, status: Dict[str, Any]):
        """Handle degraded daemon health"""
        logger.warning(f"Daemon health degraded: {status['health_score']}%")
        
        if self.config['enable_notifications']:
            await self._send_notification(
                "JARVIS v11 Health Alert",
                f"Daemon health: {status['health_score']}% (memory: {status['memory_usage']:.1f}MB)",
                priority="normal"
            )
        
        # Consider restart if health is very poor
        if status['health_score'] < 40:
            logger.warning("Daemon health very poor, considering restart...")
            await asyncio.sleep(60)  # Wait a bit
            if not self.is_daemon_running():
                await self._restart_daemon()
    
    async def _handle_high_memory_usage(self, status: Dict[str, Any]):
        """Handle high memory usage"""
        logger.warning(f"High memory usage: {status['memory_usage']:.1f}MB")
        
        # Clear process cache if possible
        try:
            subprocess.run(['sync'], check=True)
            logger.info("System cache cleared")
        except:
            pass
        
        if self.config['enable_notifications']:
            await self._send_notification(
                "JARVIS v11 Memory Alert",
                f"High memory usage: {status['memory_usage']:.1f}MB",
                priority="normal"
            )
    
    async def _check_crash_pattern(self):
        """Check for crash patterns and take action"""
        if len(self.health_history) < 3:
            return
        
        # Check recent crashes
        recent_crashes = 0
        now = datetime.now()
        
        for entry in reversed(self.health_history[-10:]):
            entry_time = datetime.fromisoformat(entry['timestamp'])
            if now - entry_time < timedelta(minutes=10):
                if not entry['status']['running']:
                    recent_crashes += 1
        
        if recent_crashes >= 3:
            logger.error("Multiple crashes detected in short time period")
            if self.config['enable_notifications']:
                await self._send_notification(
                    "JARVIS v11 Critical",
                    f"Multiple crashes detected ({recent_crashes} in 10 minutes)",
                    priority="high"
                )
            
            # Consider extended cooldown
            logger.info("Entering extended cooldown period...")
            await asyncio.sleep(300)  # 5 minutes
    
    async def _restart_daemon(self) -> bool:
        """Restart the JARVIS daemon"""
        try:
            # Start daemon
            daemon_script = self.jarvis_home / "core" / "background_daemon.py"
            process = subprocess.Popen([
                sys.executable, str(daemon_script)
            ], cwd=str(self.jarvis_home))
            
            # Wait a moment and check if it started
            await asyncio.sleep(5)
            
            if process.poll() is None:  # Still running
                return True
            else:
                logger.error(f"Daemon restart failed with return code: {process.returncode}")
                return False
                
        except Exception as e:
            logger.error(f"Error restarting daemon: {e}")
            return False
    
    async def _send_notification(self, title: str, message: str, priority: str = "normal"):
        """Send notification"""
        try:
            if not self.config['enable_notifications']:
                return
            
            # Try termux-notification
            cmd = [
                'termux-notification',
                '--title', title,
                '--content', message,
                '--priority', priority
            ]
            
            subprocess.run(cmd, timeout=10, check=True)
            logger.info(f"Notification sent: {title}")
            
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            # Fallback to log
            logger.info(f"NOTIFICATION - {title}: {message}")
    
    def cleanup(self):
        """Cleanup resources"""
        self.monitoring = False
        logger.info("Health monitor stopped")
        
        # Save final state
        if self.config['enable_cleanup']:
            self._perform_cleanup()
    
    def _perform_cleanup(self):
        """Perform cleanup operations"""
        try:
            # Clean old log files
            log_dir = self.jarvis_home / "logs"
            if log_dir.exists():
                for log_file in log_dir.glob("*.log"):
                    if log_file.stat().st_mtime < time.time() - (7 * 24 * 3600):  # 7 days
                        log_file.unlink()
                        logger.info(f"Cleaned up old log: {log_file}")
            
            # Clean temporary files
            temp_dir = self.jarvis_home / "temp"
            if temp_dir.exists():
                for temp_file in temp_dir.glob("*"):
                    if temp_file.stat().st_mtime < time.time() - (24 * 3600):  # 1 day
                        temp_file.unlink()
                        logger.info(f"Cleaned up temp file: {temp_file}")
            
            logger.info("Cleanup completed")
            
        except Exception as e:
            logger.error(f"Cleanup error: {e}")


async def main():
    """Main entry point"""
    monitor = HealthMonitor()
    
    # Handle signals
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, stopping monitor...")
        monitor.cleanup()
        sys.exit(0)
    
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        await monitor.monitor_daemon()
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    except Exception as e:
        logger.error(f"Monitor error: {e}")
    finally:
        monitor.cleanup()


if __name__ == "__main__":
    # Handle command line arguments
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        monitor = HealthMonitor()
        
        if command == "status":
            status = monitor.get_daemon_status()
            print(json.dumps(status, indent=2, default=str))
            
        elif command == "config":
            print(json.dumps(monitor.config, indent=2))
            
        elif command == "restart":
            success = asyncio.run(monitor._restart_daemon())
            print(f"Restart {'successful' if success else 'failed'}")
            
        elif command == "health-history":
            for entry in monitor.health_history[-10:]:
                print(f"{entry['timestamp']}: Health={entry['status']['health_score']}%")
                
        else:
            print("Usage: python health_monitor.py [status|config|restart|health-history]")
    else:
        # Run monitor
        asyncio.run(main())