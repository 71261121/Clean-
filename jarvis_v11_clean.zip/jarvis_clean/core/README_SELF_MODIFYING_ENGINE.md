# JARVIS v11 Enhanced - Self-Modifying Code Engine

## 📋 Overview

Advanced Self-Modifying Code Engine for JARVIS v11 Enhanced - एक comprehensive system जो runtime पर code को safely modify, update, और manage कर सकती है।

## 🚀 Key Features

### 🔧 Core Capabilities
- **Dynamic Code Injection** - Runtime code addition, editing, deletion
- **Real-time Module Hot-Swap** - Modules को restart के बिना reload करें
- **Self-Update Mechanisms** - GitHub से automatic code updates
- **Code Safety Validation** - AST parsing + security checks
- **Version Control** - Git-like versioning for code changes

### 🛡️ Security Features
- **Sandbox Execution Environment** - Isolated code execution
- **Code Injection Whitelist** - Approved code patterns only
- **Automatic Backups** - Pre-modification backup creation
- **Recovery Mechanisms** - Rollback on failures
- **Signature Verification** - Code integrity checking

### 📱 Termux Compatibility
- **Standard Library Only** - No heavy dependencies
- **Termux-API Integration** - Optional termux features
- **Non-root Friendly** - Works without root access
- **Resource Efficient** - Mobile device optimized

## 📁 File Structure

```
jarvis_v11/core/
├── self_modifying_engine.py      # Main engine implementation
├── self_modifying_engine_demo.py # Comprehensive demo & tests
└── README.md                     # This documentation
```

## 🔧 Installation & Setup

### Basic Setup
```python
from core.self_modifying_engine import SelfModifyingEngine

# Initialize engine
engine = SelfModifyingEngine(
    workspace_dir="/path/to/workspace",
    backup_enabled=True
)

# Check system health
health = engine.health_check()
print(f"Engine status: {health['status']}")
```

### Termux Setup
```bash
# Install in Termux
pkg update && pkg upgrade
pkg install python

# Run setup
cd ~/jarvis_v11
python core/self_modifying_engine_demo.py
```

## 📖 Usage Examples

### 1. Code Safety Validation
```python
# Validate code before execution
code = '''
def calculate_area(length, width):
    return length * width

result = calculate_area(5, 3)
'''

is_safe, warnings = engine.validate_code_safety(code)
if is_safe:
    print("Code is safe to execute")
else:
    print(f"Code validation failed: {warnings}")
```

### 2. Code Injection
```python
# Inject new code into existing file
target_file = "modules/example.py"
new_function = '''
def enhanced_calculation(x, y):
    """Enhanced calculation with validation."""
    if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
        raise ValueError("Inputs must be numbers")
    return x * y + 100
'''

success = engine.inject_code(target_file, new_function, position="append")
```

### 3. Function Replacement
```python
# Replace existing function
module_file = "modules/math_utils.py"
new_function = '''
def calculate(x, y):
    """Enhanced calculation with error handling."""
    try:
        result = x + y
        print(f"Calculated: {x} + {y} = {result}")
        return result
    except Exception as e:
        print(f"Error: {e}")
        return 0
'''

success = engine.replace_function(module_file, "calculate", new_function)
```

### 4. Module Hot Reload
```python
# Hot reload modified module
module_path = "modules/dynamic_module.py"
success = engine.hot_reload_module(module_path)

# Module will be reloaded without restarting application
```

### 5. Version Control
```python
# Get version information
info = engine.get_system_info()
print(f"Current version: {info['current_version']['version']}")
print(f"Build: {info['current_version']['build']}")

# View change history
changes = engine.list_changes(days=7)
for change in changes:
    print(f"{change['timestamp']}: {change['type']}")
```

### 6. Backup & Recovery
```python
# Manual backup
backup_path = engine.create_backup("modules/important.py")
print(f"Backup created: {backup_path}")

# Rollback to previous version
engine.rollback_change("2025-11-01T10:30:00")
```

### 7. GitHub Updates
```python
# Update from GitHub repository
success = engine.update_from_github(
    repo_url="https://github.com/user/repo",
    branch="main"
)
```

### 8. Security Management
```python
# Add to whitelist
engine.whitelist['functions'].append('safe_function')
engine.whitelist['classes'].append('SafeClass')
engine._save_whitelist()

# Export/import whitelist
engine.export_whitelist("whitelist_backup.json")
engine.import_whitelist("whitelist_backup.json")
```

## 🔍 API Reference

### SelfModifyingEngine Class

#### Constructor
```python
engine = SelfModifyingEngine(
    workspace_dir: str = None,    # Working directory path
    backup_enabled: bool = True   # Enable automatic backups
)
```

#### Core Methods

##### `validate_code_safety(code: str) -> Tuple[bool, List[str]]`
Validates code for safety using AST parsing and security checks.
- **Returns**: (is_safe, warnings_list)

##### `inject_code(target_file: str, code_to_add: str, position: str = "append", line_number: int = None) -> bool`
Injects code into target file.
- **Parameters**:
  - `target_file`: File to inject code into
  - `code_to_add`: Code to inject
  - `position`: "append", "prepend", or "insert"
  - `line_number`: Line number for "insert" position

##### `replace_function(module_path: str, function_name: str, new_function_code: str) -> bool`
Replaces specific function in a module.

##### `hot_reload_module(module_path: str) -> bool`
Hot reloads Python module without restart.

##### `update_from_github(repo_url: str, branch: str = "main") -> bool`
Updates code from GitHub repository.

##### `create_backup(file_path: str) -> str`
Creates backup of file before modification.

##### `rollback_change(change_id: str) -> bool`
Rollbacks to previous version.

#### Utility Methods

##### `health_check() -> Dict[str, Any]`
Performs system health check.

##### `get_system_info() -> Dict[str, Any]`
Returns system information.

##### `list_changes(days: int = 7) -> List[Dict[str, Any]]`
Lists recent code changes.

##### `get_code_signature(file_path: str) -> str`
Returns SHA256 hash of file content.

##### `verify_code_integrity(file_path: str, expected_signature: str) -> bool`
Verifies code file integrity.

### Utility Functions

#### `safe_eval(expression: str, safe_globals: Dict = None, safe_locals: Dict = None) -> Any`
Safely evaluates expression with restricted execution.

#### `create_safe_execution_environment() -> Tuple[Dict, Dict]`
Creates safe execution environment for running modified code.

## 🔧 Configuration

### Environment Variables
```bash
# Optional termux-api integration
export TERMUX_API_AVAILABLE=true

# Backup directory customization
export JARVIS_BACKUP_DIR="/custom/backup/path"

# Log level
export JARVIS_LOG_LEVEL="INFO"
```

### Engine Configuration
```python
# Customize dangerous imports detection
engine.dangerous_imports.update(['custom_dangerous_module'])

# Add custom allowed functions
engine.allowed_functions.update(['custom_safe_function'])

# Configure backup settings
engine.backup_enabled = True
engine.backup_dir = Path("/custom/backup/path")
```

## 🛡️ Security Best Practices

### 1. Whitelist Management
```python
# Always use whitelist for production
engine.whitelist = {
    "functions": ["safe_calculation", "data_processor"],
    "modules": ["json", "math"], 
    "classes": ["DataHandler", "Calculator"]
}
```

### 2. Code Validation
```python
# Always validate before injection
code = "def new_function(): return 'safe'"
is_safe, warnings = engine.validate_code_safety(code)

if not is_safe:
    print(f"Security violation: {warnings}")
    # Reject code
else:
    # Safe to proceed
    engine.inject_code(target_file, code)
```

### 3. Backup Strategy
```python
# Enable automatic backups
engine.backup_enabled = True

# Create manual backup before major changes
backup_path = engine.create_backup("critical_module.py")

# Verify backup was created
if not Path(backup_path).exists():
    print("Backup failed - abort changes!")
    return
```

### 4. Error Handling
```python
try:
    engine.inject_code(target, new_code)
except SecurityError as e:
    print(f"Security violation: {e}")
    # Handle security error
except Exception as e:
    print(f"General error: {e}")
    # Check if rollback needed
```

## 📊 Monitoring & Logging

### Health Monitoring
```python
# Regular health checks
health = engine.health_check()
if health['status'] == 'error':
    print("Engine error detected!")
    for error in health['errors']:
        print(f"Error: {error}")

# Monitor disk space
if 'disk_space' in health['checks']:
    free_space = health['checks']['disk_space']
    if 'GB free' in free_space and float(free_space.split()[0]) < 1.0:
        print("Low disk space warning!")
```

### Change Tracking
```python
# Monitor recent changes
recent_changes = engine.list_changes(days=1)
print(f"Changes today: {len(recent_changes)}")

for change in recent_changes:
    print(f"{change['type']} - {change['file']}")
    
# Check for security-related changes
security_changes = [c for c in recent_changes if 'security' in c.get('details', {})]
if security_changes:
    print("Security-related changes detected!")
```

## 🧪 Testing & Demo

### Run Complete Demo
```bash
# Automated demo
python core/self_modifying_engine_demo.py

# Interactive demo
python core/self_modifying_engine_demo.py --interactive
```

### Demo Features
- ✅ System health checks
- ✅ Code safety validation
- ✅ Code injection examples
- ✅ Function replacement
- ✅ Module hot reloading
- ✅ Version control demos
- ✅ Change history tracking
- ✅ Backup & recovery
- ✅ Whitelist management
- ✅ Security testing

### Custom Testing
```python
# Create custom test module
test_code = '''
def test_function(x):
    return x ** 2

if __name__ == "__main__":
    print(test_function(5))
'''

# Test validation
is_safe, warnings = engine.validate_code_safety(test_code)

# Test injection
if is_safe:
    success = engine.inject_code("test_module.py", test_code)
    print(f"Injection successful: {success}")
```

## 🐛 Troubleshooting

### Common Issues

#### 1. Import Errors
```python
# Ensure proper path setup
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from core.self_modifying_engine import SelfModifyingEngine
```

#### 2. Permission Issues
```bash
# Check file permissions
ls -la jarvis_v11/core/
chmod 644 jarvis_v11/core/*.py

# For termux
termux-fix-shebang jarvis_v11/core/*.py
```

#### 3. Backup Failures
```python
# Check backup directory
import os
backup_dir = "/path/to/workspace/code_backups"
if not os.path.exists(backup_dir):
    os.makedirs(backup_dir)

# Manual backup test
try:
    backup_path = engine.create_backup("test_file.py")
    print(f"Backup path: {backup_path}")
except Exception as e:
    print(f"Backup failed: {e}")
```

#### 4. Hot Reload Issues
```python
# Check module loading
import importlib.util
spec = importlib.util.spec_from_file_location("module_name", "module_path")
if spec is None:
    print("Module spec creation failed")

# Clear module cache
if "module_name" in sys.modules:
    del sys.modules["module_name"]
```

## 📈 Performance Considerations

### Optimization Tips
1. **Backup Frequency**: Disable backups for high-frequency operations
2. **Validation Caching**: Cache validation results for repeated code
3. **Module Batching**: Group related changes for single reload
4. **Storage Management**: Regular cleanup of old backups

### Memory Usage
```python
# Monitor memory usage
import psutil
process = psutil.Process()
print(f"Memory usage: {process.memory_info().rss / 1024 / 1024:.2f} MB")

# Clean up old backups
import glob
backup_files = glob.glob("code_backups/*.py")
if len(backup_files) > 100:
    # Keep only recent 50 backups
    sorted_backups = sorted(backup_files, key=os.path.getmtime)
    for backup in sorted_backups[:-50]:
        os.remove(backup)
```

## 🔄 Integration Examples

### With JARVIS Core
```python
# Integrate with main JARVIS system
class JARVISCore:
    def __init__(self):
        self.engine = SelfModifyingEngine()
        self.modules = {}
    
    def load_module(self, module_name):
        """Load module with hot-reload capability."""
        module_path = f"modules/{module_name}.py"
        try:
            self.engine.hot_reload_module(module_path)
            # Import and store reference
            import importlib.util
            spec = importlib.util.spec_from_file_location(module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self.modules[module_name] = module
            return True
        except Exception as e:
            print(f"Module loading failed: {e}")
            return False
    
    def update_module(self, module_name, new_code):
        """Update module with new code."""
        module_path = f"modules/{module_name}.py"
        try:
            # Safety validation
            is_safe, warnings = self.engine.validate_code_safety(new_code)
            if not is_safe:
                print(f"Unsafe code rejected: {warnings}")
                return False
            
            # Replace function or inject code
            success = self.engine.replace_function(module_path, "main", new_code)
            if success:
                # Reload module
                return self.load_module(module_name)
            return False
        except Exception as e:
            print(f"Update failed: {e}")
            return False
```

### With Database Systems
```python
# Safe database operations
class DatabaseIntegration:
    def __init__(self):
        self.engine = SelfModifyingEngine()
    
    def safe_query_execution(self, query_code):
        """Execute database queries safely."""
        # Validate query code
        dangerous_patterns = ['DROP', 'DELETE', 'UPDATE', 'INSERT INTO']
        for pattern in dangerous_patterns:
            if pattern.upper() in query_code.upper():
                raise SecurityError(f"Potentially dangerous query: {pattern}")
        
        # Safe execution environment
        safe_globals, safe_locals = create_safe_execution_environment()
        
        # Add database-specific safe functions
        safe_globals['query_db'] = self._safe_db_query
        
        return safe_eval(query_code, safe_globals, safe_locals)
```

## 📝 License & Credits

- **Author**: JARVIS v11 Enhanced Team
- **Version**: 1.0.0
- **Date**: 2025-11-01
- **License**: MIT License

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Add comprehensive tests
4. Ensure security validation passes
5. Submit pull request

## 📞 Support

For issues, questions, or contributions:
- Check troubleshooting section
- Review demo examples
- Examine log files in `logs/self_modifying_engine.log`

---

**⚠️ Important**: Always test code modifications in a safe environment before deploying to production. Use the built-in safety features and backups to prevent system corruption.