"""
JARVIS v11 - Advanced Termux Controller
100% Native Android Integration
Complete Termux API utilization
"""

import os
import asyncio
import subprocess
import json
import shlex
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

class ProcessState(Enum):
    RUNNING = "running"
    STOPPED = "stopped"
    ERROR = "error"
    UNKNOWN = "unknown"

@dataclass
class ProcessInfo:
    pid: int
    name: str
    state: ProcessState
    cpu_percent: float
    memory_mb: float
    command: str

@dataclass
class TermuxCommand:
    name: str
    description: str
    command: str
    danger_level: int  # 1=safe, 2=caution, 3=dangerous

class AdvancedTermuxController:
    """Advanced Termux controller with complete Android integration"""
    
    def __init__(self):
        self.termux_api_available = self._check_termux_api()
        self.home_dir = Path.home()
        self.termux_paths = self._get_termux_paths()
        
        # Dangerous commands that require confirmation
        self.dangerous_commands = {
            'rm -rf': 3,
            'sudo': 3,
            'su': 3,
            'chmod 777': 2,
            'systemctl reboot': 3,
            'reboot': 3,
            'shutdown': 3,
            'kill -9': 2,
            'dd if=': 3,
            'mkfs': 3,
            'fdisk': 3,
            'dd': 2
        }
        
        # Safe termux commands
        self.safe_commands = [
            'pkg install', 'pkg update', 'pkg upgrade', 'pkg list-installed',
            'termux-api', 'ls', 'pwd', 'cd', 'mkdir', 'cp', 'mv', 'nano', 'vim'
        ]
    
    def _check_termux_api(self) -> bool:
        """Check if termux-api is available with enhanced detection"""
        try:
            result = subprocess.run(['termux-api', '--help'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                logger.info("✅ Termux API detected and available")
                return True
            else:
                logger.warning("⚠️ Termux API command failed")
                return False
        except FileNotFoundError:
            logger.warning("⚠️ Termux API not installed")
            return False
        except Exception as e:
            logger.error(f"❌ Termux API check failed: {e}")
            return False
    
    def _get_termux_paths(self) -> Dict[str, str]:
        """Get important Termux directory paths"""
        return {
            'home': str(self.home_dir),
            'storage_shared': f"{self.home_dir}/storage/shared",
            'storage_downloads': f"{self.home_dir}/storage/downloads",
            'storage_documents': f"{self.home_dir}/storage/documents",
            'data': f"{self.home_dir}/data",
            'tmp': f"{self.home_dir}/tmp",
            'usr_bin': "/data/data/com.termux/files/usr/bin",
            'usr_share': "/data/data/com.termux/files/usr/share",
            'prefix': "/data/data/com.termux/files/usr"
        }
    
    def is_safe_command(self, command: str) -> Tuple[bool, int]:
        """Check if command is safe (returns safe_flag, danger_level)"""
        command_lower = command.lower().strip()
        
        # Check for dangerous patterns
        for dangerous, level in self.dangerous_commands.items():
            if dangerous in command_lower:
                return False, level
        
        # Check if it contains safe commands
        for safe_cmd in self.safe_commands:
            if command_lower.startswith(safe_cmd):
                return True, 1
        
        # Default to caution for unknown commands
        return False, 2
    
    async def execute_command(self, 
                            command: str, 
                            confirm_dangerous: bool = False,
                            timeout: int = 30) -> Dict[str, Any]:
        """Execute command with safety checks"""
        try:
            # Safety check
            is_safe, danger_level = self.is_safe_command(command)
            
            if not is_safe and not confirm_dangerous:
                return {
                    'success': False,
                    'error': f'Dangerous command detected (level {danger_level}). Use confirm_dangerous=True to execute.',
                    'command': command,
                    'danger_level': danger_level
                }
            
            if not is_safe and danger_level == 3:
                return {
                    'success': False,
                    'error': 'HIGH RISK: This command cannot be executed for safety.',
                    'command': command,
                    'danger_level': danger_level
                }
            
            # Execute command
            start_time = asyncio.get_event_loop().time()
            
            try:
                process = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), 
                    timeout=timeout
                )
                
                end_time = asyncio.get_event_loop().time()
                
                return {
                    'success': process.returncode == 0,
                    'return_code': process.returncode,
                    'stdout': stdout.decode('utf-8', errors='ignore'),
                    'stderr': stderr.decode('utf-8', errors='ignore'),
                    'execution_time': end_time - start_time,
                    'command': command
                }
                
            except asyncio.TimeoutError:
                return {
                    'success': False,
                    'error': f'Command timed out after {timeout} seconds',
                    'command': command
                }
                
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            return {
                'success': False,
                'error': str(e),
                'command': command
            }
    
    async def get_battery_status(self) -> Dict[str, Any]:
        """Get battery status using termux-api"""
        try:
            if not self.termux_api_available:
                return {'error': 'termux-api not available'}
            
            result = subprocess.run(['termux-battery-status'], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                return {'error': 'Failed to get battery status', 'stderr': result.stderr}
                
        except Exception as e:
            logger.error(f"Battery status error: {e}")
            return {'error': str(e)}
    
    async def get_wifi_info(self) -> Dict[str, Any]:
        """Get WiFi information"""
        try:
            if self.termux_api_available:
                result = subprocess.run(['termux-wifi-connection-info'], 
                                      capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    return json.loads(result.stdout)
            
            # Fallback to iwconfig
            result = subprocess.run(['iwconfig'], 
                                  capture_output=True, text=True, timeout=10)
            
            return {
                'raw_output': result.stdout,
                'command': 'iwconfig',
                'termux_api_used': self.termux_api_available
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    async def get_location(self) -> Dict[str, Any]:
        """Get current location"""
        try:
            if not self.termux_api_available:
                return {'error': 'termux-api not available'}
            
            result = subprocess.run(['termux-location'], 
                                  capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                return {'error': 'Failed to get location', 'stderr': result.stderr}
                
        except Exception as e:
            return {'error': str(e)}
    
    async def send_notification(self, 
                               title: str, 
                               message: str, 
                               priority: str = "normal") -> Dict[str, Any]:
        """Send notification"""
        try:
            if not self.termux_api_available:
                return {'error': 'termux-api not available'}
            
            cmd = f'termux-notification --title "{title}" --content "{message}" --priority {priority}'
            result = subprocess.run(shlex.split(cmd), 
                                  capture_output=True, text=True, timeout=10)
            
            return {
                'success': result.returncode == 0,
                'error': result.stderr if result.returncode != 0 else None
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    async def get_storage_info(self) -> Dict[str, Any]:
        """Get storage information"""
        try:
            storage_info = {}
            
            # Get internal storage info
            result = subprocess.run(['df', '-h'], 
                                  capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                storage_info['df_output'] = result.stdout
            
            # Get storage paths
            storage_info['paths'] = self.termux_paths
            
            # Check storage access
            for name, path in self.termux_paths.items():
                if os.path.exists(path):
                    try:
                        stat = os.statvfs(path)
                        free = stat.f_frsize * stat.f_bavail
                        total = stat.f_frsize * stat.f_blocks
                        storage_info[name] = {
                            'path': path,
                            'exists': True,
                            'free_bytes': free,
                            'total_bytes': total,
                            'free_mb': free // (1024 * 1024),
                            'total_mb': total // (1024 * 1024)
                        }
                    except Exception as e:
                        storage_info[name] = {'path': path, 'exists': True, 'error': str(e)}
                else:
                    storage_info[name] = {'path': path, 'exists': False}
            
            return storage_info
            
        except Exception as e:
            return {'error': str(e)}
    
    async def get_running_processes(self) -> List[ProcessInfo]:
        """Get running processes information"""
        try:
            processes = []
            
            # Parse /proc/[pid]/stat files
            proc_dir = Path('/proc')
            
            for pid_dir in proc_dir.iterdir():
                if pid_dir.name.isdigit():
                    try:
                        # Read process info
                        stat_file = pid_dir / 'stat'
                        if stat_file.exists():
                            with open(stat_file, 'r') as f:
                                stat_data = f.read().split()
                            
                            if len(stat_data) >= 4:
                                # Parse stat data
                                name = stat_data[1].strip('()')
                                state_char = stat_data[2]
                                
                                # Map state character to enum
                                state_map = {
                                    'R': ProcessState.RUNNING,
                                    'S': ProcessState.STOPPED,
                                    'D': ProcessState.STOPPED,
                                    'Z': ProcessState.ERROR,
                                    'T': ProcessState.STOPPED
                                }
                                state = state_map.get(state_char, ProcessState.UNKNOWN)
                                
                                # Get command line
                                cmdline_file = pid_dir / 'cmdline'
                                command = ""
                                if cmdline_file.exists():
                                    with open(cmdline_file, 'r') as f:
                                        command = f.read().replace('\x00', ' ')
                                
                                processes.append(ProcessInfo(
                                    pid=int(pid_dir.name),
                                    name=name,
                                    state=state,
                                    cpu_percent=0.0,  # Would need additional parsing
                                    memory_mb=0.0,    # Would need additional parsing
                                    command=command
                                ))
                    except (PermissionError, FileNotFoundError, ValueError):
                        continue
            
            # Sort by PID and limit
            processes.sort(key=lambda x: x.pid)
            return processes[:50]  # Return first 50 processes
            
        except Exception as e:
            logger.error(f"Process info error: {e}")
            return []
    
    async def kill_process(self, pid: int, force: bool = False) -> Dict[str, Any]:
        """Kill a process"""
        try:
            signal = '-9' if force else '-15'  # SIGKILL vs SIGTERM
            
            result = subprocess.run(['kill', signal, str(pid)], 
                                  capture_output=True, text=True, timeout=10)
            
            return {
                'success': result.returncode == 0,
                'pid': pid,
                'signal': signal,
                'error': result.stderr if result.returncode != 0 else None
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e), 'pid': pid}
    
    async def install_packages(self, packages: List[str]) -> Dict[str, Any]:
        """Install packages using pkg"""
        try:
            if not isinstance(packages, list):
                packages = [packages]
            
            package_list = ' '.join(packages)
            command = f"pkg install -y {package_list}"
            
            return await self.execute_command(command)
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    async def update_packages(self) -> Dict[str, Any]:
        """Update package database"""
        try:
            return await self.execute_command("pkg update -y")
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    async def upgrade_packages(self) -> Dict[str, Any]:
        """Upgrade installed packages"""
        try:
            return await self.execute_command("pkg upgrade -y")
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    async def list_installed_packages(self) -> Dict[str, Any]:
        """List installed packages"""
        try:
            result = await self.execute_command("pkg list-installed")
            if result['success']:
                # Parse package list
                packages = result['stdout'].strip().split('\n')
                return {
                    'success': True,
                    'packages': [pkg.strip() for pkg in packages if pkg.strip()],
                    'count': len([pkg.strip() for pkg in packages if pkg.strip()])
                }
            else:
                return result
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    async def get_system_info(self) -> Dict[str, Any]:
        """Get comprehensive system information"""
        try:
            tasks = [
                self.get_battery_status(),
                self.get_wifi_info(),
                self.get_storage_info(),
                self.get_running_processes()
            ]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            battery, wifi, storage, processes = results
            
            return {
                'timestamp': asyncio.get_event_loop().time(),
                'termux_api_available': self.termux_api_available,
                'termux_paths': self.termux_paths,
                'battery': battery if not isinstance(battery, Exception) else {'error': str(battery)},
                'wifi': wifi if not isinstance(wifi, Exception) else {'error': str(wifi)},
                'storage': storage if not isinstance(storage, Exception) else {'error': str(storage)},
                'processes': processes if not isinstance(processes, Exception) else []
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def get_safe_commands(self) -> List[TermuxCommand]:
        """Get list of safe commands"""
        return [
            TermuxCommand("list-packages", "List installed packages", "pkg list-installed", 1),
            TermuxCommand("update-packages", "Update package database", "pkg update -y", 1),
            TermuxCommand("upgrade-packages", "Upgrade packages", "pkg upgrade -y", 1),
            TermuxCommand("battery-status", "Get battery information", "termux-battery-status", 1),
            TermuxCommand("wifi-info", "Get WiFi information", "termux-wifi-connection-info", 1),
            TermuxCommand("storage-info", "Get storage information", "df -h", 1),
        ]
    
    def get_dangerous_commands_warning(self) -> str:
        """Get warning about dangerous commands"""
        return """
        ⚠️ DANGEROUS COMMANDS WARNING ⚠️
        
        The following command types are considered dangerous and require confirmation:
        
        Level 2 (Caution):
        - chmod 777 (permission changes)
        - kill -9 (force kill)
        - dd (disk operations)
        
        Level 3 (High Risk - Blocked):
        - rm -rf (recursive deletion)
        - sudo/su (root access)
        - systemctl reboot/shutdown
        - mkfs/fdisk (filesystem operations)
        
        For safety, use confirm_dangerous=True only for level 2 commands.
        Level 3 commands are permanently blocked.
        """

# Create global instance
termux_controller = AdvancedTermuxController()