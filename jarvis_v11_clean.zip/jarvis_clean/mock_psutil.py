#!/usr/bin/env python3
"""
JARVIS v11 - Mock psutil Module
================================

A lightweight mock implementation of psutil for testing JARVIS v11
in environments where psutil compilation fails (like Termux on Android).

This provides basic system monitoring functionality using built-in modules
without requiring external dependencies.
"""

import os
import time
import platform
import subprocess
import json
from typing import Dict, List, Optional, Tuple
from datetime import datetime

def get_system_info() -> Dict[str, any]:
    """Get basic system information"""
    return {
        'platform': platform.system(),
        'platform_release': platform.release(),
        'platform_version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'python_version': platform.python_version(),
        'cpu_count': os.cpu_count() or 1,
        'boot_time': time.time() - 3600,  # Mock boot time
    }

def get_cpu_percent(interval: float = None) -> float:
    """Mock CPU percentage (always returns a reasonable value)"""
    return 15.0  # Mock CPU usage

def get_memory_info() -> Dict[str, int]:
    """Mock memory information"""
    # Mock memory values (in bytes)
    total = 4 * 1024 * 1024 * 1024  # 4GB
    available = int(total * 0.6)  # 60% available
    used = total - available
    
    return {
        'total': total,
        'available': available,
        'used': used,
        'free': available,
        'percent': 40.0,  # 40% used
    }

def get_disk_usage(path: str) -> Dict[str, any]:
    """Mock disk usage information"""
    # Mock disk values
    total = 64 * 1024 * 1024 * 1024  # 64GB
    used = int(total * 0.3)  # 30% used
    free = total - used
    
    return {
        'total': total,
        'used': used,
        'free': free,
        'percent': 30.0,
    }

def get_disk_io_counters() -> Dict[str, int]:
    """Mock disk I/O counters"""
    return {
        'read_count': 1000000,
        'write_count': 500000,
        'read_bytes': 1024 * 1024 * 1024,  # 1GB
        'write_bytes': 512 * 1024 * 1024,  # 512MB
        'read_time': 5000,
        'write_time': 3000,
    }

def get_net_io_counters() -> Dict[str, int]:
    """Mock network I/O counters"""
    return {
        'bytes_sent': 100 * 1024 * 1024,  # 100MB
        'bytes_recv': 200 * 1024 * 1024,  # 200MB
        'packets_sent': 1000000,
        'packets_recv': 1500000,
        'errin': 0,
        'errout': 0,
        'dropin': 0,
        'dropout': 0,
    }

def get_process_list() -> List[Dict[str, any]]:
    """Mock process list (simplified)"""
    return [
        {
            'pid': 1,
            'name': 'init',
            'cpu_percent': 0.1,
            'memory_percent': 0.5,
            'status': 'running',
        },
        {
            'pid': 1234,
            'name': 'jarvis',
            'cpu_percent': 2.5,
            'memory_percent': 1.2,
            'status': 'running',
        },
        {
            'pid': 5678,
            'name': 'termux',
            'cpu_percent': 5.0,
            'memory_percent': 3.0,
            'status': 'running',
        },
    ]

def get_process(pid: int) -> Optional[Dict[str, any]]:
    """Get mock process info by PID"""
    processes = get_process_list()
    for proc in processes:
        if proc['pid'] == pid:
            return proc
    return None

def get_battery_info() -> Dict[str, any]:
    """Mock battery information"""
    return {
        'percent': 75,  # 75% battery
        'power_plugged': False,
        'secsleft': 10800,  # 3 hours left
        'status': 'discharging',
    }

def get_temperature_info() -> Dict[str, float]:
    """Mock temperature information"""
    return {
        'cpu': 35.5,  # 35.5°C
        'battery': 32.0,  # 32°C
    }

def get_boot_time() -> float:
    """Get mock boot time"""
    return time.time() - 3600  # Mock boot time (1 hour ago)

def get_load_average() -> Tuple[float, float, float]:
    """Get mock load average (Unix-like systems)"""
    if hasattr(os, 'getloadavg'):
        return os.getloadavg()
    return (0.5, 0.3, 0.2)  # Mock values

def virtual_memory() -> Dict[str, any]:
    """Alias for get_memory_info"""
    return get_memory_info()

def swap_memory() -> Dict[str, any]:
    """Mock swap memory information (not typically available on Android)"""
    return {
        'total': 0,
        'used': 0,
        'free': 0,
        'percent': 0.0,
        'sin': 0,
        'sout': 0,
    }

def cpu_times() -> Dict[str, float]:
    """Mock CPU times"""
    return {
        'user': 100.0,
        'nice': 0.0,
        'system': 50.0,
        'idle': 500.0,
        'iowait': 2.0,
        'irq': 1.0,
        'softirq': 0.5,
    }

def per_cpu_times() -> List[Dict[str, float]]:
    """Mock per-CPU times"""
    return [cpu_times()]

def cpu_count(logical: bool = True) -> int:
    """Get CPU count"""
    return os.cpu_count() or 1

def cpu_count_physical() -> int:
    """Get physical CPU count"""
    return max(1, (os.cpu_count() or 1) // 2)

def get_users() -> List[Dict[str, any]]:
    """Mock users information"""
    return [
        {
            'name': 'user',
            'terminal': 'pts/0',
            'host': 'localhost',
            'started': time.time() - 3600,
        }
    ]

# Battery and power status
def power_plugged() -> bool:
    """Check if power is plugged in"""
    return False  # Mock: always discharging

# Process management
def pid_exists(pid: int) -> bool:
    """Check if PID exists"""
    processes = get_process_list()
    return any(proc['pid'] == pid for proc in processes)

def Process(pid: int) -> 'MockProcess':
    """Create a mock process object"""
    return MockProcess(pid)

class MockProcess:
    """Mock process class for compatibility"""
    
    def __init__(self, pid: int):
        self.pid = pid
        self._info = get_process(pid) or {}
    
    def name(self) -> str:
        return self._info.get('name', 'unknown')
    
    def cpu_percent(self) -> float:
        return self._info.get('cpu_percent', 0.0)
    
    def memory_percent(self) -> float:
        return self._info.get('memory_percent', 0.0)
    
    def status(self) -> str:
        return self._info.get('status', 'unknown')
    
    def create_time(self) -> float:
        return time.time() - 1800  # Mock creation time
    
    def memory_info(self) -> Dict[str, int]:
        return {
            'rss': 50 * 1024 * 1024,  # 50MB
            'vms': 100 * 1024 * 1024,  # 100MB
        }
    
    def cmdline(self) -> List[str]:
        return ['python3', 'jarvis.py']
    
    def terminate(self):
        pass  # Mock: do nothing
    
    def kill(self):
        pass  # Mock: do nothing
    
    def suspend(self):
        pass  # Mock: do nothing
    
    def resume(self):
        pass  # Mock: do nothing

# Export everything that might be imported
__all__ = [
    'get_system_info',
    'get_cpu_percent',
    'get_memory_info', 
    'get_disk_usage',
    'get_disk_io_counters',
    'get_net_io_counters',
    'get_process_list',
    'get_process',
    'get_battery_info',
    'get_temperature_info',
    'get_boot_time',
    'get_load_average',
    'virtual_memory',
    'swap_memory',
    'cpu_times',
    'per_cpu_times',
    'cpu_count',
    'cpu_count_physical',
    'get_users',
    'power_plugged',
    'pid_exists',
    'Process',
]

if __name__ == "__main__":
    # Test the mock module
    print("JARVIS v11 Mock psutil Module")
    print("=" * 40)
    print(f"System Info: {json.dumps(get_system_info(), indent=2)}")
    print(f"CPU Usage: {get_cpu_percent()}%")
    print(f"Memory Info: {json.dumps(get_memory_info(), indent=2)}")
    print(f"Battery Info: {json.dumps(get_battery_info(), indent=2)}")
    print(f"Disk Usage: {json.dumps(get_disk_usage('/'), indent=2)}")
    print(f"Network I/O: {json.dumps(get_net_io_counters(), indent=2)}")
    print(f"Temperature: {json.dumps(get_temperature_info(), indent=2)}")
    print(f"Process List: {len(get_process_list())} processes")
    print(f"Boot Time: {datetime.fromtimestamp(get_boot_time())}")
    print(f"Load Average: {get_load_average()}")
    print(f"Users: {get_users()}")
    print(f"Power Plugged: {power_plugged()}")
    print("Mock psutil module working correctly!")