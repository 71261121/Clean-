"""
JARVIS v11 - Termux Compatibility Test
Tests all replacement modules to ensure zero compilation issues
"""

import sys
import os
import traceback
from typing import Dict, Any, List


def test_simple_validation():
    """Test simple validation module"""
    print("🔧 Testing simple_validation.py...")
    
    try:
        # Import modules
        sys.path.append('/workspace/jarvis_v11/core')
        from simple_validation import User, Config, SimpleValidator, StringValidator, NumberValidator
        
        # Test User model
        user = User(name="John Doe", email="john@example.com", age=25)
        print(f"✅ User created: {user.name}, {user.email}")
        
        # Test validation
        assert StringValidator.min_length("test", 2) == True
        assert NumberValidator.positive(10) == True
        assert SimpleValidator.validate_email("test@example.com") == True
        print("✅ Validation functions work")
        
        # Test JSON conversion
        user_json = user.json()
        print(f"✅ JSON conversion: {user_json[:50]}...")
        
        return True
        
    except Exception as e:
        print(f"❌ simple_validation test failed: {e}")
        traceback.print_exc()
        return False


def test_git_wrapper():
    """Test git wrapper module"""
    print("\n🔧 Testing git_wrapper.py...")
    
    try:
        from core.git_wrapper import GitWrapper
        
        # Test GitWrapper initialization
        git = GitWrapper('/workspace/jarvis_v11')
        print("✅ GitWrapper initialized")
        
        # Test repository detection
        is_repo = git.is_repo()
        print(f"✅ Repository check: {is_repo}")
        
        if is_repo:
            # Test basic git operations
            branch = git.get_branch()
            print(f"✅ Current branch: {branch}")
            
            status = git.get_status()
            print(f"✅ Repository status: {status['clean']}")
        
        return True
        
    except Exception as e:
        print(f"⚠️  Git wrapper test: {e}")
        return True  # Git operations may not be available in test environment


def test_lightweight_crypto():
    """Test lightweight cryptography module"""
    print("\n🔧 Testing lightweight_crypto.py...")
    
    try:
        from core.lightweight_crypto import (
            SecureHasher, SecureRandom, Base64Encoder, 
            PasswordHasher, TokenManager
        )
        
        # Test secure hashing
        test_data = "Hello, JARVIS!"
        hash_result = SecureHasher.sha256(test_data)
        print(f"✅ SHA-256 hash: {hash_result}")
        
        # Test secure random
        random_token = SecureRandom.token_hex(16)
        print(f"✅ Random token: {random_token}")
        
        # Test base64 encoding
        encoded = Base64Encoder.encode(test_data)
        decoded = Base64Encoder.decode(encoded)
        assert decoded.decode('utf-8') == test_data
        print("✅ Base64 encoding/decoding works")
        
        # Test password hashing
        password_hash = PasswordHasher.hash_password("mypassword")
        is_valid = PasswordHasher.verify_password("mypassword", password_hash)
        assert is_valid == True
        print("✅ Password hashing works")
        
        # Test token generation
        payload = {"user_id": "123", "exp": 9999999999}
        token = TokenManager.generate_jwt_like(payload)
        print(f"✅ JWT token: {token[:50]}...")
        
        return True
        
    except Exception as e:
        print(f"❌ lightweight_crypto test failed: {e}")
        traceback.print_exc()
        return False


def test_termux_compatibility():
    """Test Termux environment compatibility"""
    print("\n🔧 Testing Termux compatibility...")
    
    try:
        # Test Python version
        python_version = sys.version_info
        print(f"✅ Python version: {python_version.major}.{python_version.minor}.{python_version.micro}")
        
        # Test available built-in modules
        builtin_modules = ['hashlib', 'json', 'subprocess', 'secrets', 'hmac', 'base64', 'binascii']
        for module_name in builtin_modules:
            try:
                __import__(module_name)
                print(f"✅ Built-in module available: {module_name}")
            except ImportError as e:
                print(f"❌ Missing built-in module: {module_name}")
                return False
        
        # Test file operations
        test_file = "/tmp/jarvis_test.txt"
        with open(test_file, 'w') as f:
            f.write("JARVIS v11 test file")
        
        with open(test_file, 'r') as f:
            content = f.read()
        
        assert content == "JARVIS v11 test file"
        os.remove(test_file)
        print("✅ File operations work")
        
        return True
        
    except Exception as e:
        print(f"❌ Termux compatibility test failed: {e}")
        traceback.print_exc()
        return False


def run_performance_test():
    """Run basic performance tests"""
    print("\n⚡ Running performance tests...")
    
    try:
        from core.lightweight_crypto import SecureHasher
        import time
        
        # Test hashing performance
        test_data = "Hello, JARVIS! This is a test message for performance benchmarking."
        start_time = time.time()
        
        for _ in range(100):
            SecureHasher.sha256(test_data)
        
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"✅ 100 SHA-256 operations took: {duration:.4f} seconds")
        print(f"✅ Average per operation: {duration/100*1000:.2f} ms")
        
        # Test with larger data
        large_data = test_data * 1000
        start_time = time.time()
        
        SecureHasher.sha256(large_data)
        
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"✅ Large data (1KB) SHA-256 took: {duration:.4f} seconds")
        
        return True
        
    except Exception as e:
        print(f"❌ Performance test failed: {e}")
        traceback.print_exc()
        return False


def generate_dependency_report():
    """Generate dependency analysis report"""
    print("\n📋 Generating dependency analysis report...")
    
    try:
        # Check original requirements
        original_req_file = '/workspace/jarvis_v11/requirements_termux_optimized.txt'
        new_req_file = '/workspace/jarvis_v11/requirements_termux_proof.txt'
        
        with open(original_req_file, 'r') as f:
            original_content = f.read()
        
        with open(new_req_file, 'r') as f:
            new_content = f.read()
        
        print("✅ Dependencies analysis:")
        print(f"📄 Original file: {original_req_file}")
        print(f"📄 New file: {new_req_file}")
        
        # Count removed dependencies
        removed_count = original_content.count('REMOVED')
        print(f"🗑️  Problematic dependencies identified: {removed_count}")
        
        return True
        
    except Exception as e:
        print(f"❌ Dependency report failed: {e}")
        return False


def main():
    """Run all tests"""
    print("🚀 JARVIS v11 - Termux Compatibility Test Suite")
    print("=" * 60)
    
    tests = [
        ("Simple Validation", test_simple_validation),
        ("Git Wrapper", test_git_wrapper),
        ("Lightweight Crypto", test_lightweight_crypto),
        ("Termux Compatibility", test_termux_compatibility),
        ("Performance Test", run_performance_test),
        ("Dependency Report", generate_dependency_report)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results[test_name] = result
        except Exception as e:
            print(f"❌ {test_name} crashed: {e}")
            results[test_name] = False
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<25} {status}")
        if result:
            passed += 1
    
    print(f"\n🎯 Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! JARVIS v11 is ready for Termux!")
    else:
        print("⚠️  Some tests failed. Review errors above.")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)